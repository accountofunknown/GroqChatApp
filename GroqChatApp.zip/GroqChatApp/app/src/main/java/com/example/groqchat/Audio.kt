package com.example.groqchat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max

class Recorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start() {
        val f = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}.m4a")
        val r = newRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioSamplingRate(16000)
        r.setAudioEncodingBitRate(64000)
        r.setOutputFile(f.absolutePath)
        r.prepare()
        r.start()
        rec = r
        file = f
    }

    /** Loudness since the last call (0..32767), used to detect when you start and stop speaking. */
    fun level(): Int = try { rec?.maxAmplitude ?: 0 } catch (e: Exception) { 0 }

    fun stop(): File? {
        val r = rec ?: return null
        try { r.stop() } catch (e: RuntimeException) { file?.delete(); file = null }
        r.release()
        rec = null
        return file.also { file = null }
    }
}

/** Plays WAV chunks one after another. Chunks can be added while earlier ones are already playing. */
class Player {
    private var mp: MediaPlayer? = null
    private val queue = ArrayDeque<File>()
    private var closed = true
    private var done: (() -> Unit)? = null

    /** Starts a new session. [onDone] runs when everything has played, or when [stop] is called. */
    fun begin(onDone: () -> Unit) {
        stop()
        closed = false
        done = onDone
    }

    fun add(f: File) {
        queue.addLast(f)
        if (mp == null) next()
    }

    /** No more chunks will be added. */
    fun finish() {
        closed = true
        if (mp == null && queue.isEmpty()) fireDone()
    }

    private fun fireDone() {
        val d = done
        done = null
        d?.invoke()
    }

    private fun next() {
        val f = queue.removeFirstOrNull()
        if (f == null) { if (closed) fireDone(); return }
        try {
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { it.release(); f.delete(); if (mp === it) mp = null; next() }
            p.setOnErrorListener { it, _, _ -> it.release(); f.delete(); if (mp === it) mp = null; next(); true }
            mp = p
            p.prepare()
            p.start()
        } catch (e: Exception) { f.delete(); mp = null; next() }
    }

    fun stop() {
        queue.forEach { it.delete() }
        queue.clear()
        mp?.let { try { it.stop() } catch (e: Exception) {}; it.release() }
        mp = null
        closed = true
        fireDone()
    }
}

/** Text splitter: Orpheus accepts max 200 characters per request. */
object TtsText {
    fun chunks(raw: String, max: Int = 200, limit: Int = 10): List<String> {
        val clean = raw.replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("[*_#`>|]"), "")
            .replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return emptyList()
        val out = mutableListOf<String>()
        var cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) out.add(cur.toString().trim()); cur = StringBuilder() }
        for (s in clean.split(Regex("(?<=[.!?؟。])\\s+"))) {
            var piece = s
            while (piece.length > max) {
                val cut = piece.lastIndexOf(' ', max).let { if (it <= 0) max else it }
                flush()
                out.add(piece.substring(0, cut).trim())
                piece = piece.substring(cut).trim()
            }
            if (cur.length + piece.length + 1 > max) flush()
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(piece)
        }
        flush()
        return out.take(limit)
    }
}

/** Reads an image Uri, downsizes to maxSide and returns a base64 JPEG data URL (for vision models). */
fun uriToDataUrl(ctx: Context, uri: Uri, maxSide: Int = 1600): String? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
    val bmp = ctx.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
    } ?: return null
    val scale = maxSide.toFloat() / max(bmp.width, bmp.height)
    val out = if (scale < 1f)
        Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
    val rotation = try {
        ctx.contentResolver.openInputStream(uri)?.use { st ->
            when (ExifInterface(st).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
    } catch (e: Exception) { 0f }
    val upright = if (rotation != 0f)
        Bitmap.createBitmap(out, 0, 0, out.width, out.height, Matrix().apply { postRotate(rotation) }, true) else out
    val bos = ByteArrayOutputStream()
    upright.compress(Bitmap.CompressFormat.JPEG, 85, bos)
    return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
}
