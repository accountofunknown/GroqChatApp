package com.example.groqchat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max

class Recorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start() {
        val f = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}.m4a")
        val r = newRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioSamplingRate(16000)
        r.setAudioEncodingBitRate(64000)
        r.setOutputFile(f.absolutePath)
        r.prepare()
        r.start()
        rec = r
        file = f
    }

    fun stop(): File? {
        val r = rec ?: return null
        try { r.stop() } catch (e: RuntimeException) { file?.delete(); file = null }
        r.release()
        rec = null
        return file.also { file = null }
    }
}

class Player {
    private var mp: MediaPlayer? = null
    private var queue = ArrayDeque<File>()
    private var done: (() -> Unit)? = null

    fun playAll(files: List<File>, onDone: () -> Unit) {
        stop()
        queue = ArrayDeque(files)
        done = onDone
        next()
    }

    private fun next() {
        val f = queue.removeFirstOrNull()
        if (f == null) { done?.invoke(); return }
        try {
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { it.release(); f.delete(); if (mp === it) mp = null; next() }
            p.setOnErrorListener { it, _, _ -> it.release(); f.delete(); if (mp === it) mp = null; next(); true }
            mp = p
            p.prepare()
            p.start()
        } catch (e: Exception) { f.delete(); next() }
    }

    fun stop() {
        queue.forEach { it.delete() }
        queue.clear()
        mp?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        mp = null
    }
}

/** Text splitter: Orpheus accepts max 200 characters per request. */
object TtsText {
    fun chunks(raw: String, max: Int = 200, limit: Int = 10): List<String> {
        val clean = raw.replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("[*_#`>|]"), "")
            .replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return emptyList()
        val out = mutableListOf<String>()
        var cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) out.add(cur.toString().trim()); cur = StringBuilder() }
        for (s in clean.split(Regex("(?<=[.!?؟。])\\s+"))) {
            var piece = s
            while (piece.length > max) {
                val cut = piece.lastIndexOf(' ', max).let { if (it <= 0) max else it }
                flush()
                out.add(piece.substring(0, cut).trim())
                piece = piece.substring(cut).trim()
            }
            if (cur.length + piece.length + 1 > max) flush()
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(piece)
        }
        flush()
        return out.take(limit)
    }
}

/** Reads an image Uri, downsizes to maxSide and returns a base64 JPEG data URL (for vision models). */
fun uriToDataUrl(ctx: Context, uri: Uri, maxSide: Int = 1600): String? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
    val bmp = ctx.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
    } ?: return null
    val scale = maxSide.toFloat() / max(bmp.width, bmp.height)
    val out = if (scale < 1f)
        Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
    val bos = ByteArrayOutputStream()
    out.compress(Bitmap.CompressFormat.JPEG, 85, bos)
    return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
}
