package com.example.groqchat

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class FriendlyErrorTest {

    @Test
    fun invalidKeyMessage() {
        val msg = friendlyErrorMessage(ApiException(401, "unauthorized", null))
        assertTrue(msg.contains("API key", ignoreCase = true))
    }

    @Test
    fun rateLimitMentionsRetry() {
        val msg = friendlyErrorMessage(ApiException(429, "slow down", "5"))
        assertTrue(msg.contains("Rate limit", ignoreCase = true))
    }

    @Test
    fun offlineHost() {
        val msg = friendlyErrorMessage(IOException("Unable to resolve host api.groq.com"))
        assertTrue(msg.contains("internet", ignoreCase = true) || msg.contains("connection", ignoreCase = true))
    }
}
