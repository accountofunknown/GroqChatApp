package com.example.groqchat

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * Client-side web tools so any function-calling model can use the internet
 * (not only gpt-oss server browser_search).
 */
object WebTools {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    val names = listOf("web_search", "fetch_url")

    fun definitions(): JSONArray = JSONArray().apply {
        put(
            JSONObject().put("type", "function").put(
                "function", JSONObject()
                    .put("name", "web_search")
                    .put("description", "Search the public web and return short result snippets. Use for current events, facts, or documentation.")
                    .put(
                        "parameters", JSONObject()
                            .put("type", "object")
                            .put(
                                "properties", JSONObject()
                                    .put("query", JSONObject().put("type", "string").put("description", "Search query"))
                            )
                            .put("required", JSONArray().put("query"))
                    )
            )
        )
        put(
            JSONObject().put("type", "function").put(
                "function", JSONObject()
                    .put("name", "fetch_url")
                    .put("description", "Download a public https page and return plain text (HTML tags stripped). Max ~12k characters.")
                    .put(
                        "parameters", JSONObject()
                            .put("type", "object")
                            .put(
                                "properties", JSONObject()
                                    .put("url", JSONObject().put("type", "string").put("description", "https URL to fetch"))
                            )
                            .put("required", JSONArray().put("url"))
                    )
            )
        )
    }

    fun run(name: String, args: String, searchApiKey: String = ""): String = try {
        val a = if (args.isBlank()) JSONObject() else JSONObject(args)
        when (name) {
            "web_search" -> search(a.optString("query", "").trim(), searchApiKey)
            "fetch_url" -> fetch(a.optString("url", "").trim())
            else -> "Unknown web tool: $name"
        }
    } catch (e: Exception) {
        "Error: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun search(query: String, searchApiKey: String = ""): String {
        if (query.isBlank()) return "Error: empty query"
        if (searchApiKey.isNotBlank()) {
            val brave = braveSearch(query, searchApiKey)
            if (brave != null) return brave
        }
        // DuckDuckGo Instant Answer API — no key required (fallback)
        val url = "https://api.duckduckgo.com/?q=${java.net.URLEncoder.encode(query, "UTF-8")}&format=json&no_html=1&skip_disambig=1"
        val body = get(url) ?: return "Error: search request failed"
        val j = JSONObject(body)
        val sb = StringBuilder()
        val heading = j.optString("Heading")
        val abstract = j.optString("AbstractText")
        val abstractUrl = j.optString("AbstractURL")
        if (abstract.isNotBlank()) {
            sb.appendLine(if (heading.isNotBlank()) "$heading: $abstract" else abstract)
            if (abstractUrl.isNotBlank()) sb.appendLine("Source: $abstractUrl")
        }
        val related = j.optJSONArray("RelatedTopics")
        if (related != null) {
            var n = 0
            for (i in 0 until related.length()) {
                if (n >= 6) break
                val item = related.optJSONObject(i) ?: continue
                val text = item.optString("Text")
                val firstUrl = item.optString("FirstURL")
                if (text.isNotBlank()) {
                    sb.appendLine("• $text")
                    if (firstUrl.isNotBlank()) sb.appendLine("  $firstUrl")
                    n++
                } else {
                    val topics = item.optJSONArray("Topics") ?: continue
                    for (k in 0 until topics.length()) {
                        if (n >= 6) break
                        val t = topics.optJSONObject(k) ?: continue
                        val tx = t.optString("Text")
                        val u = t.optString("FirstURL")
                        if (tx.isBlank()) continue
                        sb.appendLine("• $tx")
                        if (u.isNotBlank()) sb.appendLine("  $u")
                        n++
                    }
                }
            }
        }
        val out = sb.toString().trim()
        return out.ifBlank {
            "No structured results for \"$query\". Try a more specific query or fetch_url on a known page."
        }.take(8000)
    }

    private fun fetch(url: String): String {
        if (url.isBlank()) return "Error: empty url"
        val u = url.trim()
        if (!u.startsWith("https://") && !u.startsWith("http://")) {
            return "Error: only http(s) URLs are allowed"
        }
        if (u.startsWith("http://")) {
            return "Error: only https URLs are allowed for safety"
        }
        val raw = get(u) ?: return "Error: failed to fetch URL"
        val text = stripHtml(raw).replace(Regex("\\s+\n"), "\n").replace(Regex("[ \\t]+"), " ").trim()
        return text.take(12000).ifBlank { "Error: page had no extractable text" }
    }

    private fun braveSearch(query: String, apiKey: String): String? {
        val url = "https://api.search.brave.com/res/v1/web/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&count=6"
        val req = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("X-Subscription-Token", apiKey)
            .header("User-Agent", "GroqChatApp/1.0")
            .get()
            .build()
        return try {
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val j = JSONObject(resp.body?.string().orEmpty())
                val web = j.optJSONObject("web")?.optJSONArray("results") ?: return null
                val sb = StringBuilder("Search results for \"$query\":\n")
                for (i in 0 until web.length()) {
                    val r = web.optJSONObject(i) ?: continue
                    val title = r.optString("title")
                    val desc = r.optString("description")
                    val link = r.optString("url")
                    sb.appendLine("${i + 1}. $title")
                    if (desc.isNotBlank()) sb.appendLine("   $desc")
                    if (link.isNotBlank()) sb.appendLine("   $link")
                }
                sb.toString().trim().take(8000).ifBlank { null }
            }
        } catch (_: Exception) { null }
    }

    private fun get(url: String): String? {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "GroqChatApp/1.0 (Android; research tool)")
            .header("Accept", "text/html,application/json,*/*")
            .get()
            .build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            return resp.body?.string()
        }
    }

    private fun stripHtml(html: String): String {
        var s = html
        s = Pattern.compile("(?is)<script[^>]*>.*?</script>").matcher(s).replaceAll(" ")
        s = Pattern.compile("(?is)<style[^>]*>.*?</style>").matcher(s).replaceAll(" ")
        s = Pattern.compile("(?is)<[^>]+>").matcher(s).replaceAll(" ")
        s = s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'")
        return s
    }
}

/** Redact common secret patterns before sending text to the model. */
object SecretRedaction {
    private val patterns = listOf(
        Regex("""(?i)\b(sk-[A-Za-z0-9]{20,})\b"""),
        Regex("""(?i)\b(gsk_[A-Za-z0-9]{20,})\b"""),
        Regex("""(?i)\b(api[_-]?key\s*[:=]\s*)([A-Za-z0-9_\-]{16,})"""),
        Regex("""(?i)\b(Bearer\s+)([A-Za-z0-9\-._~+/]+=*)"""),
        Regex("""(?i)\b(xox[baprs]-[A-Za-z0-9-]{10,})\b"""),
        Regex("""(?i)\b(ghp_[A-Za-z0-9]{20,})\b"""),
        Regex("""(?i)\b(AKIA[0-9A-Z]{16})\b"""),
    )

    fun redact(text: String): String {
        var t = text
        for (p in patterns) {
            t = p.replace(t) { m ->
                if (m.groupValues.size > 2) m.groupValues[1] + "•••REDACTED•••"
                else "•••REDACTED•••"
            }
        }
        return t
    }

    fun containsSecret(text: String): Boolean = patterns.any { it.containsMatchIn(text) }
}
