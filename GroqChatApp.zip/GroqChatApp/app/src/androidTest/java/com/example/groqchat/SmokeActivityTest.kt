package com.example.groqchat

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Emulator smoke: app launches without crashing.
 * With a blank API key the UI opens Settings (or shows onboarding copy).
 */
@RunWith(AndroidJUnit4::class)
@LargeTest
class SmokeActivityTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun appLaunches_showsSettingsOrChatChrome() {
        composeRule.waitForIdle()
        val settingsVisible = runCatching {
            composeRule.onNodeWithText("API key", substring = true).assertIsDisplayed()
            true
        }.getOrDefault(false)
        val doneVisible = runCatching {
            composeRule.onNodeWithText("Done").assertIsDisplayed()
            true
        }.getOrDefault(false)
        val helpVisible = runCatching {
            composeRule.onNodeWithText("How can I help?", substring = true).assertIsDisplayed()
            true
        }.getOrDefault(false)
        assertTrue(
            "Expected Settings or chat empty state after launch",
            settingsVisible || doneVisible || helpVisible
        )
    }
}
