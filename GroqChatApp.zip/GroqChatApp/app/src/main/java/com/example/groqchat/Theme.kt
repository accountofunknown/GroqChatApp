package com.example.groqchat

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val GroqLight = lightColorScheme(
    primary = Color(0xFFD83A1F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD2),
    onPrimaryContainer = Color(0xFF410100),
    secondary = Color(0xFF765650),
    background = Color(0xFFFFFBFA),
    onBackground = Color(0xFF201A19),
    surface = Color(0xFFFFFBFA),
    onSurface = Color(0xFF201A19),
    surfaceVariant = Color(0xFFF5DDD8),
    onSurfaceVariant = Color(0xFF534341),
    outlineVariant = Color(0xFFD8C2BE),
)

val GroqDark = darkColorScheme(
    primary = Color(0xFFFFB4A5),
    onPrimary = Color(0xFF650B00),
    primaryContainer = Color(0xFF8E1D0A),
    onPrimaryContainer = Color(0xFFFFDAD2),
    secondary = Color(0xFFE7BDB4),
    background = Color(0xFF1A1110),
    onBackground = Color(0xFFF1DFDB),
    surface = Color(0xFF1A1110),
    onSurface = Color(0xFFF1DFDB),
    surfaceVariant = Color(0xFF534341),
    onSurfaceVariant = Color(0xFFD8C2BE),
    outlineVariant = Color(0xFF534341),
)
