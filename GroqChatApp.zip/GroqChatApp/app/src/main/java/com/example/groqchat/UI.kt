package com.example.groqchat

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import android.content.Context
import android.content.Intent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.border
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.text.input.ImeAction

// ============================ ROOT ============================

@Composable
fun GroqApp(
    vm: ChatViewModel,
    pendingShareText: String? = null,
    onShareConsumed: () -> Unit = {},
    forceSettings: Boolean = false,
    onSettingsConsumed: () -> Unit = {},
    forceNewChat: Boolean = false,
    onNewChatConsumed: () -> Unit = {},
    forceOpenLast: Boolean = false,
    onOpenLastConsumed: () -> Unit = {},
) {
    var showSettings by rememberSaveable { mutableStateOf(vm.apiKey.isBlank()) }
    val ctx = LocalContext.current
    LaunchedEffect(forceSettings) {
        if (forceSettings) { showSettings = true; onSettingsConsumed() }
    }
    LaunchedEffect(forceNewChat) {
        if (forceNewChat) { vm.newChat(); showSettings = false; onNewChatConsumed() }
    }
    LaunchedEffect(forceOpenLast) {
        if (forceOpenLast) {
            vm.openLastChat()
            showSettings = false
            onOpenLastConsumed()
        }
    }
    LaunchedEffect(pendingShareText) {
        val t = pendingShareText ?: return@LaunchedEffect
        if (t.isNotBlank()) {
            vm.draft = t
            showSettings = false
            onShareConsumed()
            vm.status = "Shared text ready to send"
        }
    }
    LaunchedEffect(vm.status) {
        vm.status?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.status = null }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> vm.permissionResult(ok) }
    vm.pendingPermission?.let { req -> LaunchedEffect(req) { permLauncher.launch(req.permission) } }
    if (vm.locked && vm.settings.appLock) { LockScreen(vm); return }
    vm.canvasText?.let { body ->
        AlertDialog(
            onDismissRequest = { vm.closeCanvas() },
            title = { Text(vm.canvasTitle) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                    SelectionContainer {
                        Text(body, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.closeCanvas() }) { Text("Close") }
            },
            dismissButton = {
                TextButton(onClick = {
                    exportMarkdownFile(ctx, body, vm.canvasTitle)
                }) { Text("Export") }
            }
        )
    }

    if (!vm.settings.onboardingDone && vm.apiKey.isBlank()) {
        AlertDialog(
            onDismissRequest = { vm.completeOnboarding() },
            title = { Text("Welcome to Groq Chat") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. Open Settings and paste your Groq API key.")
                    Text("2. Pick a chat model (Fast / Cheap / Smart presets work too).")
                    Text("3. Send a message — or type /help for commands.")
                    Text("Optional: enable Function tools + Client web tools for web_search.")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.completeOnboarding()
                    showSettings = true
                }) { Text("Open Settings") }
            },
            dismissButton = {
                TextButton(onClick = { vm.completeOnboarding() }) { Text("Skip") }
            }
        )
    }
    vm.pendingAsk?.let { r ->
        var answer by remember(r) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Tool request: ${r.tool}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("The model is asking you for this result.", fontSize = 13.sp)
                    if (r.args.isNotBlank()) Text(r.args, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    OutlinedTextField(
                        value = answer, onValueChange = { answer = it },
                        label = { Text("Your answer") }, modifier = Modifier.fillMaxWidth(), minLines = 2
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.answerAsk(answer.ifBlank { "(no answer)" }) }) { Text("Send") } },
            dismissButton = { TextButton(onClick = { vm.answerAsk(null) }) { Text("Decline") } }
        )
    }
    vm.pendingConsent?.let { c ->
        AlertDialog(
            onDismissRequest = { vm.answerConsent(0) },
            title = { Text("Allow access?") },
            text = { Text("The assistant wants to ${DeviceTools.consentText(c.tool)}.\n\nIt will see the result and can use it in the conversation.") },
            confirmButton = {
                Row {
                    TextButton(onClick = { vm.answerConsent(2) }) { Text("Always") }
                    TextButton(onClick = { vm.answerConsent(1) }) { Text("Allow once") }
                }
            },
            dismissButton = { TextButton(onClick = { vm.answerConsent(0) }) { Text("Deny") } }
        )
    }
    vm.pendingApproval?.let { a ->
        AlertDialog(
            onDismissRequest = { vm.answerApproval(false) },
            title = { Text("Run ${a.tool}?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${a.server} wants to run this tool.")
                    if (a.args.isNotBlank()) Text(a.args.take(1500), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            },
            confirmButton = { TextButton(onClick = { vm.answerApproval(true) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { vm.answerApproval(false) }) { Text("Deny") } }
        )
    }
    BackHandler(showSettings && vm.apiKey.isNotBlank()) { showSettings = false }
    Crossfade(targetState = showSettings, label = "screen") { settingsOpen ->
        if (settingsOpen) SettingsScreen(vm) { showSettings = false } else ChatScreen(vm) { showSettings = true }
    }
}

// ============================ CHAT ============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, openSettings: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val msgs = vm.messages.toList()
    var showModels by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<String?>(null) }
    var deleteTarget by remember { mutableStateOf<ChatMeta?>(null) }
    var renameTarget by remember { mutableStateOf<ChatMeta?>(null) }
    var showQuick by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var showToolLog by remember { mutableStateOf(false) }
    var showPins by remember { mutableStateOf(false) }
    var chatSearch by remember { mutableStateOf("") }
    var findOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var findPos by remember { mutableStateOf(0) }
    var selecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var moveIds by remember { mutableStateOf<List<String>?>(null) }
    var tagTarget by remember { mutableStateOf<ChatMeta?>(null) }
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val currentMeta = vm.chats.firstOrNull { it.id == vm.currentChatId }
    val scrolledUp by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 240 }
    }
    LaunchedEffect(msgs.size, vm.currentChatId) { listState.scrollToItem(0) }

    // "Find in chat": messages are laid out newest-first, so a larger index means an older message
    val revMsgs = msgs.asReversed()
    val findTerm = findQuery.trim()
    val matchIdx = if (findOpen && findTerm.isNotEmpty()) revMsgs.indices.filter { revMsgs[it].text.contains(findTerm, ignoreCase = true) } else emptyList()
    val matchSet = matchIdx.toSet()
    LaunchedEffect(findPos, findTerm, matchIdx.size) {
        if (matchIdx.isNotEmpty()) listState.animateScrollToItem(matchIdx[findPos.coerceIn(0, matchIdx.lastIndex)])
    }

    val twoPane = isTwoPane()
    // On wide screens (tablets / foldables) keep the drawer permanently open as a side pane.
    LaunchedEffect(twoPane) {
        if (twoPane && drawerState.isClosed) drawerState.open()
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = !twoPane,
        drawerContent = {
            ModalDrawerSheet(modifier = if (twoPane) Modifier.width(vm.settings.paneWidthDp.dp.coerceIn(280.dp, 420.dp)) else Modifier) {
                Text("Chats", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 24.dp, top = 24.dp, bottom = 12.dp))
                FilledTonalButton(
                    onClick = { vm.newChat(); scope.launch { drawerState.close() } },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("New chat")
                }
                Spacer(Modifier.height(8.dp))
                var hits by remember { mutableStateOf<List<ChatHit>>(emptyList()) }
                var filter by rememberSaveable { mutableStateOf("all") }
                val searching = chatSearch.trim().length >= 2
                LaunchedEffect(chatSearch, vm.chats.size) {
                    if (!searching) { hits = emptyList() } else { delay(250); hits = vm.searchChats(chatSearch, vm.chats.toList()) }
                }
                val folders = vm.chats.map { it.folder }.filter { it.isNotBlank() }.distinct().sorted()
                val archivedCount = vm.chats.count { it.archived }
                val activeFilter = when {
                    filter.startsWith("folder:") && filter.removePrefix("folder:") !in folders -> "all"
                    filter == "archived" && archivedCount == 0 -> "all"
                    else -> filter
                }
                if (vm.chats.isNotEmpty()) OutlinedTextField(
                    value = chatSearch, onValueChange = { chatSearch = it }, singleLine = true,
                    placeholder = { Text("Search chats and messages") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                )
                if (folders.isNotEmpty() || archivedCount > 0) {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(selected = activeFilter == "all", onClick = { filter = "all" }, label = { Text("All") })
                        folders.forEach { f ->
                            FilterChip(selected = activeFilter == "folder:$f", onClick = { filter = "folder:$f" }, label = { Text(f) })
                        }
                        if (archivedCount > 0) {
                            FilterChip(selected = activeFilter == "archived", onClick = { filter = "archived" }, label = { Text("Archived ($archivedCount)") })
                        }
                    }
                }
                if (selecting) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selecting = false; selected = emptySet() }) { Icon(Icons.Default.Close, "Cancel selection") }
                        Text("${selected.size} selected", modifier = Modifier.weight(1f))
                        IconButton(enabled = selected.isNotEmpty(), onClick = { moveIds = selected.toList() }) {
                            Icon(Icons.Default.Folder, "Move to folder")
                        }
                        IconButton(
                            enabled = selected.isNotEmpty(),
                            onClick = { vm.setArchived(selected, activeFilter != "archived"); selecting = false; selected = emptySet() }
                        ) {
                            Icon(
                                if (activeFilter == "archived") Icons.Default.Unarchive else Icons.Default.Archive,
                                if (activeFilter == "archived") "Unarchive selected" else "Archive selected"
                            )
                        }
                        IconButton(
                            enabled = selected.isNotEmpty(),
                            onClick = { vm.deleteChats(selected); selecting = false; selected = emptySet() }
                        ) { Icon(Icons.Default.Delete, "Delete selected") }
                    }
                }
                val base = vm.chats.filter { c ->
                    when {
                        activeFilter == "archived" -> c.archived
                        activeFilter.startsWith("folder:") -> !c.archived && c.folder == activeFilter.removePrefix("folder:")
                        else -> !c.archived
                    }
                }
                val shown: List<ChatHit> =
                    if (searching) hits else base.sortedByDescending { it.pinned }.map { ChatHit(it, "") }
                if (vm.chats.isEmpty()) Text(
                    "Your conversations are saved here.", fontSize = 13.sp, color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                ) else if (shown.isEmpty()) Text(
                    if (searching) "No matches" else "Nothing here", fontSize = 13.sp, color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.meta.id }) { h ->
                        val c = h.meta
                        ChatRow(
                            c = c, snippet = h.snippet, current = c.id == vm.currentChatId,
                            selecting = selecting, checked = c.id in selected,
                            onClick = {
                                if (selecting) selected = if (c.id in selected) selected - c.id else selected + c.id
                                else { vm.openChat(c.id); chatSearch = ""; scope.launch { drawerState.close() } }
                            },
                            onPin = { vm.togglePin(c.id) },
                            onRename = { renameTarget = c },
                            onMove = { moveIds = listOf(c.id) },
                            onTags = { tagTarget = c },
                            onArchive = { vm.setArchived(setOf(c.id), !c.archived) },
                            onSelect = { selecting = true; selected = setOf(c.id) },
                            onDelete = { vm.deleteChats(setOf(c.id)) }
                        )
                    }
                }
                UndoBar(vm)
                HorizontalDivider()
                NavigationDrawerItem(
                    label = { Text("Settings") },
                    icon = { Icon(Icons.Default.Settings, null) },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() }; openSettings() },
                    modifier = Modifier.padding(12.dp).navigationBarsPadding()
                )
            }
        }
    ) {
        Column(Modifier.fillMaxSize().background(cs.background)) {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
                navigationIcon = {
                    if (!twoPane) {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.semantics { contentDescription = "Open chat list" }
                        ) { Icon(Icons.Default.Menu, "Chat history") }
                    }
                },
                title = {
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(cs.secondaryContainer)
                            .clickable { showModels = true }.padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            vm.activeModel.substringAfterLast('/'), fontSize = 14.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                            color = cs.onSecondaryContainer
                        )
                        Icon(Icons.Default.ArrowDropDown, "Choose model", tint = cs.onSecondaryContainer)
                    }
                },
                actions = {
                    IconButton(onClick = { showQuick = true }) { Icon(Icons.Default.Tune, "Quick settings") }
                    IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "New chat") }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "More") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Share chat") }, enabled = msgs.isNotEmpty(),
                                onClick = { menuOpen = false; shareText(ctx, vm.chatMarkdown()) }
                            )
                            DropdownMenuItem(
                                text = { Text("Copy as Markdown") }, enabled = msgs.isNotEmpty(),
                                onClick = { menuOpen = false; clipboard.setText(AnnotatedString(vm.chatMarkdown())); vm.status = "Chat copied" }
                            )
                            DropdownMenuItem(
                                text = { Text("Export Markdown file") }, enabled = msgs.isNotEmpty(),
                                onClick = { menuOpen = false; exportMarkdownFile(ctx, vm.chatMarkdown(), vm.chats.firstOrNull { it.id == vm.currentChatId }?.title ?: "chat") }
                            )
                            DropdownMenuItem(
                                text = { Text("Export PDF") }, enabled = msgs.isNotEmpty(),
                                onClick = { menuOpen = false; exportChatPdf(ctx, vm.chatMarkdown(), vm.chats.firstOrNull { it.id == vm.currentChatId }?.title ?: "chat") }
                            )
                            DropdownMenuItem(
                                text = { Text("Incognito chat") },
                                onClick = { menuOpen = false; vm.startIncognitoChat() }
                            )
                            DropdownMenuItem(
                                text = { Text(if (vm.chatPrefs.chatLocked) "Unlock this chat" else "Lock this chat") },
                                onClick = { menuOpen = false; vm.toggleChatLock() }
                            )
                            if (vm.incognito) {
                                DropdownMenuItem(
                                    text = { Text("Save incognito chat") },
                                    onClick = { menuOpen = false; vm.saveIncognitoChat() }
                                )
                                DropdownMenuItem(
                                    text = { Text("Discard incognito") },
                                    onClick = { menuOpen = false; vm.discardIncognitoChat() }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Tool call log") },
                                onClick = { menuOpen = false; showToolLog = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Pinned messages") },
                                enabled = vm.pinnedMessages().isNotEmpty(),
                                onClick = { menuOpen = false; showPins = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Summarise older messages") }, enabled = msgs.size >= 8 && !vm.busy,
                                onClick = { menuOpen = false; vm.summarizeOlder() }
                            )
                            DropdownMenuItem(
                                text = { Text("Find in chat") }, enabled = msgs.isNotEmpty(),
                                onClick = { menuOpen = false; findOpen = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Rename chat") }, enabled = currentMeta != null,
                                onClick = { menuOpen = false; renameTarget = currentMeta }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete chat") }, enabled = currentMeta != null,
                                onClick = { menuOpen = false; deleteTarget = currentMeta }
                            )
                        }
                    }
                }
            )

            if (findOpen) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = findQuery, onValueChange = { findQuery = it; findPos = 0 }, singleLine = true,
                        placeholder = { Text("Find in chat") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        if (matchIdx.isEmpty()) "0" else "${findPos.coerceIn(0, matchIdx.lastIndex) + 1}/${matchIdx.size}",
                        fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 6.dp)
                    )
                    IconButton(onClick = { if (matchIdx.isNotEmpty()) findPos = (findPos + 1) % matchIdx.size }) {
                        Icon(Icons.Default.KeyboardArrowUp, "Older match")
                    }
                    IconButton(onClick = { if (matchIdx.isNotEmpty()) findPos = (findPos - 1 + matchIdx.size) % matchIdx.size }) {
                        Icon(Icons.Default.KeyboardArrowDown, "Newer match")
                    }
                    IconButton(onClick = { findOpen = false; findQuery = ""; findPos = 0 }) { Icon(Icons.Default.Close, "Close search") }
                }
            }

            if (showModels) {
                OptionSheet(
                    title = "Model for this chat (${vm.models.size} available)",
                    options = vm.models.map { Opt(it.id, "${kindOf(it.id).label} · ${it.ctx / 1000}K context", it.owner.ifBlank { "Other" }) },
                    selected = setOf(vm.activeModel, vm.settings.sttModel, vm.settings.ttsModel),
                    onSelect = { vm.pickModel(it) },
                    onDismiss = { showModels = false }
                )
            }

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                CompositionLocalProvider(
                    LocalTextStyle provides LocalTextStyle.current.copy(fontFamily = fontFamilyOf(vm.settings.fontFamily))
                ) {
                    if (msgs.isEmpty()) {
                        EmptyState(vm)
                    } else {
                        val scale = vm.settings.fontScale
                        val compact = vm.settings.compact
                        LazyColumn(
                            modifier = Modifier.widthIn(max = 840.dp).fillMaxHeight(),
                            state = listState, reverseLayout = true,
                            contentPadding = PaddingValues(horizontal = if (compact) 10.dp else 14.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 14.dp)
                        ) {
                            val rev = msgs.asReversed()
                            items(rev.size, key = { rev[it].id }) { i ->
                                val hit = i in matchSet
                                val tint = if (matchIdx.getOrNull(findPos.coerceIn(0, (matchIdx.size - 1).coerceAtLeast(0))) == i) 1f else 0.35f
                                Box(
                                    if (hit) Modifier.clip(RoundedCornerShape(14.dp)).background(cs.tertiaryContainer.copy(alpha = tint)).padding(4.dp)
                                    else Modifier
                                ) {
                                    MessageItem(vm, rev[i], isLast = i == 0, scale = scale) { preview = it }
                                }
                            }
                        }
                    }
                }
                if (scrolledUp && msgs.isNotEmpty()) {
                    SmallFloatingActionButton(
                        onClick = { scope.launch { listState.animateScrollToItem(0) } },
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)
                    ) {
                        Icon(Icons.Default.KeyboardArrowDown, "Scroll to latest")
                    }
                }
            }
            ContextMeter(vm)
            UndoBar(vm)
            if (vm.voiceMode) VoiceBar(vm) else if (vm.searchCitations.isNotEmpty()) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                    Text("Sources", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        vm.searchCitations.forEach { c ->
                            AssistChip(
                                onClick = {
                                    try {
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.url)))
                                    } catch (_: Exception) {}
                                },
                                label = { Text(c.title.take(28), fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
            InputBar(vm)
        }
    }

    moveIds?.let { ids ->
        var name by remember(ids) { mutableStateOf(vm.chats.firstOrNull { it.id == ids.first() }?.folder.orEmpty()) }
        val existing = vm.chats.map { it.folder }.filter { it.isNotBlank() }.distinct().sorted()
        AlertDialog(
            onDismissRequest = { moveIds = null },
            title = { Text(if (ids.size == 1) "Move to folder" else "Move ${ids.size} chats") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it }, singleLine = true,
                        label = { Text("Folder name") }, modifier = Modifier.fillMaxWidth()
                    )
                    if (existing.isNotEmpty()) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            existing.forEach { f -> FilterChip(selected = name == f, onClick = { name = f }, label = { Text(f) }) }
                        }
                    }
                    Hint("Leave it empty to take the chat out of its folder.")
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.setFolder(ids, name); moveIds = null; selecting = false; selected = emptySet() }) { Text("Move") }
            },
            dismissButton = { TextButton(onClick = { moveIds = null }) { Text("Cancel") } }
        )
    }
    tagTarget?.let { c ->
        var text by remember(c.id) { mutableStateOf(c.tags) }
        AlertDialog(
            onDismissRequest = { tagTarget = null },
            title = { Text("Tags") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = text, onValueChange = { text = it },
                        label = { Text("Tags, separated by commas") }, modifier = Modifier.fillMaxWidth()
                    )
                    Hint("Tags show under the chat title and can be found with the search box.")
                }
            },
            confirmButton = { TextButton(onClick = { vm.setTags(c.id, text); tagTarget = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { tagTarget = null }) { Text("Cancel") } }
        )
    }
    preview?.let { ImagePreview(it) { preview = null } }
    if (showQuick) QuickSheet(vm, onDismiss = { showQuick = false }, openSettings = openSettings)
    
    if (showPins) {
        AlertDialog(
            onDismissRequest = { showPins = false },
            title = { Text("Pinned messages") },
            text = {
                Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                    vm.pinnedMessages().forEach { m ->
                        Text(
                            if (m.role == Role.USER) "You" else (m.model?.substringAfterLast('/') ?: "Assistant"),
                            fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary
                        )
                        Text(m.text.take(400) + if (m.text.length > 400) "…" else "", fontSize = 13.sp)
                        TextButton(onClick = { vm.togglePinMessage(m.id) }) { Text("Unpin") }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPins = false }) { Text("Close") } }
        )
    }

    if (showToolLog) {
        AlertDialog(
            onDismissRequest = { showToolLog = false },
            title = { Text("Tool call log") },
            text = {
                Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                    if (vm.toolLog.isEmpty()) Text("No tool calls yet in this session.", fontSize = 13.sp)
                    else vm.toolLog.forEach { e ->
                        Text(
                            "${if (e.ok) "✓" else "✗"} ${e.name}",
                            fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                        )
                        Text(e.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                    }
                }
            },
            confirmButton = {
                Row {
                    if (vm.toolLog.isNotEmpty()) TextButton(onClick = { vm.clearToolLog() }) { Text("Clear") }
                    TextButton(onClick = { showToolLog = false }) { Text("Close") }
                }
            }
        )
    }
    if (vm.incognito) {
        Surface(color = MaterialTheme.colorScheme.tertiaryContainer, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Incognito — not saved", modifier = Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = { vm.saveIncognitoChat() }) { Text("Save") }
                TextButton(onClick = { vm.discardIncognitoChat() }) { Text("Discard") }
            }
        }
    }

    // Section A: undo after swipe/long-press delete of a message turn
    if (vm.canUndoDelete) {
        Snackbar(
            modifier = Modifier.padding(12.dp),
            action = {
                TextButton(onClick = { vm.undoDeleteTurn() }) { Text("Undo") }
            },
            dismissAction = {
                IconButton(onClick = { vm.clearUndoDelete() }) {
                    Icon(Icons.Default.Close, contentDescription = "Dismiss")
                }
            }
        ) { Text("Message deleted") }
        LaunchedEffect(vm.canUndoDelete) {
            kotlinx.coroutines.delay(6_000)
            if (vm.canUndoDelete) vm.clearUndoDelete()
        }
    }
    renameTarget?.let { c ->
        var t by remember(c.id) { mutableStateOf(c.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename chat") },
            text = { OutlinedTextField(value = t, onValueChange = { t = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { vm.renameChat(c.id, t); renameTarget = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } }
        )
    }
    deleteTarget?.let { c ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete chat?") },
            text = { Text("“${c.title}” will be removed from this device.") },
            confirmButton = { TextButton(onClick = { vm.deleteChat(c.id); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Avatar(size: Dp = 28.dp) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(size).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
        Text("G", color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.5f).sp)
    }
}

@Composable
fun EmptyState(vm: ChatViewModel) {
    val cs = MaterialTheme.colorScheme
    val ideas = listOf(
        "💡" to "Explain how transformers work in simple terms",
        "✍️" to "Write a polite email asking for a deadline extension",
        "🐍" to "Write a Python function that checks for palindromes",
        "✈️" to "Plan a 3-day budget trip to Tokyo",
    )
    Column(
        Modifier.widthIn(max = 840.dp).fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Avatar(56.dp)
        Spacer(Modifier.height(16.dp))
        Text("How can I help?", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "Type, talk with the mic, or attach images", fontSize = 13.sp, color = cs.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
        )
        if (vm.apiKey.isBlank()) {
            Text(
                "1. Open Settings  →  2. Paste your Groq API key  →  3. Send a message",
                fontSize = 13.sp, color = cs.primary, modifier = Modifier.padding(bottom = 16.dp)
            )
        } else {
            Spacer(Modifier.height(16.dp))
        }
        ideas.forEach { (emoji, text) ->
            OutlinedCard(
                onClick = { vm.draft = text; vm.send() },
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(emoji, fontSize = 20.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(text, fontSize = 14.sp)
                }
            }
        }
    }
}

/** Messages that were folded into a summary are dimmed: still readable, no longer sent to the model. */
@Composable
fun MessageItem(vm: ChatViewModel, m: Msg, isLast: Boolean, scale: Float, onImage: (String) -> Unit) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    Box(Modifier.alpha(if (m.summarized) 0.45f else 1f)) {
        if (m.pinned) {
            Icon(
                Icons.Default.PushPin, "Pinned",
                Modifier.align(Alignment.TopEnd).padding(4.dp).size(14.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        }

        SwipeableMessage(
            messageId = m.id,
            isUser = m.role == Role.USER,
            text = m.text,
            gesturesEnabled = vm.settings.swipeGestures,
            onCopy = { clip.setText(AnnotatedString(m.text)); vm.status = "Copied" },
            onDelete = if (m.role == Role.USER) ({ vm.deleteTurn(m.id) }) else null,
            onEdit = if (m.role == Role.USER) ({ vm.editMessage(m.id) }) else null,
            onShare = { shareText(ctx, m.text) },
            onRegenerate = if (isLast && m.role == Role.ASSISTANT) ({ vm.regenerate() }) else null,
            onPin = if (m.role == Role.USER || m.role == Role.ASSISTANT) ({ vm.togglePinMessage(m.id) }) else null,
            onBranch = if (m.role == Role.USER || m.role == Role.ASSISTANT) ({ vm.branchFromMessage(m.id) }) else null,
        ) {
            MessageItemBody(vm, m, isLast, scale, onImage)
        }
    }
}

@Composable
fun MessageItemBody(vm: ChatViewModel, m: Msg, isLast: Boolean, scale: Float, onImage: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val clip = LocalClipboardManager.current
    when (m.role) {
        Role.USER -> {
            var actions by remember(m.id) { mutableStateOf(false) }
            val compact = vm.settings.compact
            Column(Modifier.fillMaxWidth().padding(start = 40.dp), horizontalAlignment = Alignment.End) {
                Surface(
                    color = cs.primaryContainer,
                    shape = RoundedCornerShape(vm.settings.bubbleRadius.dp, vm.settings.bubbleRadius.dp, 4.dp, vm.settings.bubbleRadius.dp),
                    modifier = Modifier.clickable { actions = !actions }
                ) {
                    Column(
                        Modifier.padding(horizontal = 14.dp, vertical = if (compact) 7.dp else 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (m.images.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            m.images.forEach { DataImage(it, 80.dp) { onImage(it) } }
                        }
                        m.docs.forEach {
                            Text("📄 ${it.name}", fontSize = 12.sp, color = cs.onPrimaryContainer, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (m.text.isNotBlank()) {
                            Text(m.text, color = cs.onPrimaryContainer, fontSize = (15f * scale).sp, lineHeight = (22f * scale).sp)
                        }
                    }
                }
                AnimatedVisibility(visible = actions) {
                    Row {
                        IconButton(onClick = { clip.setText(AnnotatedString(m.text)); vm.status = "Copied"; actions = false }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.ContentCopy, "Copy message", Modifier.size(20.dp))
                        }
                        IconButton(onClick = { actions = false; vm.editMessage(m.id) }, enabled = !vm.busy, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Edit, "Edit and resend", Modifier.size(20.dp))
                        }
                        IconButton(onClick = { actions = false; vm.deleteTurn(m.id) }, enabled = !vm.busy, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Delete, "Delete message and reply", Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
        Role.TOOL -> Row(Modifier.fillMaxWidth().padding(start = 38.dp)) {
            Surface(color = cs.surfaceVariant, shape = RoundedCornerShape(10.dp)) {
                Text(
                    "🔧 ${m.toolName} → ${m.text}", fontSize = 12.sp, color = cs.onSurfaceVariant,
                    maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
        Role.ASSISTANT -> AssistantItem(vm, m, isLast, scale)
        Role.SYSTEM -> if (m.summary && !m.summarized) SummaryCard(m)
    }
}

@Composable
fun AssistantItem(vm: ChatViewModel, m: Msg, isLast: Boolean, scale: Float) {
    val cs = MaterialTheme.colorScheme
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    var tryModel by remember(m.id) { mutableStateOf(false) }
    var showDiff by remember(m.id, m.variant) { mutableStateOf(false) }
    val waiting = m.text.isBlank() && m.toolCalls.isEmpty() && m.reasoning.isBlank() && vm.busy && isLast
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (vm.settings.showAvatar) Avatar()
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (m.reasoning.isNotBlank()) {
                var open by remember(m.id) { mutableStateOf(false) }
                val live = m.text.isBlank() && vm.busy && isLast
                Surface(
                    color = cs.surfaceVariant, shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().clickable { open = !open }
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Text(
                            if (live) "Thinking…" else if (open) "Thought process ▾" else "Thought process ▸",
                            fontSize = 12.sp, fontWeight = FontWeight.Medium
                        )
                        if (open || live) Text(
                            m.reasoning, fontSize = 12.sp, fontStyle = FontStyle.Italic,
                            color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
            if (m.steps.isNotEmpty()) ToolSteps(m.steps)
            if (waiting) TypingDots()
            if (m.error) {
                Surface(color = cs.errorContainer, shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(m.text, color = cs.onErrorContainer, fontSize = 14.sp)
                        if (isLast && !vm.busy) TextButton(onClick = { vm.regenerate() }) {
                            Icon(Icons.Default.Refresh, null, Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp)); Text("Retry")
                        }
                    }
                }
            } else if (m.text.isNotBlank()) {
                SelectionContainer { RichText(m.text, cs.onSurface, scale) }
            }
            if (m.variants.size > 1) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { vm.selectVariant(m.id, m.variant - 1) }, enabled = m.variant > 0 && !vm.busy,
                        modifier = Modifier.size(28.dp)
                    ) { Icon(Icons.Default.KeyboardArrowLeft, "Previous version", Modifier.size(20.dp)) }
                    Text("${m.variant + 1} / ${m.variants.size}", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    IconButton(
                        onClick = { vm.selectVariant(m.id, m.variant + 1) }, enabled = m.variant < m.variants.lastIndex && !vm.busy,
                        modifier = Modifier.size(28.dp)
                    ) { Icon(Icons.Default.KeyboardArrowRight, "Next version", Modifier.size(20.dp)) }
                    TextButton(onClick = { showDiff = !showDiff }) {
                        Text(if (showDiff) "Hide diff" else "Show diff", fontSize = 12.sp)
                    }
                }
                if (showDiff) {
                    val prev = m.variants.getOrNull((m.variant - 1).coerceAtLeast(0))?.text
                        ?: m.variants.getOrNull(0)?.text.orEmpty()
                    val cur = m.text
                    Text(
                        simpleLineDiff(prev, cur),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(cs.surfaceVariant.copy(alpha = 0.4f))
                            .padding(8.dp)
                    )
                }
            }
            m.toolCalls.forEach {
                Text("→ ${it.name}(${it.args})", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = cs.onSurfaceVariant)
            }
            if (m.text.isNotBlank() && !m.error && !(vm.busy && isLast)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { clip.setText(AnnotatedString(m.text)); vm.status = "Copied" }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.ContentCopy, "Copy", Modifier.size(20.dp))
                    }
                    IconButton(onClick = { vm.speak(m) }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            if (vm.speakingId == m.id) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                            if (vm.speakingId == m.id) "Stop speaking" else "Read aloud", Modifier.size(20.dp)
                        )
                    }
                    IconButton(onClick = { shareText(ctx, m.text) }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Share, "Share", Modifier.size(20.dp))
                    }
                    if (isLast) IconButton(onClick = { vm.regenerate() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Refresh, "Regenerate", Modifier.size(20.dp))
                    }
                    if (isLast) IconButton(onClick = { tryModel = true }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.AutoAwesome, "Answer again with another model", Modifier.size(20.dp))
                    }
                    if (tryModel) OptionSheet(
                        title = "Answer again with…",
                        options = vm.chatModels.map { Opt(it.id, "${it.ctx / 1000}K context", it.owner.ifBlank { "Other" }) },
                        selected = setOf(vm.activeModel),
                        onSelect = { vm.regenerate(it) },
                        onDismiss = { tryModel = false }
                    )
                    if (vm.settings.showMeta) {
                        Spacer(Modifier.width(6.dp))
                        Text(
                            listOfNotNull(timeLabel(m.time), m.model?.substringAfterLast('/'), m.usage).joinToString(" · "),
                            fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(vertical = 10.dp)) {
        repeat(3) { i ->
            val a by t.animateFloat(
                initialValue = 0.25f, targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(600, delayMillis = i * 150), RepeatMode.Reverse),
                label = "dot$i"
            )
            Box(Modifier.size(8.dp).alpha(a).clip(CircleShape).background(MaterialTheme.colorScheme.onSurfaceVariant))
        }
    }
}

@Composable
fun RecordingIndicator() {
    val t = rememberInfiniteTransition(label = "rec")
    val a by t.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "recAlpha"
    )
    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).alpha(a).clip(CircleShape).background(MaterialTheme.colorScheme.error))
        Spacer(Modifier.width(10.dp))
        Text("Recording… tap ■ to transcribe", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
    }
}

@Composable
fun InputBar(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    fun buzz() { if (vm.settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(3)) { vm.addImages(it) }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addDocuments(it) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = cameraUri
        if (ok && u != null) vm.addImages(listOf(u))
    }
    val voicePerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startVoiceMode() else vm.status = "Microphone permission denied"
    }
    var attachMenu by remember { mutableStateOf(false) }
    var showTemplates by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggleRecord() else vm.status = "Microphone permission denied"
    }
    fun onMic() {
        buzz()
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (vm.recording || granted) vm.toggleRecord() else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    val canSend = vm.draft.isNotBlank() || vm.attachments.isNotEmpty() || vm.docs.isNotEmpty()
    val slashMode = vm.draft.trimStart().startsWith("/")

    Surface(
        color = cs.background,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime))
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 840.dp).padding(horizontal = 10.dp, vertical = 8.dp)) {
            if (slashMode) {
                Text("Commands: /help /fast /cheap /smart /incognito /web on|off /router on|off /stop /new", fontSize = 11.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("/help", "/search on", "/remember ", "/image ", "/canvas", "/fast", "/smart").forEach { c ->
                        AssistChip(onClick = { vm.draft = c }, label = { Text(c, fontSize = 12.sp) })
                    }
                }
            }

            AnimatedVisibility(
                visible = vm.attachments.isNotEmpty(),
                enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
            ) {
                Row(
                    Modifier.padding(start = 6.dp, bottom = 8.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    vm.attachments.forEachIndexed { i, a ->
                        Box {
                            DataImage(a, 60.dp)
                            Icon(
                                Icons.Default.Close, "Remove image",
                                Modifier.align(Alignment.TopEnd).size(20.dp).clip(CircleShape)
                                    .background(cs.surface).clickable { vm.attachments.removeAt(i) }.padding(2.dp)
                            )
                        }
                    }
                }
            }
            if (vm.docs.isNotEmpty()) {
                Row(
                    Modifier.padding(start = 6.dp, bottom = 8.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    vm.docs.forEachIndexed { i, d ->
                        AssistChip(
                            onClick = { vm.docs.removeAt(i) },
                            label = { Text(d.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp)) },
                            leadingIcon = { Text("📄") },
                            trailingIcon = { Icon(Icons.Default.Close, "Remove document", Modifier.size(16.dp)) }
                        )
                    }
                }
            }
            if (showTemplates) TemplateSheet(vm) { showTemplates = false }
            Surface(shape = RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh) {
                Row(Modifier.padding(4.dp), verticalAlignment = Alignment.Bottom) {
                    Box {
                        IconButton(onClick = { attachMenu = true }, enabled = !vm.recording) { Icon(Icons.Default.AttachFile, "Attach") }
                        DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                            DropdownMenuItem(text = { Text("Photo from gallery") }, onClick = {
                                attachMenu = false
                                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            })
                            DropdownMenuItem(text = { Text("Take a photo") }, onClick = {
                                attachMenu = false
                                val dir = File(ctx.cacheDir, "camera").apply { mkdirs() }
                                val file = File(dir, "cam_${System.currentTimeMillis()}.jpg")
                                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
                                cameraUri = uri
                                camera.launch(uri)
                            })
                            DropdownMenuItem(text = { Text("Document (PDF, Word, text)") }, onClick = {
                                attachMenu = false
                                docPicker.launch(arrayOf("*/*"))
                            })
                            DropdownMenuItem(text = { Text("Prompt template…") }, onClick = { attachMenu = false; showTemplates = true })
                        }
                    }

                    Box(Modifier.weight(1f).heightIn(min = 48.dp), contentAlignment = Alignment.CenterStart) {
                        if (vm.recording) RecordingIndicator() else TextField(
                            value = vm.draft, onValueChange = { vm.draft = it },
                            modifier = Modifier.fillMaxWidth(), maxLines = 6,
                            keyboardOptions = KeyboardOptions(imeAction = if (vm.settings.enterSends) ImeAction.Send else ImeAction.Default),
                            keyboardActions = KeyboardActions(onSend = {
                    if (vm.draft.trimStart().startsWith("/")) { if (!vm.runSlashCommand(vm.draft)) vm.send() }
                    else vm.send()
                }),
                            placeholder = { Text(if (vm.transcribing) "Transcribing…" else "Message") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                disabledIndicatorColor = Color.Transparent
                            )
                        )
                    }

                    if (vm.transcribing) {
                        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        }
                    } else if (vm.recording) {
                        FilledIconButton(
                            onClick = { onMic() },
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = cs.error, contentColor = cs.onError),
                            modifier = Modifier.padding(4.dp)
                        ) { Icon(Icons.Default.Stop, "Stop recording") }
                    } else {
                        IconButton(onClick = { onMic() }) { Icon(Icons.Default.Mic, "Voice input") }
                        if (!vm.busy && vm.draft.isBlank()) IconButton(onClick = {
                            buzz()
                            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            if (granted) vm.startVoiceMode() else voicePerm.launch(Manifest.permission.RECORD_AUDIO)
                        }) { Icon(Icons.Default.Headset, "Hands-free voice mode") }
                    }

                    if (vm.busy) {
                        FilledIconButton(onClick = { vm.stop() }, modifier = Modifier.padding(4.dp)) {
                            Icon(Icons.Default.Stop, "Stop generating")
                        }
                    } else {
                        FilledIconButton(
                            onClick = {
                                buzz()
                                val editId = vm.editingMessageId
                                when {
                                    editId != null -> { vm.editUserMessage(editId, vm.draft); }
                                    vm.draft.trimStart().startsWith("/") -> {
                                        if (!vm.runSlashCommand(vm.draft)) vm.send()
                                    }
                                    else -> vm.send()
                                }
                            }, enabled = canSend && !vm.recording && !vm.transcribing,
                            modifier = Modifier.padding(4.dp)
                        ) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
                    }
                }
            }
        }
        }
    }
}

@Composable
fun ImagePreview(url: String, onDismiss: () -> Unit) {
    val bmp = remember(url) { decodeDataUrl(url, 1) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.92f)).clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            if (bmp != null) Image(
                bitmap = bmp, contentDescription = "Image preview", contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(8.dp)
            )
            IconButton(onClick = onDismiss, modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding()) {
                Icon(Icons.Default.Close, "Close", tint = Color.White)
            }
        }
    }
}

// ============================ RICH TEXT ============================

@Composable
fun RichText(text: String, color: Color, scale: Float) {
    // Defer heavy parse for very long messages so scroll stays responsive (section A performance)
    val heavy = text.length > 12_000
    var ready by remember(text) { mutableStateOf(!heavy) }
    LaunchedEffect(text) {
        if (heavy) {
            ready = false
            kotlinx.coroutines.delay(32)
            ready = true
        } else ready = true
    }
    if (!ready) {
        Text(
            text.take(800) + if (text.length > 800) "…" else "",
            color = color, fontSize = (15f * scale).sp, lineHeight = (22f * scale).sp
        )
        return
    }
    val parts = text.split("```")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEachIndexed { i, p ->
            if (i % 2 == 1) {
                val nl = p.indexOf('\n')
                val lang = if (nl >= 0) p.substring(0, nl).trim() else ""
                val code = if (nl >= 0) p.substring(nl + 1) else p
                val kind = lang.trim().lowercase()
                val closed = i < parts.lastIndex      // an unclosed block is still streaming in
                if (closed && (kind == "mermaid" || kind == "svg" || (kind == "xml" && code.trimStart().startsWith("<svg")))) {
                    DiagramBlock(if (kind == "mermaid") "mermaid" else "svg", code.trim())
                } else {
                    CodeBlock(code.trimEnd(), lang)
                }
            } else if (p.isNotBlank()) {
                MarkdownBlocks(p, color, scale)
            }
        }
    }
}

@Composable
fun CodeBlock(code: String, lang: String) {
    val clip = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val highlighted = remember(code, lang, dark) { highlightCode(code, lang, dark) }
    var expanded by remember { mutableStateOf(false) }
    var full by remember { mutableStateOf(false) }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val lines = remember(code) { code.count { it == '\n' } + 1 }
    val canExpand = lines > 13

    // While a long block is still streaming in, keep following the newest lines (unless you scrolled up).
    LaunchedEffect(vScroll) {
        var prevMax = 0
        snapshotFlow { vScroll.maxValue }.collect { max ->
            if (prevMax > 0 && max > prevMax && vScroll.value >= prevMax - 80) vScroll.scrollTo(max)
            prevMax = max
        }
    }

    Surface(
        color = cs.surfaceVariant, shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(
                Modifier.fillMaxWidth().clickable(enabled = canExpand) { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    lang.ifBlank { "code" } + if (canExpand) " · $lines lines" else "",
                    fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f)
                )
                if (canExpand) IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(28.dp)) {
                    Icon(
                        if (expanded) Icons.Default.UnfoldLess else Icons.Default.UnfoldMore,
                        if (expanded) "Collapse code" else "Expand code", Modifier.size(16.dp)
                    )
                }
                IconButton(onClick = { full = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Fullscreen, "Full screen", Modifier.size(16.dp))
                }
                IconButton(onClick = { clip.setText(AnnotatedString(code)) }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.ContentCopy, "Copy code", Modifier.size(15.dp))
                }
            }
            if (full) FullscreenCode(lang.ifBlank { "code" }, highlighted, code) { full = false }
            ScrollBox(expanded, 240.dp, vScroll, hScroll) {
                Text(
                    highlighted, fontFamily = FontFamily.Monospace, fontSize = 12.5.sp, lineHeight = 18.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
        }
    }
}

@Composable
fun DataImage(url: String, size: Dp, onClick: (() -> Unit)? = null) {
    val bmp: ImageBitmap? = remember(url) { decodeDataUrl(url, 4) }
    if (bmp != null) Image(
        bitmap = bmp, contentDescription = "Attached image", contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp)).clickable(enabled = onClick != null) { onClick?.invoke() }
    )
}

fun decodeDataUrl(url: String, sample: Int = 4): ImageBitmap? = try {
    val b = Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT)
    BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
} catch (e: Exception) { null }

// ============================ SETTINGS ============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptionSheet(
    title: String,
    options: List<Opt>,
    selected: Set<String>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var q by remember { mutableStateOf("") }
    val query = q.trim()
    val shown = options.filter { query.isEmpty() || it.id.contains(query, true) || it.group.contains(query, true) }
    val grouped = shown.groupBy { it.group }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.85f).navigationBarsPadding()) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
            if (options.size > 6) OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text("Search model or publisher") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (options.isEmpty()) Text(
                "Nothing to show yet. Save your API key in Settings to load the list.",
                modifier = Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LazyColumn(Modifier.weight(1f)) {
                grouped.forEach { (g, list) ->
                    if (g.isNotBlank()) item(key = "header_$g") {
                        Text(
                            "$g  ·  ${list.size}", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 20.dp, vertical = 6.dp)
                        )
                    }
                    items(list, key = { "$g/${it.id}" }) { o ->
                        ListItem(
                            headlineContent = { Text(o.id) },
                            supportingContent = if (o.sub.isNotBlank()) ({ Text(o.sub) }) else null,
                            trailingContent = if (o.id in selected) ({ Icon(Icons.Default.Check, "Selected") }) else null,
                            modifier = Modifier.clickable { onSelect(o.id); onDismiss() }
                        )
                    }
                }
            }
        }
    }
}

// ============================ SERVER TOOLS ============================

@Composable
fun ToolSteps(steps: List<ToolStep>) {
    val cs = MaterialTheme.colorScheme
    var open by remember(steps) { mutableStateOf(false) }
    Surface(
        color = cs.surfaceVariant, shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().clickable { open = !open }
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                "🛠 Used ${steps.size} tool step${if (steps.size == 1) "" else "s"} ${if (open) "▾" else "▸"}",
                fontSize = 12.sp, fontWeight = FontWeight.Medium
            )
            if (open) steps.forEach { st ->
                Column {
                    Text(st.title.ifBlank { st.kind }, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    if (st.detail.isNotBlank()) Text(
                        st.detail, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = cs.onSurfaceVariant,
                        maxLines = 12, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

data class McpEdit(val index: Int, val server: McpServer?, val connector: Boolean)

private val CONNECTORS = listOf(
    "Gmail" to "connector_gmail",
    "Google Calendar" to "connector_googlecalendar",
    "Google Drive" to "connector_googledrive",
)

@Composable
fun McpDialog(edit: McpEdit, onDismiss: () -> Unit, onSave: (McpServer) -> Unit) {
    val init = edit.server
    val isConn = edit.connector
    val uri = LocalUriHandler.current
    var label by remember { mutableStateOf(init?.label ?: "") }
    var url by remember { mutableStateOf(init?.url ?: "") }
    var connector by remember { mutableStateOf(init?.connector?.ifBlank { null } ?: CONNECTORS.first().second) }
    var header by remember { mutableStateOf(init?.headerName ?: "Authorization") }
    var token by remember { mutableStateOf(init?.token ?: "") }
    var desc by remember { mutableStateOf(init?.description ?: "") }
    var allowed by remember { mutableStateOf(init?.allowedTools ?: "") }
    var approval by remember { mutableStateOf(init?.approval ?: false) }
    val valid = if (isConn) token.isNotBlank() else (label.isNotBlank() && url.trim().startsWith("https://"))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isConn) "Google connector" else "MCP server") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isConn) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CONNECTORS.forEach { (name, id) ->
                            FilterChip(selected = connector == id, onClick = { connector = id }, label = { Text(name) })
                        }
                    }
                    OutlinedTextField(
                        value = token, onValueChange = { token = it }, singleLine = true,
                        label = { Text("Google OAuth access token") },
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                    )
                    Hint("Read-only access. Tokens last about an hour; create one in Google's OAuth Playground using the scope for this connector (gmail.readonly, calendar.events or drive.readonly).")
                    TextButton(onClick = { uri.openUri("https://developers.google.com/oauthplayground") }) { Text("Open OAuth Playground") }
                } else {
                    OutlinedTextField(
                        value = label, onValueChange = { label = it }, singleLine = true,
                        label = { Text("Name (e.g. Huggingface)") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = url, onValueChange = { url = it }, singleLine = true,
                        label = { Text("Server URL (https://…)") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = header, onValueChange = { header = it }, singleLine = true,
                        label = { Text("Auth header name") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = token, onValueChange = { token = it }, singleLine = true,
                        label = { Text("Token / key (optional)") },
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = desc, onValueChange = { desc = it },
                        label = { Text("What this server does (helps the model)") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = allowed, onValueChange = { allowed = it }, singleLine = true,
                        label = { Text("Allowed tools, comma-separated (optional)") }, modifier = Modifier.fillMaxWidth()
                    )
                }
                SwitchRow("Ask before each tool call", "Groq pauses and asks you to allow or deny every call this server wants to make", approval) { approval = it }
                Hint("The token is stored encrypted on this device and sent only with your requests to Groq.")
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                val name = CONNECTORS.firstOrNull { it.second == connector }?.first ?: "Connector"
                onSave(
                    McpServer(
                        label = if (isConn) name else label.trim(),
                        url = if (isConn) "" else url.trim(),
                        connector = if (isConn) connector else "",
                        headerName = header.trim().ifBlank { "Authorization" },
                        token = token.trim(), description = desc.trim(), allowedTools = allowed.trim(),
                        enabled = init?.enabled ?: true, approval = approval
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ============================ CUSTOM TOOLS ============================

data class ToolEdit(val index: Int, val tool: CustomTool?)

@Composable
fun ToolDialog(edit: ToolEdit, taken: List<String>, onDismiss: () -> Unit, onSave: (CustomTool) -> Unit) {
    val init = edit.tool
    var name by remember { mutableStateOf(init?.name ?: "") }
    var desc by remember { mutableStateOf(init?.description ?: "") }
    var params by remember { mutableStateOf(init?.params ?: "") }
    var kind by remember { mutableStateOf(init?.kind ?: "webhook") }
    var response by remember { mutableStateOf(init?.response ?: "") }
    var method by remember { mutableStateOf(init?.method ?: "GET") }
    var url by remember { mutableStateOf(init?.url ?: "") }
    var headers by remember { mutableStateOf(init?.headers ?: "") }
    val others = taken.filterIndexed { i, _ -> i != edit.index }
    val nameError = when {
        name.isBlank() -> null
        !CustomTools.NAME.matches(name) -> "Letters, numbers, _ or - only (max 64)"
        name in others || name in LocalTools.names -> "That name is already used"
        else -> null
    }
    val valid = name.isNotBlank() && nameError == null && desc.isNotBlank() && when (kind) {
        "webhook" -> url.trim().startsWith("https://")
        "static" -> response.isNotBlank()
        else -> true
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (init == null) "New tool" else "Edit tool") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name (e.g. get_weather)") },
                    isError = nameError != null, supportingText = { nameError?.let { Text(it) } },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc, onValueChange = { desc = it },
                    label = { Text("What it does (the model reads this)") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = params, onValueChange = { params = it }, minLines = 2,
                    label = { Text("Parameters, one per line") },
                    supportingText = { Text("name type[*] description\ne.g.  city string* City name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Types: string, number, integer, boolean. A * after the type means required.", fontSize = 11.sp)
                Text("When the model calls it", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("webhook" to "Webhook", "static" to "Static", "ask" to "Ask me").forEach { (k, label) ->
                        FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(label) })
                    }
                }
                when (kind) {
                    "webhook" -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("GET", "POST").forEach { m ->
                                FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m) })
                            }
                        }
                        OutlinedTextField(
                            value = url, onValueChange = { url = it }, singleLine = true,
                            label = { Text("https:// URL, e.g. …?q={{city}}") }, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = headers, onValueChange = { headers = it }, minLines = 2,
                            label = { Text("Headers, one per line (optional)") },
                            supportingText = { Text("Authorization: Bearer abc123") }, modifier = Modifier.fillMaxWidth()
                        )
                        Hint("POST sends the model's arguments as JSON. Only the first 4000 characters of the reply are returned to the model.")
                    }
                    "static" -> OutlinedTextField(
                        value = response, onValueChange = { response = it }, minLines = 2,
                        label = { Text("Result text (use {{param}})") }, modifier = Modifier.fillMaxWidth()
                    )
                    else -> Hint("A dialog will ask you to type the result each time the model calls this tool.")
                }
                Hint("Tools are stored encrypted on this device. Webhooks run from your phone, so only use URLs you trust.")
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                onSave(
                    CustomTool(
                        name = name.trim(), description = desc.trim(), params = params.trim(), kind = kind,
                        response = response, method = method, url = url.trim(), headers = headers.trim(),
                        enabled = init?.enabled ?: true
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ============================ QUICK SETTINGS / HELPERS ============================

/** "3:42 PM" for a message timestamp, or null for old messages saved before timestamps existed. */
fun timeLabel(t: Long): String? =
    if (t <= 0L) null else java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(t))

fun fontFamilyOf(key: String): FontFamily = when (key) {
    "serif" -> FontFamily.Serif
    "mono" -> FontFamily.Monospace
    else -> FontFamily.Default
}

fun exportChatPdf(ctx: Context, markdown: String, title: String) {
    try {
        val pdf = android.graphics.pdf.PdfDocument()
        val paint = android.graphics.Paint().apply { textSize = 10f; isAntiAlias = true }
        val pageWidth = 595
        val pageHeight = 842
        val margin = 40
        val lineHeight = 14f
        val lines = markdown.replace("	", "    ").lines()
        var pageNum = 1
        var y = margin.toFloat()
        var page = pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas
        for (line in lines) {
            val chunks = if (line.length <= 90) listOf(line) else line.chunked(90)
            for (chunk in chunks) {
                if (y > pageHeight - margin) {
                    pdf.finishPage(page)
                    pageNum++
                    page = pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                    canvas = page.canvas
                    y = margin.toFloat()
                }
                canvas.drawText(chunk, margin.toFloat(), y, paint)
                y += lineHeight
            }
        }
        pdf.finishPage(page)
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val safe = title.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(40).ifBlank { "chat" }
        val f = File(dir, "$safe.pdf")
        f.outputStream().use { pdf.writeTo(it) }
        pdf.close()
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Export PDF"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "PDF export failed: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

fun exportMarkdownFile(ctx: Context, markdown: String, title: String) {
    try {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val safe = title.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(40).ifBlank { "chat" }
        val f = File(dir, "$safe.md")
        f.writeText(markdown)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/markdown"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Export Markdown"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Export failed: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

fun shareText(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** The settings you change most often, one swipe away from the chat. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickSheet(vm: ChatViewModel, onDismiss: () -> Unit, openSettings: () -> Unit) {
    val s = vm.settings
    val cs = MaterialTheme.colorScheme
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("This chat", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Model presets", fontSize = 12.sp, color = cs.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("fast" to "Fast", "cheap" to "Cheap", "smart" to "Smart").forEach { (k, label) ->
                    FilterChip(
                        selected = false,
                        onClick = { vm.applyModelPreset(k); onDismiss() },
                        label = { Text(label) }
                    )
                }
            }
            Hint("These choices apply to this chat only. Defaults for new chats are in Settings.")
            Text("Model: ${vm.activeModel}", fontSize = 13.sp)

            Text("Persona", fontSize = 12.sp, color = cs.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (BUILTIN_PERSONAS + s.personas).forEach { p ->
                    FilterChip(
                        selected = vm.cfg.systemPrompt.trim() == p.prompt.trim(),
                        onClick = { vm.updateChatPrefs(vm.chatPrefs.copy(systemPrompt = p.prompt)) }, label = { Text(p.name) }
                    )
                }
            }

            Text("Creativity", fontSize = 12.sp, color = cs.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Precise" to 0.2f, "Balanced" to 0.7f, "Creative" to 1.2f).forEach { (name, v) ->
                    FilterChip(
                        selected = abs(vm.cfg.temperature - v) < 0.05f,
                        onClick = { vm.updateChatPrefs(vm.chatPrefs.copy(temperature = v)) }, label = { Text(name) }
                    )
                }
            }

            Text("Reasoning effort", fontSize = 12.sp, color = cs.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("default", "none", "low", "medium", "high").forEach { e ->
                    FilterChip(
                        selected = vm.cfg.reasoningEffort == e,
                        onClick = { vm.updateChatPrefs(vm.chatPrefs.copy(reasoningEffort = if (e == "default") "" else e)) },
                        label = { Text(e) }
                    )
                }
            }

            Text("Tool use", fontSize = 12.sp, color = cs.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Auto", "off" to "Off", "required" to "Required").forEach { (k, label) ->
                    FilterChip(selected = s.toolMode == k, onClick = { vm.update(s.copy(toolMode = k)) }, label = { Text(label) })
                }
            }

            SwitchRow("Stream responses", "Show text as it is generated", s.stream) { vm.update(s.copy(stream = it)) }
            SwitchRow("Read replies aloud", "Speaks each answer automatically", s.autoSpeak) { vm.update(s.copy(autoSpeak = it)) }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.makePrefsDefault() }, enabled = !vm.chatPrefs.isDefault, modifier = Modifier.weight(1f)) {
                    Text("Use as default")
                }
                OutlinedButton(onClick = { vm.updateChatPrefs(ChatPrefs()) }, enabled = !vm.chatPrefs.isDefault, modifier = Modifier.weight(1f)) {
                    Text("Reset this chat")
                }
            }
            TextButton(onClick = { onDismiss(); openSettings() }, modifier = Modifier.fillMaxWidth()) { Text("All settings") }
            Spacer(Modifier.height(12.dp))
        }
    }
}

// ============================ CHAT LIST ROW, UNDO, LOCK ============================

@Composable
fun ChatRow(
    c: ChatMeta, snippet: String, current: Boolean, selecting: Boolean, checked: Boolean,
    onClick: () -> Unit, onPin: () -> Unit, onRename: () -> Unit, onMove: () -> Unit, onTags: () -> Unit,
    onArchive: () -> Unit, onSelect: () -> Unit, onDelete: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 1.dp).clip(RoundedCornerShape(28.dp))
            .background(if (current && !selecting) cs.secondaryContainer else Color.Transparent)
            .clickable { onClick() }.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selecting) Checkbox(checked = checked, onCheckedChange = { onClick() })
        else if (c.pinned) Icon(Icons.Default.PushPin, "Pinned", Modifier.size(16.dp), tint = cs.primary)
        if (selecting || c.pinned) Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                c.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (current) FontWeight.SemiBold else FontWeight.Normal
            )
            val tags = c.tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" ") { "#$it" }
            val sub = listOfNotNull(
                c.folder.takeIf { it.isNotBlank() }?.let { "📁 $it" },
                tags.takeIf { it.isNotBlank() }
            ).joinToString("  ")
            if (sub.isNotBlank()) Text(sub, fontSize = 11.sp, color = cs.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (snippet.isNotBlank()) Text(
                snippet, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
        }
        if (!selecting) Box {
            IconButton(onClick = { menu = true }, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.MoreVert, "Chat options", Modifier.size(20.dp))
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(if (c.pinned) "Unpin" else "Pin") }, onClick = { menu = false; onPin() })
                DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() })
                DropdownMenuItem(text = { Text("Move to folder…") }, onClick = { menu = false; onMove() })
                DropdownMenuItem(text = { Text("Edit tags…") }, onClick = { menu = false; onTags() })
                DropdownMenuItem(text = { Text(if (c.archived) "Unarchive" else "Archive") }, onClick = { menu = false; onArchive() })
                DropdownMenuItem(text = { Text("Select multiple") }, onClick = { menu = false; onSelect() })
                DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

/** Shown after chats or message turns are deleted (with Undo). */
@Composable
fun UndoBar(vm: ChatViewModel) {
    val cs = MaterialTheme.colorScheme
    val chatTrash = vm.trash
    val msgUndo = vm.canUndoDelete
    if (chatTrash == null && !msgUndo) return
    // Auto-dismiss message undo after a few seconds
    if (msgUndo) {
        LaunchedEffect(msgUndo) {
            kotlinx.coroutines.delay(6_000)
            if (vm.canUndoDelete) vm.clearUndoDelete()
        }
    }
    Surface(
        color = cs.inverseSurface, shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 2.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                when {
                    chatTrash != null && chatTrash.metas.size == 1 -> "Chat deleted"
                    chatTrash != null -> "${chatTrash.metas.size} chats deleted"
                    else -> "Message deleted"
                },
                color = cs.inverseOnSurface, modifier = Modifier.weight(1f)
            )
            TextButton(onClick = {
                if (chatTrash != null) vm.undoDelete() else vm.undoDeleteTurn()
            }) { Text("Undo", color = cs.inversePrimary) }
        }
    }
}

@Composable
fun LockScreen(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val activity = remember(ctx) { ctx.findActivity() as? FragmentActivity }
    val canAuth = remember { AppLock.available(ctx) }
    fun unlock() {
        val a = activity ?: return
        AppLock.prompt(a) { ok -> if (ok) vm.unlock() }
    }
    LaunchedEffect(Unit) { if (canAuth) unlock() }
    Column(
        Modifier.fillMaxSize().background(cs.background).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Avatar(64.dp)
        Spacer(Modifier.height(16.dp))
        Text("Groq Chat is locked", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (canAuth) {
            Text("Unlock to see your chats", color = cs.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            Button(onClick = { unlock() }) {
                Icon(Icons.Default.Lock, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Unlock")
            }
        } else {
            Text(
                "This device no longer has a screen lock or fingerprint set up, so the app can't check who you are.",
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = { vm.update(vm.settings.copy(appLock = false)); vm.unlock() }) { Text("Turn off app lock") }
        }
    }
}

// ============================ LONG CHATS, VOICE, TEMPLATES, USAGE ============================

@Composable
fun SummaryCard(m: Msg) {
    val cs = MaterialTheme.colorScheme
    var open by remember(m.id) { mutableStateOf(false) }
    Surface(
        color = cs.tertiaryContainer.copy(alpha = 0.5f), shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().clickable { open = !open }
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(
                if (open) "Earlier messages were summarised ▾" else "Earlier messages were summarised ▸",
                fontSize = 12.sp, fontWeight = FontWeight.Medium
            )
            if (open) Text(m.text, fontSize = 13.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

private fun tokensLabel(n: Int): String = if (n >= 1000) "${n / 1000}K" else "$n"

/** Appears once a chat uses half of the model's context window. */
@Composable
fun ContextMeter(vm: ChatViewModel) {
    val w = vm.contextWindow
    if (!vm.settings.showContext || w <= 0 || vm.messages.isEmpty()) return
    val used = vm.contextUsed
    val frac = (used.toFloat() / w).coerceIn(0f, 1f)
    if (frac < 0.5f && !vm.summarizing) return
    val cs = MaterialTheme.colorScheme
    val hot = frac > 0.85f
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Context ${(frac * 100).roundToInt()}% · about ${tokensLabel(used)} of ${tokensLabel(w)} tokens",
                fontSize = 11.sp, color = if (hot) cs.error else cs.onSurfaceVariant, modifier = Modifier.weight(1f)
            )
            if (vm.summarizing) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
            else TextButton(
                onClick = { vm.summarizeOlder() }, enabled = !vm.busy,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
            ) { Text("Summarise older", fontSize = 11.sp) }
        }
        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth(), color = if (hot) cs.error else cs.primary)
    }
}

@Composable
fun VoiceBar(vm: ChatViewModel) {
    val cs = MaterialTheme.colorScheme
    Surface(color = cs.background, modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Row(
                Modifier.widthIn(max = 840.dp).fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size((28 + 28 * vm.voiceLevel).dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.25f)))
                    Icon(Icons.Default.Mic, null, tint = cs.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(vm.voiceState.ifBlank { "Voice mode" }, fontWeight = FontWeight.SemiBold)
                    Text("Speak, pause, and the answer is read aloud", fontSize = 12.sp, color = cs.onSurfaceVariant)
                }
                FilledTonalButton(onClick = { vm.stopVoiceMode() }) { Text("End") }
            }
        }
    }
}

private val TEMPLATE_VAR = Regex("\\{\\{\\s*([A-Za-z_][A-Za-z0-9_ ]*?)\\s*\\}\\}")

fun templateVars(body: String): List<String> = TEMPLATE_VAR.findAll(body).map { it.groupValues[1].trim() }.distinct().toList()

fun fillTemplate(body: String, values: Map<String, String>): String =
    TEMPLATE_VAR.replace(body) { values[it.groupValues[1].trim()].orEmpty() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplateSheet(vm: ChatViewModel, onDismiss: () -> Unit) {
    var chosen by remember { mutableStateOf<PromptTemplate?>(null) }
    val all = BUILTIN_TEMPLATES + vm.settings.templates
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.7f).navigationBarsPadding()) {
            Text("Prompt templates", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(all) { t ->
                    ListItem(
                        headlineContent = { Text(t.name) },
                        supportingContent = { Text(t.body, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                        modifier = Modifier.clickable {
                            if (templateVars(t.body).isEmpty()) {
                                vm.draft = (vm.draft.trim() + "\n\n" + t.body).trim()
                                onDismiss()
                            } else chosen = t
                        }
                    )
                }
            }
        }
    }
    chosen?.let { t ->
        val names = templateVars(t.body)
        val values = remember(t.name) { mutableStateMapOf<String, String>() }
        AlertDialog(
            onDismissRequest = { chosen = null },
            title = { Text(t.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    names.forEach { n ->
                        val long = n.lowercase() in setOf("text", "code", "email", "material", "body", "content", "notes")
                        OutlinedTextField(
                            value = values[n].orEmpty(), onValueChange = { values[n] = it },
                            label = { Text(n) }, modifier = Modifier.fillMaxWidth(),
                            singleLine = !long, minLines = if (long) 3 else 1, maxLines = if (long) 8 else 1
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.draft = (vm.draft.trim() + "\n\n" + fillTemplate(t.body, values)).trim()
                    chosen = null
                    onDismiss()
                }) { Text("Insert") }
            },
            dismissButton = { TextButton(onClick = { chosen = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun TemplateEditDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New template") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = body, onValueChange = { body = it }, minLines = 3, label = { Text("Prompt") },
                    supportingText = { Text("Use {{name}} for parts you fill in each time") }, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank() && body.isNotBlank(), onClick = { onSave(name, body) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun compactCount(n: Long): String = when {
    n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0)
    n >= 1_000 -> "%.1fK".format(n / 1_000.0)
    else -> n.toString()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsageSheet(vm: ChatViewModel, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var range by remember { mutableStateOf(0) }
    var rows by remember { mutableStateOf<List<UsageRow>>(emptyList()) }
    var reload by remember { mutableStateOf(0) }
    LaunchedEffect(range, reload) {
        val now = System.currentTimeMillis()
        val midnight = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
        rows = vm.usage(when (range) { 0 -> midnight; 1 -> now - 7L * 86_400_000L; else -> 0L })
    }
    val total = rows.sumOf { it.prompt + it.completion }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Usage", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Today", "7 days", "All time").forEachIndexed { i, label ->
                    FilterChip(selected = range == i, onClick = { range = i }, label = { Text(label) })
                }
            }
            Text(
                "${rows.sumOf { it.requests }} requests · ${compactCount(total)} tokens " +
                    "(${compactCount(rows.sumOf { it.prompt })} in, ${compactCount(rows.sumOf { it.completion })} out)",
                fontWeight = FontWeight.Medium
            )
            vm.lastRate?.let { Text("Last response: $it", fontSize = 12.sp, color = cs.onSurfaceVariant) }
            if (rows.isEmpty()) Hint("Nothing recorded for this period yet.")
            rows.forEach { r ->
                val t = r.prompt + r.completion
                val speed = if (r.ms > 0 && r.completion > 0) "${(r.completion * 1000.0 / r.ms).roundToInt()} tok/s" else "–"
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row {
                        Text(r.model.substringAfterLast('/'), modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${compactCount(t)} tokens", fontSize = 13.sp, color = cs.primary)
                    }
                    LinearProgressIndicator(progress = { if (total > 0) t.toFloat() / total else 0f }, modifier = Modifier.fillMaxWidth())
                    Text(
                        "${r.requests} requests · ${compactCount(r.prompt)} in · ${compactCount(r.completion)} out · $speed",
                        fontSize = 11.sp, color = cs.onSurfaceVariant
                    )
                }
            }
            OutlinedButton(onClick = { vm.clearUsage(); rows = emptyList(); reload++ }, modifier = Modifier.fillMaxWidth()) {
                Text("Clear usage history")
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
