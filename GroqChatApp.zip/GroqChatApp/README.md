# Groq Chat (Android)

Kotlin + Jetpack Compose client for the Groq API (OpenAI-compatible, https://api.groq.com/openai/v1).

## Chat
- Streaming replies, multi-chat history (pin, rename, delete, automatic titles), edit-and-resend, regenerate, share / copy as Markdown
- Search: across all chats (titles and message text) from the drawer, and "Find in chat" with next/previous match
- Rich Markdown: tables, lists, quotes, links, images (tap to load), inline HTML subset, syntax-coloured code
- Math: real KaTeX typesetting for display formulas (downloaded and bundled by the Gradle build), text fallback otherwise
- Code, formula and diagram blocks scroll inside themselves, expand on tap, and open full screen (formulas and diagrams can be pinch-zoomed)
- Inline formulas ($x^2$) are real KaTeX, flowing inside the sentence; Mermaid diagrams and SVG images render as pictures
- Syntax colouring for Python, Kotlin/Java/JS/C-family, SQL, shell, JSON, HTML, CSS, diff, Lua/Haskell, LaTeX and more
- Vision (images), speech-to-text (Whisper), text-to-speech (Orpheus), reasoning controls

## Chat features
- Per-chat settings (model, persona, creativity, reasoning) with "use as default" / reset
- Regenerate keeps earlier versions you can flip between; "answer again with another model" compares models
- Context meter, and summarise-older-messages (manual or automatic); summarised messages stay visible but aren't sent
- Attach photos, camera shots, PDFs, Word and text files; prompt templates with {{variables}}
- Hands-free voice mode (listen, answer, read aloud); read-aloud starts with the first sentence
- Usage dashboard: tokens, speed and remaining rate limit per model

## Tools
- Device tools: battery, device info, and (opt-in, approved each time) clipboard, approximate location, calendar
- MCP: replies stream, and a server can be set to "ask before each tool call"; structured output with your own JSON schema
- Function tools: built-in device tools and your own (webhook / static / ask-me), with Auto / Off / Required / Specific modes
- Server tools: web browsing and code execution (gpt-oss), remote MCP servers and Google connectors

## Customisation
- Theme (system / light / dark), pure-black mode, Material You or 8 accent colours, serif / mono fonts, text size
- Compact mode, avatars, usage line, bubble roundness, haptics, Enter-to-send
- Personas (built-in + your own), quick-settings sheet, settings export / import (no secrets included)

## Privacy and storage
- Chats live in an SQLite database; titles, folders, tags and every message are AES-256-GCM encrypted, images are separate encrypted files
- The encryption key is protected by the Android Keystore; API keys, MCP servers and custom tools are stored encrypted too
- Optional app lock (fingerprint / face / device PIN) with a grace period, and "hide in recent apps" (blocks screenshots)
- Folders, tags, archive, multi-select, and delete with undo; old chats are migrated automatically on first start

## Build
Open in Android Studio and Run, or use the GitHub Actions workflow in `build.yml`.
First launch: paste your key from https://console.groq.com/keys in Settings.
The model you select is always the model that answers (only image requests may switch to the vision model, and the reply says so).

## Layout & devices
- Two-pane layout on tablets and foldables (screen width ≥ 600 dp): chat list stays open beside the conversation
- Permanent side drawer on large screens; modal drawer on phones

## Settings
- Search box at the top of Settings filters long section lists
- Custom HSV colour picker for accent colours beyond the presets
- Theme export / import (appearance JSON via clipboard)

## Gestures
- Swipe a message right to copy, left to delete (user) or copy (assistant)
- Long-press a message for an action menu (copy, edit, share, regenerate, delete)

## Accessibility & localisation
- `supportsRtl` enabled; layout respects right-to-left locales
- Content descriptions on key controls for TalkBack / screen readers
- User-facing strings moved into `res/values/strings.xml` for translation

## Share targets & home screen
- “Send to Groq Chat” share target for text (and image MIME) from other apps
- Home-screen widget opens a new chat
- App shortcuts: New chat, Open settings

## Recent polish (section A)
- Settings search remembered across reopen; ranked matching
- Theme import shows a preview dialog before applying
- Swipe on messages can be disabled in Chat display settings
- Undo bar after deleting a message turn (and existing chat undo)
- Clearer offline / rate-limit / invalid-key error text
- Larger message action buttons; long-press menu min height 48dp


## Structure (section A complete)
- `SettingsUi.kt` — settings screen and shared settings widgets (split out of UI.kt)
- Chat switch cancels in-flight jobs (stream, voice) and clears message-delete undo
- Tablet list width is adjustable (280–420 dp) and stored in settings
- Very long replies defer full Markdown/diagram parse for one frame for smoother scroll
