package com.example.groqchat

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.withStyle

private class Palette(
    val keyword: Color, val string: Color, val comment: Color, val number: Color,
    val function: Color, val type: Color, val literal: Color,
    val add: Color = Color(0xFF1A7F37), val del: Color = Color(0xFFCF222E),
)

private val LIGHT = Palette(
    Color(0xFFCF222E), Color(0xFF0A3069), Color(0xFF6E7781), Color(0xFF0550AE),
    Color(0xFF8250DF), Color(0xFF953800), Color(0xFF0550AE)
)
private val DARK = Palette(
    Color(0xFFFF7B72), Color(0xFFA5D6FF), Color(0xFF8B949E), Color(0xFF79C0FF),
    Color(0xFFD2A8FF), Color(0xFFFFA657), Color(0xFF79C0FF),
    add = Color(0xFF3FB950), del = Color(0xFFFF7B72)
)

private fun words(s: String): Set<String> = s.split(' ').filter { it.isNotEmpty() }.toSet()

private val C_KW = words(
    "abstract as async await break case catch class const continue data default defer do else enum export extends " +
        "extern final finally for fn fun func function go if implements import in inline interface internal is lateinit " +
        "let match mod mut namespace new object open operator override package private protected pub public return " +
        "sealed select static struct super suspend switch this throw trait try type typealias typeof unsafe use val var " +
        "void when where while with yield"
)
private val PY_KW = words(
    "and as assert async await break class continue def del elif else except finally for from global if import in is " +
        "lambda nonlocal not or pass raise return try while with yield match case self cls end begin"
)
private val SH_KW = words("if then else elif fi for while do done case esac in function select until return exit export local echo set unset source")
private val SQL_KW = words(
    "select from where group by order having insert into values update set delete create table alter drop index join " +
        "inner left right outer on as and or not null is in like limit offset distinct union all primary key foreign " +
        "references default unique case when then else end"
)
private val DASH_KW = words(
    "local function end then do while repeat until if else elseif for in return nil and or not break goto module import where " +
        "let case of data type class instance deriving newtype qualified as hiding"
)
private val LITERALS = words("true false null nil none True False None undefined NaN nullptr NULL")

private enum class Family { NONE, C, PY, SH, SQL, JSON, MARKUP, HASH, DASH, TEX, CSS, DIFF }

private fun familyOf(lang: String): Family = when (lang.trim().lowercase()) {
    "python", "py", "python3" -> Family.PY
    "bash", "sh", "shell", "zsh", "console", "terminal" -> Family.SH
    "sql", "mysql", "postgresql", "postgres", "sqlite" -> Family.SQL
    "json", "jsonc", "json5" -> Family.JSON
    "html", "xml", "svg", "xhtml" -> Family.MARKUP
    "kotlin", "kt", "java", "javascript", "js", "typescript", "ts", "jsx", "tsx", "c", "cpp", "c++", "cs", "csharp",
    "go", "golang", "rust", "rs", "swift", "dart", "php", "scala" -> Family.C
    "css", "scss", "less" -> Family.CSS
    "lua", "haskell", "hs", "elm" -> Family.DASH
    "tex", "latex" -> Family.TEX
    "diff", "patch" -> Family.DIFF
    "powershell", "ps1", "bat", "cmd" -> Family.SH
    "yaml", "yml", "toml", "ini", "properties", "dockerfile", "ruby", "rb", "r", "perl", "makefile" -> Family.HASH
    else -> Family.NONE
}

private const val C_COMMENT = """//[^\n]*|/\*[\s\S]*?(?:\*/|${'$'})"""
private const val HASH_COMMENT = """#[^\n]*"""
private const val SQL_COMMENT = """--[^\n]*|/\*[\s\S]*?(?:\*/|${'$'})"""
private const val MARKUP_COMMENT = """<!--[\s\S]*?(?:-->|${'$'})"""
private const val NEVER = """(?!)"""
private const val STRING = """\"{3}[\s\S]*?(?:\"{3}|${'$'})|'{3}[\s\S]*?(?:'{3}|${'$'})|\"(?:\\.|[^\"\\\n])*\"?|'(?:\\.|[^'\\\n])*'?|`(?:\\.|[^`\\])*`?"""
private const val NUMBER = """0[xX][0-9a-fA-F]+|\d+(?:\.\d+)?(?:[eE][+-]?\d+)?"""
private const val MARKUP_TAG = """</?[A-Za-z][\w:.-]*|/?>"""
private const val WORD = """[A-Za-z_][A-Za-z0-9_]*"""
private const val CSS_WORD = """[@A-Za-z_-][A-Za-z0-9_-]*"""
private const val CSS_TOKEN = """#[0-9a-fA-F]{3,8}\b|\d+(?:\.\d+)?(?:[a-zA-Z%]+)?"""
private const val TEX_COMMENT = """%[^\n]*"""
private const val TEX_CMD = """\\[A-Za-z@]+|\\[^A-Za-z]"""

private fun build(comment: String, third: String, word: String = WORD): Regex =
    Regex("($comment)|($STRING)|($third)|($word)")

private val REGEX: Map<Family, Regex> = mapOf(
    Family.C to build(C_COMMENT, NUMBER),
    Family.PY to build(HASH_COMMENT, NUMBER),
    Family.SH to build(HASH_COMMENT, NUMBER),
    Family.HASH to build(HASH_COMMENT, NUMBER),
    Family.SQL to build(SQL_COMMENT, NUMBER),
    Family.JSON to build(NEVER, NUMBER),
    Family.MARKUP to build(MARKUP_COMMENT, MARKUP_TAG),
    Family.DASH to build(SQL_COMMENT, NUMBER),
    Family.TEX to build(TEX_COMMENT, TEX_CMD),
    Family.CSS to build(C_COMMENT, CSS_TOKEN, CSS_WORD),
)

private fun isJsonKey(code: String, after: Int): Boolean {
    var j = after
    while (j < code.length && code[j].isWhitespace()) j++
    return j < code.length && code[j] == ':'
}

/** Lightweight syntax colouring for common languages. Unknown languages are returned unstyled. */
fun highlightCode(code: String, lang: String, dark: Boolean): AnnotatedString {
    val fam = familyOf(lang)
    val regex = REGEX[fam]
    if (fam == Family.NONE || code.length > 20000) return AnnotatedString(code)
    val p = if (dark) DARK else LIGHT
    if (fam == Family.DIFF) {
        return buildAnnotatedString {
            code.split("\n").forEachIndexed { i, line ->
                if (i > 0) append("\n")
                val c = when {
                    line.startsWith("+++") || line.startsWith("---") -> p.type
                    line.startsWith("+") -> p.add
                    line.startsWith("-") -> p.del
                    line.startsWith("@@") -> p.number
                    else -> null
                }
                if (c == null) append(line) else withStyle(SpanStyle(color = c)) { append(line) }
            }
        }
    }
    if (regex == null) return AnnotatedString(code)
    val keywords = when (fam) {
        Family.C -> C_KW
        Family.PY, Family.HASH -> PY_KW
        Family.SH -> SH_KW
        Family.SQL -> SQL_KW
        Family.DASH -> DASH_KW
        else -> emptySet()
    }
    return buildAnnotatedString {
        var last = 0
        var inTag = false
        for (m in regex.findAll(code)) {
            if (m.range.first > last) append(code.substring(last, m.range.first))
            last = m.range.last + 1
            val t = m.value
            var color: Color? = null
            var italic = false
            when {
                m.groups[1] != null -> { color = p.comment; italic = true }
                m.groups[2] != null -> color = when {
                    fam == Family.MARKUP && !inTag -> null
                    fam == Family.JSON && isJsonKey(code, m.range.last + 1) -> p.type
                    else -> p.string
                }
                m.groups[3] != null -> {
                    if (fam == Family.MARKUP) { inTag = !t.endsWith(">"); color = p.keyword } else if (fam == Family.TEX) color = p.keyword else color = p.number
                }
                else -> {
                    val w = if (fam == Family.SQL) t.lowercase() else t
                    color = when {
                        fam == Family.MARKUP -> if (inTag) p.function else null
                        fam == Family.TEX -> null
                        fam == Family.CSS -> when {
                            t.startsWith("@") -> p.keyword
                            code.getOrNull(m.range.last + 1) == ':' -> p.function
                            else -> null
                        }
                        t in LITERALS -> p.literal
                        w in keywords -> p.keyword
                        code.getOrNull(m.range.last + 1) == '(' -> p.function
                        t[0].isUpperCase() && fam != Family.SH -> p.type
                        else -> null
                    }
                }
            }
            if (color == null) append(t)
            else withStyle(SpanStyle(color = color, fontStyle = if (italic) FontStyle.Italic else null)) { append(t) }
        }
        if (last < code.length) append(code.substring(last))
    }
}
