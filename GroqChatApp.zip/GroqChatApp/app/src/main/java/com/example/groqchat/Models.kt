package com.example.groqchat

import org.json.JSONArray
import org.json.JSONObject

fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")

enum class Role(val api: String) { SYSTEM("system"), USER("user"), ASSISTANT("assistant"), TOOL("tool") }

data class ToolCall(val id: String, val name: String, val args: String)

/** One server-side tool action (built-in tool or MCP call) shown under a reply. */
data class ToolStep(val kind: String, val title: String, val detail: String)

/** A user-defined function tool. kind: "static" (fixed text), "webhook" (https call) or "ask" (you answer). */
data class CustomTool(
    val name: String,
    val description: String,
    val params: String = "",
    val kind: String = "webhook",
    val response: String = "",
    val method: String = "GET",
    val url: String = "",
    val headers: String = "",
    val enabled: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("name", name).put("description", description).put("params", params).put("kind", kind)
        .put("response", response).put("method", method).put("url", url).put("headers", headers)
        .put("enabled", enabled)

    companion object {
        fun fromJson(j: JSONObject) = CustomTool(
            name = j.str("name"), description = j.str("description"), params = j.str("params"),
            kind = j.str("kind").ifBlank { "webhook" }, response = j.str("response"),
            method = j.str("method").ifBlank { "GET" }, url = j.str("url"), headers = j.str("headers"),
            enabled = j.optBoolean("enabled", true),
        )
    }
}

/** A remote MCP server (custom URL) or a Groq Google Workspace connector. Stored encrypted. */
data class McpServer(
    val label: String,
    val url: String = "",
    val connector: String = "",
    val headerName: String = "Authorization",
    val token: String = "",
    val description: String = "",
    val allowedTools: String = "",
    val enabled: Boolean = true,
    val approval: Boolean = false,
) {
    val isConnector: Boolean get() = connector.isNotBlank()
    val usable: Boolean get() = enabled && (isConnector || url.trim().startsWith("https://"))

    fun toJson(): JSONObject = JSONObject()
        .put("label", label).put("url", url).put("connector", connector).put("headerName", headerName)
        .put("token", token).put("description", description).put("allowedTools", allowedTools)
        .put("enabled", enabled).put("approval", approval)

    /** The entry placed in the request's `tools` array. */
    fun toTool(): JSONObject {
        val t = JSONObject().put("type", "mcp").put("server_label", label).put("require_approval", if (approval) "always" else "never")
        if (isConnector) {
            t.put("connector_id", connector)
            if (token.isNotBlank()) t.put("authorization", token.trim().removePrefix("Bearer ").trim())
        } else {
            t.put("server_url", url.trim())
            if (token.isNotBlank()) {
                val name = headerName.ifBlank { "Authorization" }
                val v = if (name.equals("Authorization", true) && !token.trim().startsWith("Bearer ", true))
                    "Bearer ${token.trim()}" else token.trim()
                t.put("headers", JSONObject().put(name, v))
            }
        }
        if (description.isNotBlank()) t.put("server_description", description.trim())
        val allowed = allowedTools.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (allowed.isNotEmpty()) t.put("allowed_tools", JSONArray(allowed))
        return t
    }

    companion object {
        fun fromJson(j: JSONObject) = McpServer(
            label = j.str("label"), url = j.str("url"), connector = j.str("connector"),
            headerName = j.str("headerName").ifBlank { "Authorization" }, token = j.str("token"),
            description = j.str("description"), allowedTools = j.str("allowedTools"),
            enabled = j.optBoolean("enabled", true), approval = j.optBoolean("approval", false),
        )
    }
}

data class Msg(
    val id: Long = System.nanoTime(),
    val role: Role,
    val text: String = "",
    val images: List<String> = emptyList(),
    val reasoning: String = "",
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,
    val toolName: String? = null,
    val model: String? = null,
    val usage: String? = null,
    val error: Boolean = false,
    val steps: List<ToolStep> = emptyList(),
    val time: Long = System.currentTimeMillis(),
    val docs: List<Doc> = emptyList(),
    val variants: List<Alt> = emptyList(),
    val variant: Int = 0,
    val summary: Boolean = false,
    val summarized: Boolean = false,
) {
    fun toAlt() = Alt(text, reasoning, model, usage)

    /** The text sent to the model: the message plus the contents of any attached documents. */
    fun apiText(): String =
        if (docs.isEmpty()) text
        else text + docs.joinToString("") { "\n\n--- Attached file: ${it.name} ---\n${it.text}\n--- end of ${it.name} ---" }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("time", time).put("role", role.name).put("text", text)
        .put("images", JSONArray(images)).put("reasoning", reasoning)
        .put("toolCalls", JSONArray().also { a ->
            toolCalls.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("args", it.args)) }
        })
        .put("toolCallId", toolCallId ?: JSONObject.NULL)
        .put("toolName", toolName ?: JSONObject.NULL)
        .put("model", model ?: JSONObject.NULL)
        .put("usage", usage ?: JSONObject.NULL)
        .put("error", error)
        .put("steps", JSONArray().also { a ->
            steps.forEach { a.put(JSONObject().put("kind", it.kind).put("title", it.title).put("detail", it.detail)) }
        })
        .put("docs", JSONArray().also { a -> docs.forEach { a.put(JSONObject().put("name", it.name).put("text", it.text)) } })
        .put("variants", JSONArray().also { a ->
            variants.forEach { a.put(JSONObject().put("text", it.text).put("reasoning", it.reasoning).put("model", it.model ?: JSONObject.NULL).put("usage", it.usage ?: JSONObject.NULL)) }
        })
        .put("variant", variant).put("summary", summary).put("summarized", summarized)

    companion object {
        fun fromJson(j: JSONObject): Msg {
            val imgs = j.optJSONArray("images")
            val tcs = j.optJSONArray("toolCalls")
            return Msg(
                id = j.optLong("id", System.nanoTime()),
                time = j.optLong("time", 0L),
                role = Role.valueOf(j.optString("role", "USER")),
                text = j.str("text"),
                images = if (imgs == null) emptyList() else (0 until imgs.length()).map { imgs.getString(it) },
                reasoning = j.str("reasoning"),
                toolCalls = if (tcs == null) emptyList() else (0 until tcs.length()).map {
                    val o = tcs.getJSONObject(it); ToolCall(o.str("id"), o.str("name"), o.str("args"))
                },
                toolCallId = j.str("toolCallId").ifEmpty { null },
                toolName = j.str("toolName").ifEmpty { null },
                model = j.str("model").ifEmpty { null },
                usage = j.str("usage").ifEmpty { null },
                error = j.optBoolean("error", false),
                steps = j.optJSONArray("steps")?.let { a ->
                    (0 until a.length()).map { i ->
                        val o = a.getJSONObject(i); ToolStep(o.str("kind"), o.str("title"), o.str("detail"))
                    }
                } ?: emptyList(),
                docs = j.optJSONArray("docs")?.let { a ->
                    (0 until a.length()).map { i -> val o = a.getJSONObject(i); Doc(o.str("name"), o.str("text")) }
                } ?: emptyList(),
                variants = j.optJSONArray("variants")?.let { a ->
                    (0 until a.length()).map { i ->
                        val o = a.getJSONObject(i)
                        Alt(o.str("text"), o.str("reasoning"), o.str("model").ifEmpty { null }, o.str("usage").ifEmpty { null })
                    }
                } ?: emptyList(),
                variant = j.optInt("variant", 0),
                summary = j.optBoolean("summary", false),
                summarized = j.optBoolean("summarized", false),
            )
        }
    }
}

/** An earlier version of a reply, kept when you regenerate or try another model. */
data class Alt(val text: String, val reasoning: String, val model: String?, val usage: String?)

/** A text document attached to a message (its extracted text is what the model sees). */
data class Doc(val name: String, val text: String)

data class PromptTemplate(val name: String, val body: String)

/** Per-chat overrides of the global defaults. Blank / null / negative means "use the default". */
data class ChatPrefs(
    val model: String = "",
    val systemPrompt: String? = null,
    val temperature: Float = -1f,
    val reasoningEffort: String = "",
) {
    val isDefault: Boolean get() = model.isBlank() && systemPrompt == null && temperature < 0f && reasoningEffort.isBlank()

    fun toJson(): JSONObject = JSONObject().put("model", model).put("system", systemPrompt ?: JSONObject.NULL)
        .put("temperature", temperature.toDouble()).put("effort", reasoningEffort)

    companion object {
        fun parse(s: String): ChatPrefs = try {
            if (s.isBlank()) ChatPrefs() else {
                val j = JSONObject(s)
                ChatPrefs(
                    j.str("model"), if (j.isNull("system")) null else j.optString("system"),
                    j.optDouble("temperature", -1.0).toFloat(), j.str("effort")
                )
            }
        } catch (e: Exception) { ChatPrefs() }
    }
}

val BUILTIN_TEMPLATES = listOf(
    PromptTemplate("Summarise text", "Summarise the following text in {{style}} bullet points:\n\n{{text}}"),
    PromptTemplate("Translate", "Translate the following text into {{language}}. Keep the tone and formatting.\n\n{{text}}"),
    PromptTemplate("Explain code", "Explain what this {{language}} code does, step by step, and point out any bugs:\n\n{{code}}"),
    PromptTemplate("Rewrite", "Rewrite the following so it sounds {{tone}}:\n\n{{text}}"),
    PromptTemplate("Email reply", "Write a {{tone}} reply to this email. Key points to include: {{points}}\n\n{{email}}"),
    PromptTemplate("Study notes", "Turn the following material about {{topic}} into short study notes with 5 quiz questions at the end:\n\n{{material}}"),
)

data class ModelInfo(val id: String, val owner: String, val ctx: Int, val active: Boolean)

data class Settings(
    val chatModel: String = "llama-3.3-70b-versatile",
    val visionModel: String = "qwen/qwen3.8-27b",
    val sttModel: String = "whisper-large-v3-turbo",
    val ttsModel: String = "canopylabs/orpheus-v1-english",
    val ttsVoice: String = "troy",
    val systemPrompt: String = "You are a helpful assistant.",
    val temperature: Float = 1f,
    val topP: Float = 1f,
    val maxTokens: Int = 2048,
    val reasoningEffort: String = "default",
    val showReasoning: Boolean = false,
    val jsonMode: Boolean = false,
    val tools: Boolean = false,
    val serviceTier: String = "on_demand",
    val translate: Boolean = false,
    val sttLanguage: String = "",
    val autoSpeak: Boolean = false,
    val stream: Boolean = true,
    val theme: String = "system",
    val dynamicColor: Boolean = false,
    val fontScale: Float = 1f,
    val browserSearch: Boolean = false,
    val codeExecution: Boolean = false,
    val toolMode: String = "auto",
    val deviceToolsOff: String = "",
    val accent: String = "default",
    val amoled: Boolean = false,
    val fontFamily: String = "default",
    val compact: Boolean = false,
    val showAvatar: Boolean = true,
    val showMeta: Boolean = true,
    val enterSends: Boolean = false,
    val personas: List<Persona> = emptyList(),
    val haptics: Boolean = true,
    val bubbleRadius: Int = 20,
    val autoTitle: Boolean = true,
    val appLock: Boolean = false,
    val lockDelay: Int = 60,
    val hideRecents: Boolean = false,
    val showContext: Boolean = true,
    val autoSummarize: Boolean = false,
    val templates: List<PromptTemplate> = emptyList(),
    val sensitiveTools: Boolean = false,
    val allowedTools: String = "",
    val schemaOn: Boolean = false,
    val schemaText: String = "",
) {
    fun toJson(): JSONObject = JSONObject()
        .put("chatModel", chatModel).put("visionModel", visionModel).put("sttModel", sttModel)
        .put("ttsModel", ttsModel).put("ttsVoice", ttsVoice).put("systemPrompt", systemPrompt)
        .put("temperature", temperature.toDouble()).put("topP", topP.toDouble()).put("maxTokens", maxTokens)
        .put("reasoningEffort", reasoningEffort).put("showReasoning", showReasoning)
        .put("jsonMode", jsonMode).put("tools", tools).put("serviceTier", serviceTier)
        .put("translate", translate).put("sttLanguage", sttLanguage)
        .put("autoSpeak", autoSpeak).put("stream", stream)
        .put("theme", theme).put("dynamicColor", dynamicColor).put("fontScale", fontScale.toDouble())
        .put("browserSearch", browserSearch).put("codeExecution", codeExecution)
        .put("toolMode", toolMode).put("deviceToolsOff", deviceToolsOff)
        .put("accent", accent).put("amoled", amoled).put("fontFamily", fontFamily).put("compact", compact)
        .put("showAvatar", showAvatar).put("showMeta", showMeta).put("enterSends", enterSends)
        .put("haptics", haptics).put("bubbleRadius", bubbleRadius).put("autoTitle", autoTitle)
        .put("appLock", appLock).put("lockDelay", lockDelay).put("hideRecents", hideRecents)
        .put("showContext", showContext).put("autoSummarize", autoSummarize)
        .put("templates", JSONArray().also { a -> templates.forEach { a.put(JSONObject().put("name", it.name).put("body", it.body)) } })
        .put("sensitiveTools", sensitiveTools).put("allowedTools", allowedTools)
        .put("schemaOn", schemaOn).put("schemaText", schemaText)
        .put("personas", JSONArray().also { a ->
            personas.forEach { a.put(JSONObject().put("name", it.name).put("prompt", it.prompt)) }
        })

    companion object {
        fun fromJson(j: JSONObject): Settings {
            val d = Settings()
            return Settings(
                chatModel = j.optString("chatModel", d.chatModel),
                visionModel = j.optString("visionModel", d.visionModel),
                sttModel = j.optString("sttModel", d.sttModel),
                ttsModel = j.optString("ttsModel", d.ttsModel),
                ttsVoice = j.optString("ttsVoice", d.ttsVoice),
                systemPrompt = j.optString("systemPrompt", d.systemPrompt),
                temperature = j.optDouble("temperature", d.temperature.toDouble()).toFloat(),
                topP = j.optDouble("topP", d.topP.toDouble()).toFloat(),
                maxTokens = j.optInt("maxTokens", d.maxTokens),
                reasoningEffort = j.optString("reasoningEffort", d.reasoningEffort),
                showReasoning = j.optBoolean("showReasoning", d.showReasoning),
                jsonMode = j.optBoolean("jsonMode", d.jsonMode),
                tools = j.optBoolean("tools", d.tools),
                serviceTier = j.optString("serviceTier", d.serviceTier),
                translate = j.optBoolean("translate", d.translate),
                sttLanguage = j.optString("sttLanguage", d.sttLanguage),
                autoSpeak = j.optBoolean("autoSpeak", d.autoSpeak),
                stream = j.optBoolean("stream", d.stream),
                theme = j.optString("theme", d.theme),
                dynamicColor = j.optBoolean("dynamicColor", d.dynamicColor),
                fontScale = j.optDouble("fontScale", d.fontScale.toDouble()).toFloat(),
                browserSearch = j.optBoolean("browserSearch", d.browserSearch),
                codeExecution = j.optBoolean("codeExecution", d.codeExecution),
                toolMode = j.optString("toolMode", d.toolMode),
                deviceToolsOff = j.optString("deviceToolsOff", d.deviceToolsOff),
                accent = j.optString("accent", d.accent),
                amoled = j.optBoolean("amoled", d.amoled),
                fontFamily = j.optString("fontFamily", d.fontFamily),
                compact = j.optBoolean("compact", d.compact),
                showAvatar = j.optBoolean("showAvatar", d.showAvatar),
                showMeta = j.optBoolean("showMeta", d.showMeta),
                enterSends = j.optBoolean("enterSends", d.enterSends),
                haptics = j.optBoolean("haptics", d.haptics),
                autoTitle = j.optBoolean("autoTitle", d.autoTitle),
                appLock = j.optBoolean("appLock", d.appLock),
                lockDelay = j.optInt("lockDelay", d.lockDelay).coerceAtLeast(0),
                hideRecents = j.optBoolean("hideRecents", d.hideRecents),
                showContext = j.optBoolean("showContext", d.showContext),
                autoSummarize = j.optBoolean("autoSummarize", d.autoSummarize),
                templates = j.optJSONArray("templates")?.let { a ->
                    (0 until a.length()).map { i -> val o = a.getJSONObject(i); PromptTemplate(o.str("name"), o.str("body")) }
                } ?: emptyList(),
                sensitiveTools = j.optBoolean("sensitiveTools", d.sensitiveTools),
                allowedTools = j.optString("allowedTools", d.allowedTools),
                schemaOn = j.optBoolean("schemaOn", d.schemaOn),
                schemaText = j.optString("schemaText", d.schemaText),
                bubbleRadius = j.optInt("bubbleRadius", d.bubbleRadius).coerceIn(4, 32),
                personas = j.optJSONArray("personas")?.let { a ->
                    (0 until a.length()).map { i ->
                        val o = a.getJSONObject(i); Persona(o.str("name"), o.str("prompt"))
                    }
                } ?: emptyList(),
            )
        }
    }
}

fun isVisionModel(id: String): Boolean {
    val m = id.lowercase()
    return "qwen3.8" in m || "llama-4" in m || "scout" in m || "maverick" in m || "vision" in m
}

fun isReasoningModel(id: String): Boolean {
    val m = id.lowercase()
    return "gpt-oss" in m || "qwen3" in m || "deepseek-r1" in m
}

val ENGLISH_VOICES = listOf("autumn", "diana", "hannah", "austin", "daniel", "troy")
val ARABIC_VOICES = listOf("abdullah", "fahad", "sultan", "lulwa", "noura", "aisha")

enum class Kind(val label: String) {
    CHAT("Chat"), STT("Speech to text"), TTS("Text to speech"), SAFETY("Safety / moderation")
}

fun kindOf(id: String): Kind {
    val m = id.lowercase()
    return when {
        "whisper" in m -> Kind.STT
        "orpheus" in m || "tts" in m -> Kind.TTS
        "guard" in m -> Kind.SAFETY
        else -> Kind.CHAT
    }
}


fun isGptOss(id: String): Boolean = "gpt-oss" in id.lowercase()

/** A saved system prompt. */
data class Persona(val name: String, val prompt: String)

val BUILTIN_PERSONAS = listOf(
    Persona("Assistant", "You are a helpful assistant."),
    Persona("Coder", "You are an expert software engineer. Give correct, idiomatic code with brief explanations. Ask for missing details only when essential."),
    Persona("Writer", "You are a thoughtful writing partner. Improve clarity, tone and structure while keeping the author's voice."),
    Persona("Translator", "You translate between languages accurately and naturally. Reply with the translation only unless asked to explain."),
    Persona("Concise", "Answer as briefly as possible. Use short sentences and avoid filler."),
    Persona("Tutor", "You are a patient tutor. Explain step by step, check understanding and use simple examples."),
)

/** Models that accept response_format json_schema (Groq docs: gpt-oss and Qwen3; no streaming or tools alongside it). */
fun supportsSchema(id: String): Boolean = isGptOss(id) || "qwen3" in id.lowercase()

fun parseSchema(text: String): JSONObject? = try {
    if (text.isBlank()) null else JSONObject(text.trim())
} catch (e: Exception) { null }
