package com.example.groqchat

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val main = Handler(Looper.getMainLooper())
    private val recorder = Recorder(app)
    private val player = Player()

    var apiKey by mutableStateOf(store.apiKey)
        private set
    var settings by mutableStateOf(store.loadSettings())
        private set
    var models by mutableStateOf<List<ModelInfo>>(emptyList())
        private set
    var loadingModels by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var recording by mutableStateOf(false)
        private set
    var transcribing by mutableStateOf(false)
        private set
    var speakingId by mutableStateOf<Long?>(null)
        private set
    var draft by mutableStateOf("")
    var status by mutableStateOf<String?>(null)
    val messages = mutableStateListOf<Msg>()
    val chats = mutableStateListOf<ChatMeta>()
    val mcpServers = mutableStateListOf<McpServer>()
    val customTools = mutableStateListOf<CustomTool>()

    /** A custom "Ask me" tool waiting for the user to type the result. */
    class AskRequest(val tool: String, val args: String, val answer: CompletableDeferred<String>)
    var pendingAsk by mutableStateOf<AskRequest?>(null)
        private set
    var currentChatId by mutableStateOf("")
        private set
    val attachments = mutableStateListOf<String>()

    private val api = GroqApi { apiKey }
    private var job: Job? = null

    val chatModels: List<ModelInfo>
        get() = models.filter {
            val id = it.id.lowercase()
            !id.contains("whisper") && !id.contains("orpheus") && !id.contains("guard") && !id.contains("tts")
        }

    val owners: Map<String, String>
        get() = models.associate { it.id to it.owner }

    /** Picking any model from the full list assigns it to the matching role. */
    fun pickModel(id: String) {
        when (kindOf(id)) {
            Kind.STT -> { update(settings.copy(sttModel = id)); status = "Speech-to-text model: $id" }
            Kind.TTS -> {
                val v = if (id.contains("arabic")) ARABIC_VOICES.first() else ENGLISH_VOICES.last()
                update(settings.copy(ttsModel = id, ttsVoice = v)); status = "Text-to-speech model: $id"
            }
            else -> update(settings.copy(chatModel = id))
        }
    }

    // ---------- settings / key ----------
    fun update(s: Settings) { settings = s; store.saveSettings(s) }

    // ---------- MCP servers / connectors ----------
    private fun saveMcp(list: List<McpServer>) {
        mcpServers.clear(); mcpServers.addAll(list); store.saveMcp(list)
    }
    fun addMcp(s: McpServer) = saveMcp(mcpServers.toList() + s)
    fun updateMcp(i: Int, s: McpServer) = saveMcp(mcpServers.toMutableList().also { if (i in it.indices) it[i] = s })
    fun removeMcp(i: Int) = saveMcp(mcpServers.toMutableList().also { if (i in it.indices) it.removeAt(i) })

    // ---------- custom function tools ----------
    private fun saveTools(list: List<CustomTool>) {
        customTools.clear(); customTools.addAll(list); store.saveTools(list)
    }
    fun addTool(t: CustomTool) = saveTools(customTools.toList() + t)
    fun updateTool(i: Int, t: CustomTool) = saveTools(customTools.toMutableList().also { if (i in it.indices) it[i] = t })
    fun removeTool(i: Int) = saveTools(customTools.toMutableList().also { if (i in it.indices) it.removeAt(i) })

    private fun deviceOff(): Set<String> =
        settings.deviceToolsOff.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    private fun activeCustom(): List<CustomTool> = customTools.filter { it.enabled && CustomTools.valid(it) }

    /** Names of every function tool the model could currently call. */
    val functionToolNames: List<String>
        get() = LocalTools.names.filter { it !in deviceOff() } + activeCustom().map { it.name }

    fun answerAsk(text: String?) {
        pendingAsk?.answer?.complete(text ?: "The user declined to provide a result.")
    }

    private suspend fun askUser(t: CustomTool, args: String): String {
        val req = AskRequest(t.name, args, CompletableDeferred())
        pendingAsk = req
        try { return req.answer.await() } finally { pendingAsk = null }
    }

    private suspend fun runTool(name: String, args: String): String {
        val t = customTools.firstOrNull { it.name == name && it.enabled }
            ?: return withContext(Dispatchers.Default) { LocalTools.run(name, args) }
        return when (t.kind) {
            "static" -> CustomTools.fill(t.response, args)
            "ask" -> askUser(t, args)
            else -> CustomTools.webhook(t, args)
        }
    }

    /** First step of a reply honours Required / Specific; later steps go back to auto so the loop can finish. */
    private fun toolChoice(round: Int, names: List<String>): Any {
        val m = settings.toolMode
        if (round > 0 || names.isEmpty()) return "auto"
        return when {
            m == "required" -> "required"
            m.startsWith("fn:") && m.removePrefix("fn:") in names ->
                JSONObject().put("type", "function").put("function", JSONObject().put("name", m.removePrefix("fn:")))
            else -> "auto"
        }
    }

    fun saveKey(k: String) {
        store.apiKey = k
        apiKey = k.trim()
        refreshModels()
    }

    fun refreshModels(loud: Boolean = true) {
        if (apiKey.isBlank()) return
        viewModelScope.launch {
            loadingModels = true
            try {
                models = api.listModels()
                val chat = chatModels
                var note = ""
                if (chat.isNotEmpty() && chat.none { it.id == settings.chatModel }) {
                    val pick = chat.firstOrNull { it.id == "llama-3.3-70b-versatile" }
                        ?: chat.firstOrNull { it.id.contains("gpt-oss") } ?: chat.first()
                    note = " · ${settings.chatModel.substringAfterLast('/')} is no longer available, switched to ${pick.id.substringAfterLast('/')}"
                    update(settings.copy(chatModel = pick.id))
                }
                if (loud || note.isNotEmpty()) status = "${models.size} models loaded$note"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status = friendly(e) }
            finally { loadingModels = false }
        }
    }

    // ---------- chat ----------
    fun send() {
        val text = draft.trim()
        if (busy || (text.isEmpty() && attachments.isEmpty())) return
        if (apiKey.isBlank()) { status = "Add your Groq API key in Settings"; return }
        if (currentChatId.isEmpty()) {
            currentChatId = System.currentTimeMillis().toString()
            store.currentChatId = currentChatId
        }
        messages += Msg(role = Role.USER, text = text, images = attachments.toList())
        attachments.clear()
        draft = ""
        run()
    }

    fun stop() { job?.cancel() }

    /** Saves the open chat (if any) and switches to a blank one. Nothing is deleted. */
    fun newChat() {
        persist()
        resetView()
        currentChatId = ""
        store.currentChatId = ""
    }

    fun openChat(id: String) {
        if (id == currentChatId) return
        persist()
        resetView()
        currentChatId = id
        store.currentChatId = id
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) { store.loadChat(id) }
            if (currentChatId == id) { messages.clear(); messages.addAll(loaded) }
        }
    }

    fun deleteChat(id: String) = deleteChats(listOf(id))

    /** Takes chats out of the list at once; their data is erased for good after a few seconds unless [undoDelete] runs. */
    fun deleteChats(ids: Collection<String>) {
        val gone = chats.filter { it.id in ids }
        if (gone.isEmpty()) return
        finalizeTrash()
        if (currentChatId in ids) { resetView(); currentChatId = ""; store.currentChatId = "" }
        chats.removeAll { it.id in ids }
        viewModelScope.launch(Dispatchers.IO) { gone.forEach { store.removeMeta(it.id) } }
        val t = Trash(gone)
        trash = t
        trashJob = viewModelScope.launch { delay(7000); if (trash === t) finalizeTrash() }
    }

    fun undoDelete() {
        val t = trash ?: return
        trashJob?.cancel()
        trash = null
        val merged = (chats.toList() + t.metas).sortedByDescending { it.updated }
        chats.clear()
        chats.addAll(merged)
        viewModelScope.launch(Dispatchers.IO) { t.metas.forEach { store.saveMeta(it) } }
    }

    private fun finalizeTrash() {
        val t = trash ?: return
        trashJob?.cancel()
        trash = null
        viewModelScope.launch(Dispatchers.IO) { t.metas.forEach { store.deleteChat(it.id) } }
    }

    class Trash(val metas: List<ChatMeta>)
    var trash by mutableStateOf<Trash?>(null)
        private set
    private var trashJob: Job? = null

    private fun saveMetaAsync(m: ChatMeta) {
        viewModelScope.launch(Dispatchers.IO) { store.saveMeta(m) }
    }

    private fun editChats(ids: Collection<String>, change: (ChatMeta) -> ChatMeta) {
        for (id in ids) {
            val i = chats.indexOfFirst { it.id == id }
            if (i >= 0) { chats[i] = change(chats[i]); saveMetaAsync(chats[i]) }
        }
    }

    fun setFolder(ids: Collection<String>, folder: String) = editChats(ids) { it.copy(folder = folder.trim().take(40)) }

    fun setTags(id: String, tags: String) = editChats(listOf(id)) { m ->
        m.copy(tags = tags.split(",").map { it.trim().trimStart('#') }.filter { it.isNotEmpty() }.distinct().joinToString(", ").take(120))
    }

    fun setArchived(ids: Collection<String>, archived: Boolean) = editChats(ids) { it.copy(archived = archived) }

    // ---------- app lock ----------
    var locked by mutableStateOf(false)
        private set
    private var backgroundedAt = 0L

    fun onBackground() { backgroundedAt = SystemClock.elapsedRealtime() }

    fun onForeground() {
        if (settings.appLock && backgroundedAt > 0L &&
            SystemClock.elapsedRealtime() - backgroundedAt >= settings.lockDelay * 1000L) locked = true
        backgroundedAt = 0L
    }

    fun unlock() { locked = false }

    fun clearAllChats() {
        trashJob?.cancel()
        trash = null
        resetView()
        currentChatId = ""
        chats.clear()
        viewModelScope.launch(Dispatchers.IO) { store.deleteAllChats() }
    }

    private fun resetView() {
        job?.cancel(); player.stop(); speakingId = null
        busy = false
        messages.clear(); attachments.clear(); draft = ""
    }

    fun regenerate() {
        if (busy) return
        while (messages.isNotEmpty() && messages.last().role != Role.USER) messages.removeAt(messages.lastIndex)
        if (messages.isNotEmpty()) run()
    }

    private fun run() {
        busy = true
        val cid = currentChatId
        job = viewModelScope.launch {
            var ok = false
            try {
                var rounds = 0
                while (true) {
                    val reply = streamOne(rounds)
                    if (reply.toolCalls.isEmpty() || rounds++ >= 4) break
                    for (tc in reply.toolCalls) {
                        val result = runTool(tc.name, tc.args)
                        messages += Msg(role = Role.TOOL, text = result, toolCallId = tc.id, toolName = tc.name)
                    }
                }
                if (settings.autoSpeak) messages.lastOrNull { it.role == Role.ASSISTANT && it.text.isNotBlank() }?.let { speak(it) }
                ok = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages += Msg(role = Role.ASSISTANT, text = friendly(e), error = true)
            } finally {
                if (cid == currentChatId) { busy = false; persist(); if (ok) maybeAutoTitle(cid) }
            }
        }
    }

    private suspend fun streamOne(round: Int): Msg {
        val servers = if (settings.toolMode == "off") emptyList() else mcpServers.filter { it.usable }
        val viaResponses = servers.isNotEmpty()
        val hasImagesNow = messages.any { it.images.isNotEmpty() }
        if (round == 0 && wantsBuiltin(settings, hasImagesNow) && !isGptOss(settings.chatModel)) {
            status = "Web browsing / code execution need a gpt-oss model, so they were skipped for this reply."
        }
        val body = if (viaResponses) buildResponsesBody(servers) else buildBody(round)
        val model = body.getString("model")
        val switchNote = if (model != settings.chatModel)
            "switched from ${settings.chatModel.substringAfterLast('/')} (images)" else null
        val stream = !viaResponses && body.optBoolean("stream")
        val idx = messages.size
        messages += Msg(role = Role.ASSISTANT, model = model)
        val res = try {
            if (viaResponses) api.respond(body)
            else api.chat(body, stream) { t, r ->
                main.post { if (idx < messages.size) messages[idx] = messages[idx].copy(text = t, reasoning = r) }
            }
        } catch (e: Exception) {
            if (idx < messages.size && messages[idx].text.isEmpty() && messages[idx].reasoning.isEmpty()) messages.removeAt(idx)
            throw e
        }
        val shownReasoning = if (viaResponses && !settings.showReasoning) "" else res.reasoning
        val done = Msg(
            id = messages[idx].id, role = Role.ASSISTANT, text = res.text, reasoning = shownReasoning,
            toolCalls = res.toolCalls, model = model,
            usage = listOfNotNull(res.usage, switchNote).joinToString(" · ").ifBlank { null }, steps = res.steps
        )
        messages[idx] = done
        return done
    }

    private fun wantsBuiltin(s: Settings, hasImages: Boolean): Boolean =
        (s.browserSearch || s.codeExecution) && !hasImages && s.toolMode != "off"

    /** System prompt plus a line telling the model its real name (models often guess "GPT-4" otherwise). */
    private fun systemText(model: String): String {
        val base = settings.systemPrompt.trim()
        val short = model.substringAfterLast('/')
        val owner = owners[model]?.takeIf { it.isNotBlank() }
        val hint = "For reference: this conversation is running on the model \"$short\" (id: $model" +
            (if (owner != null) ", published by $owner" else "") + "), served through Groq. " +
            "If asked which model or AI you are, answer with this name and do not claim to be another model."
        return if (base.isEmpty()) hint else "$base\n\n$hint"
    }

    /** Always the model you selected. The only exception is a request with images on a model that cannot see them. */
    private fun effectiveModel(hasImages: Boolean): String {
        val s = settings
        return if (hasImages && !isVisionModel(s.chatModel)) s.visionModel else s.chatModel
    }

    private fun builtinTools(responses: Boolean): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        if (settings.browserSearch) out += JSONObject().put("type", "browser_search")
        if (settings.codeExecution) {
            val t = JSONObject().put("type", "code_interpreter")
            if (responses) t.put("container", JSONObject().put("type", "auto"))
            out += t
        }
        return out
    }

    /** Request for the Responses API: remote MCP servers / connectors (+ built-in tools). Not streamed. */
    private fun buildResponsesBody(servers: List<McpServer>): JSONObject {
        val s = settings
        val hasImages = messages.any { it.images.isNotEmpty() }
        val builtin = wantsBuiltin(s, hasImages) && isGptOss(s.chatModel)
        val model = effectiveModel(hasImages)

        var budget = 3
        val keep = HashSet<Long>()
        for (m in messages.asReversed()) if (m.images.isNotEmpty() && budget >= m.images.size) { keep += m.id; budget -= m.images.size }

        fun item(role: String, content: Any) =
            JSONObject().put("type", "message").put("role", role).put("content", content)

        val input = JSONArray()
        systemText(model).let { if (it.isNotBlank()) input.put(item("system", it)) }
        for (m in messages) {
            if (m.error) continue
            when (m.role) {
                Role.USER -> {
                    if (m.images.isNotEmpty() && m.id in keep) {
                        val parts = JSONArray()
                        parts.put(JSONObject().put("type", "input_text").put("text", m.text.ifBlank { "Describe this image." }))
                        m.images.forEach {
                            parts.put(JSONObject().put("type", "input_image").put("detail", "auto").put("image_url", it))
                        }
                        input.put(item("user", parts))
                    } else {
                        input.put(item("user", if (m.images.isNotEmpty()) "[image omitted] ${m.text}" else m.text))
                    }
                }
                Role.ASSISTANT -> if (m.text.isNotBlank()) input.put(item("assistant", m.text))
                else -> {}
            }
        }

        val tools = JSONArray()
        servers.forEach { tools.put(it.toTool()) }
        if (builtin) builtinTools(true).forEach { tools.put(it) }

        val b = JSONObject()
            .put("model", model).put("input", input).put("tools", tools)
            .put("temperature", s.temperature.toDouble()).put("top_p", s.topP.toDouble())
            .put("max_output_tokens", s.maxTokens).put("stream", false)
        if (isReasoningModel(model) && s.reasoningEffort != "default") {
            b.put("reasoning", JSONObject().put("effort", s.reasoningEffort))
        }
        return b
    }

    private fun buildBody(round: Int): JSONObject {
        val s = settings
        val hasImages = messages.any { it.images.isNotEmpty() }
        val builtin = wantsBuiltin(s, hasImages) && isGptOss(s.chatModel)
        val model = effectiveModel(hasImages)

        // Vision requests accept at most 3 images: keep the most recent ones.
        var budget = 3
        val keep = HashSet<Long>()
        for (m in messages.asReversed()) if (m.images.isNotEmpty() && budget >= m.images.size) { keep += m.id; budget -= m.images.size }

        val arr = JSONArray()
        systemText(model).let { if (it.isNotBlank()) arr.put(JSONObject().put("role", "system").put("content", it)) }
        for (m in messages) {
            if (m.error) continue
            when (m.role) {
                Role.USER -> {
                    if (m.images.isNotEmpty() && m.id in keep) {
                        val parts = JSONArray()
                        parts.put(JSONObject().put("type", "text").put("text", m.text.ifBlank { "Describe this image." }))
                        m.images.forEach {
                            parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", it)))
                        }
                        arr.put(JSONObject().put("role", "user").put("content", parts))
                    } else {
                        val t = if (m.images.isNotEmpty()) "[image omitted] ${m.text}" else m.text
                        arr.put(JSONObject().put("role", "user").put("content", t))
                    }
                }
                Role.ASSISTANT -> {
                    if (m.text.isBlank() && m.toolCalls.isEmpty()) continue
                    val o = JSONObject().put("role", "assistant")
                    o.put("content", if (m.text.isBlank()) JSONObject.NULL else m.text)
                    if (m.toolCalls.isNotEmpty()) {
                        val tc = JSONArray()
                        m.toolCalls.forEach {
                            tc.put(JSONObject().put("id", it.id).put("type", "function")
                                .put("function", JSONObject().put("name", it.name).put("arguments", it.args)))
                        }
                        o.put("tool_calls", tc)
                    }
                    arr.put(o)
                }
                Role.TOOL -> arr.put(JSONObject().put("role", "tool").put("tool_call_id", m.toolCallId).put("name", m.toolName ?: "").put("content", m.text))
                Role.SYSTEM -> {}
            }
        }

        val b = JSONObject()
            .put("model", model)
            .put("messages", arr)
            .put("temperature", s.temperature.toDouble())
            .put("top_p", s.topP.toDouble())
            .put("max_completion_tokens", s.maxTokens)
            .put("stream", s.stream && !s.jsonMode)
        if (s.jsonMode) {
            b.put("response_format", JSONObject().put("type", "json_object"))
        } else if (s.toolMode != "off") {
            val tools = JSONArray()
            val fnNames = mutableListOf<String>()
            if (s.tools) {
                LocalTools.active(deviceOff()).forEach { tools.put(it); fnNames += it.getJSONObject("function").getString("name") }
                activeCustom().forEach { tools.put(CustomTools.definition(it)); fnNames += it.name }
            }
            if (builtin) builtinTools(false).forEach { tools.put(it) }
            if (tools.length() > 0) b.put("tools", tools).put("tool_choice", toolChoice(round, fnNames))
            if (builtin) b.put("stream", false)
        }
        if (s.serviceTier != "on_demand") b.put("service_tier", s.serviceTier)
        if (isReasoningModel(model)) {
            if (s.reasoningEffort != "default") b.put("reasoning_effort", s.reasoningEffort)
            if (s.showReasoning) b.put("include_reasoning", true)
        }
        return b
    }

    // ---------- images ----------
    fun addImages(uris: List<Uri>) {
        viewModelScope.launch {
            for (u in uris) {
                if (attachments.size >= 3) { status = "Max 3 images per request"; break }
                val d = withContext(Dispatchers.IO) {
                    try { uriToDataUrl(getApplication<Application>(), u) } catch (e: Exception) { null }
                }
                if (d != null) attachments += d else status = "Couldn't read image"
            }
        }
    }

    // ---------- speech to text ----------
    fun toggleRecord() {
        if (recording) {
            recording = false
            val f = recorder.stop()
            if (f != null) transcribe(f) else status = "Recording too short"
        } else {
            if (apiKey.isBlank()) { status = "Add your Groq API key in Settings"; return }
            try { recorder.start(); recording = true } catch (e: Exception) { status = "Mic error: ${e.message}" }
        }
    }

    private fun transcribe(f: File) {
        transcribing = true
        viewModelScope.launch {
            try {
                val t = api.transcribe(f, settings.sttModel, settings.sttLanguage, settings.translate)
                draft = (draft + " " + t).trim()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status = friendly(e) }
            finally { transcribing = false; f.delete() }
        }
    }

    // ---------- text to speech ----------
    fun speak(m: Msg) {
        if (speakingId == m.id) { player.stop(); speakingId = null; return }
        player.stop()
        speakingId = m.id
        viewModelScope.launch {
            try {
                val chunks = TtsText.chunks(m.text)
                val files = mutableListOf<File>()
                for ((i, c) in chunks.withIndex()) {
                    val f = File(getApplication<Application>().cacheDir, "tts_${m.id}_$i.wav")
                    api.speech(c, settings.ttsModel, settings.ttsVoice, f)
                    files += f
                    if (speakingId != m.id) { files.forEach { it.delete() }; return@launch }
                }
                if (files.isEmpty()) speakingId = null
                else player.playAll(files) { speakingId = null }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status = friendly(e); speakingId = null }
        }
    }

    // ---------- helpers ----------
    private fun persist() {
        val id = currentChatId
        if (id.isEmpty()) return
        // an existing chat may legitimately become empty (e.g. its first message was edited)
        if (messages.isEmpty() && chats.none { it.id == id }) return
        val snap = messages.toList()
        val old = chats.firstOrNull { it.id == id }
        val meta = (old ?: ChatMeta(id, fallbackTitle(snap), 0L)).copy(updated = System.currentTimeMillis())
        chats.removeAll { it.id == id }
        chats.add(0, meta)
        viewModelScope.launch(Dispatchers.IO) { store.saveChat(id, snap); store.saveMeta(meta) }
    }

    // ---------- chat management ----------
    fun renameChat(id: String, title: String) {
        val i = chats.indexOfFirst { it.id == id }
        if (i < 0) return
        val t = title.trim()
        if (t.isEmpty()) return
        chats[i] = chats[i].copy(title = t.take(80))
        saveMetaAsync(chats[i])
    }

    /** Removes a user message together with the reply (and tool steps) that followed it. */
    fun deleteTurn(id: Long) {
        if (busy) return
        val i = messages.indexOfFirst { it.id == id }
        if (i < 0) return
        var end = i + 1
        while (end < messages.size && messages[end].role != Role.USER) end++
        repeat(end - i) { messages.removeAt(i) }
        if (messages.isEmpty()) deleteChat(currentChatId) else persist()
    }

    /** Puts a user message (and its images) back into the input box and drops it and everything after it. */
    fun editMessage(id: Long) {
        if (busy) return
        val i = messages.indexOfFirst { it.id == id && it.role == Role.USER }
        if (i < 0) return
        val m = messages[i]
        draft = m.text
        attachments.clear()
        attachments.addAll(m.images)
        while (messages.size > i) messages.removeAt(messages.lastIndex)
        persist()
    }

    fun chatMarkdown(): String {
        val title = chats.firstOrNull { it.id == currentChatId }?.title ?: "Chat"
        val sb = StringBuilder("# ").append(title).append("\n\n")
        for (m in messages) {
            when (m.role) {
                Role.USER -> {
                    sb.append("**You:** ").append(m.text)
                    if (m.images.isNotEmpty()) sb.append(" _(").append(m.images.size).append(" image(s) not included)_")
                    sb.append("\n\n")
                }
                Role.ASSISTANT -> if (m.text.isNotBlank()) {
                    sb.append("**").append(m.model?.substringAfterLast('/') ?: "Assistant").append(":** ")
                        .append(m.text).append("\n\n")
                }
                Role.TOOL -> sb.append("> 🔧 ").append(m.toolName ?: "tool").append(": ").append(m.text).append("\n\n")
                Role.SYSTEM -> {}
            }
        }
        return sb.toString().trim()
    }

    // ---------- personas (saved system prompts) ----------
    /** Settings as JSON for backup or sharing. API keys, MCP servers and custom tools are never included. */
    fun exportSettings(): String = settings.toJson().toString(2)

    fun importSettings(text: String): Boolean = try {
        val j = JSONObject(text.trim())
        if (!j.has("chatModel")) false else { update(Settings.fromJson(j)); true }
    } catch (e: Exception) { false }

    fun togglePin(id: String) {
        val i = chats.indexOfFirst { it.id == id }
        if (i < 0) return
        chats[i] = chats[i].copy(pinned = !chats[i].pinned)
        saveMetaAsync(chats[i])
    }

    /** Chats whose title or message text contains [query], with an excerpt of the first matching text. */
    suspend fun searchChats(query: String, list: List<ChatMeta>): List<ChatHit> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.length < 2) return@withContext emptyList<ChatHit>()
        list.mapNotNull { c ->
            val text = store.chatText(c.id)
            val i = text.indexOf(q, ignoreCase = true)
            if (i < 0 && !c.title.contains(q, ignoreCase = true) && !c.tags.contains(q, ignoreCase = true) && !c.folder.contains(q, ignoreCase = true)) null
            else ChatHit(c, if (i >= 0) excerpt(text, i, q.length) else "")
        }
    }

    private fun excerpt(text: String, at: Int, len: Int): String {
        val start = (at - 30).coerceAtLeast(0)
        val end = (at + len + 50).coerceAtMost(text.length)
        return (if (start > 0) "…" else "") + text.substring(start, end).replace('\n', ' ') + (if (end < text.length) "…" else "")
    }

    // ---------- automatic chat titles ----------
    private val titleTried = HashSet<String>()

    private fun fallbackTitle(list: List<Msg>): String =
        list.firstOrNull { it.role == Role.USER }?.text?.trim()?.replace("\n", " ")?.take(48)?.ifBlank { null } ?: "Image chat"

    /** After the first reply of a new chat, asks the model for a short title. Skipped if you renamed the chat. */
    private fun maybeAutoTitle(cid: String) {
        if (!settings.autoTitle || cid.isEmpty() || cid in titleTried || apiKey.isBlank()) return
        val meta = chats.firstOrNull { it.id == cid } ?: return
        val snap = messages.toList()
        if (meta.title != fallbackTitle(snap)) return
        val user = snap.firstOrNull { it.role == Role.USER }?.text.orEmpty()
        val reply = snap.firstOrNull { it.role == Role.ASSISTANT && !it.error && it.text.isNotBlank() }?.text ?: return
        titleTried += cid
        val model = settings.chatModel
        viewModelScope.launch {
            try {
                val body = JSONObject().put("model", model).put("stream", false).put("temperature", 0.3)
                    .put("max_completion_tokens", if (isReasoningModel(model)) 256 else 32)
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content",
                            "Write a very short title (at most 5 words) for this conversation. Reply with the title only: no quotes and no final punctuation."))
                        .put(JSONObject().put("role", "user").put("content",
                            "User: ${user.take(400)}\n\nAssistant: ${reply.take(400)}")))
                when {
                    isGptOss(model) -> body.put("reasoning_effort", "low")
                    "qwen3" in model.lowercase() -> body.put("reasoning_effort", "none")
                }
                val title = api.chat(body, false) { _, _ -> }.text
                    .lines().firstOrNull { it.isNotBlank() }.orEmpty()
                    .trim().trim('"', '\'', '“', '”', '.', '*', '#').trim().take(60)
                val now = chats.firstOrNull { it.id == cid }
                if (title.isNotEmpty() && now != null && now.title == fallbackTitle(snap)) renameChat(cid, title)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // a missing title is not worth bothering the user about
            }
        }
    }

    fun applyPersona(p: Persona) = update(settings.copy(systemPrompt = p.prompt))

    fun savePersona(name: String, prompt: String) {
        val n = name.trim()
        if (n.isEmpty() || prompt.isBlank()) return
        val rest = settings.personas.filter { !it.name.equals(n, ignoreCase = true) }
        update(settings.copy(personas = rest + Persona(n, prompt.trim())))
    }

    fun deletePersona(name: String) = update(settings.copy(personas = settings.personas.filter { it.name != name }))

    private fun friendly(e: Exception): String = when (e) {
        is ApiException -> when (e.code) {
            401 -> "Invalid API key (401). Check Settings."
            429 -> "Rate limit reached" + (e.retryAfter?.let { " – retry in ${it}s" } ?: "") + ". ${e.message}"
            else -> "Error ${e.code}: ${e.message}"
        }
        is IOException -> "Network error: ${e.message}"
        else -> e.message ?: e.javaClass.simpleName
    }

    override fun onCleared() {
        player.stop()
        if (recording) recorder.stop()?.delete()
    }

    init {
        mcpServers.addAll(store.loadMcp())
        customTools.addAll(store.loadTools())
        locked = settings.appLock
        viewModelScope.launch {
            // the chat list is read and decrypted off the main thread so start-up never waits on it
            val index = withContext(Dispatchers.IO) { store.loadIndex() }
            chats.addAll(index)
            val cur = store.currentChatId
            if (cur.isNotEmpty() && chats.any { it.id == cur }) {
                val loaded = withContext(Dispatchers.IO) { store.loadChat(cur) }
                if (currentChatId.isEmpty() && messages.isEmpty()) { currentChatId = cur; messages.addAll(loaded) }
            }
        }
        refreshModels(loud = false)
    }
}
