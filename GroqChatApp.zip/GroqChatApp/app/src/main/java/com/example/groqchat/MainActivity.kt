package com.example.groqchat

import android.content.Intent
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    private val vm: ChatViewModel by viewModels()
    private var pendingShareText by mutableStateOf<String?>(null)
    private var openSettingsOnLaunch by mutableStateOf(false)
    private var newChatOnLaunch by mutableStateOf(false)

    override fun onStart() {
        super.onStart()
        vm.onForeground()
    }

    override fun onStop() {
        super.onStop()
        vm.onBackground()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        enableEdgeToEdge()
        setContent {
            val st = vm.settings
            val systemDark = isSystemInDarkTheme()
            val dark = when (st.theme) {
                "dark" -> true
                "light" -> false
                else -> systemDark
            }
            val ctx = LocalContext.current
            DisposableEffect(st.hideRecents) {
                if (st.hideRecents) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                onDispose { }
            }
            val base = when {
                st.customAccent != 0 && !(Build.VERSION.SDK_INT >= 31 && st.dynamicColor) ->
                    customAccentScheme(st.customAccent, dark)
                Build.VERSION.SDK_INT >= 31 && st.dynamicColor ->
                    if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
                else -> accentScheme(st.accent, dark)
            }
            val scheme = if (dark && st.amoled) amoledScheme(base) else base
            DisposableEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT) { dark }
                )
                onDispose { }
            }
            MaterialTheme(colorScheme = scheme) {
                CompositionLocalProvider(
                    LocalTextStyle provides LocalTextStyle.current.copy(fontFamily = fontFamilyOf(st.fontFamily))
                ) {
                    Surface(Modifier.fillMaxSize()) {
                        GroqApp(
                            vm = vm,
                            pendingShareText = pendingShareText,
                            onShareConsumed = { pendingShareText = null },
                            forceSettings = openSettingsOnLaunch,
                            onSettingsConsumed = { openSettingsOnLaunch = false },
                            forceNewChat = newChatOnLaunch,
                            onNewChatConsumed = { newChatOnLaunch = false }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            Intent.ACTION_SEND -> {
                if (intent.type?.startsWith("text/") == true) {
                    pendingShareText = intent.getStringExtra(Intent.EXTRA_TEXT)
                }
                // Image shares can be handled later via attachment flow
            }
            GroqWidget.ACTION_NEW_CHAT -> newChatOnLaunch = true
            GroqWidget.ACTION_OPEN_SETTINGS -> openSettingsOnLaunch = true
        }
    }
}
