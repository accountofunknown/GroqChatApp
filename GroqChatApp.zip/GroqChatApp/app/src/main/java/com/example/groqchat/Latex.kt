package com.example.groqchat

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.em

private fun pairs(vararg parts: String): Map<String, String> =
    parts.joinToString(" ").split(' ').filter { it.isNotEmpty() }.chunked(2).associate { it[0] to it.getOrElse(1) { "" } }

private val SYMBOLS: Map<String, String> = pairs(
    "alpha α beta β gamma γ delta δ epsilon ε varepsilon ε zeta ζ eta η theta θ vartheta ϑ iota ι kappa κ lambda λ mu μ",
    "nu ν xi ξ pi π varpi ϖ rho ρ varrho ϱ sigma σ varsigma ς tau τ upsilon υ phi φ varphi φ chi χ psi ψ omega ω",
    "Gamma Γ Delta Δ Theta Θ Lambda Λ Xi Ξ Pi Π Sigma Σ Upsilon Υ Phi Φ Psi Ψ Omega Ω",
    "times × cdot · pm ± mp ∓ div ÷ ast ∗ star ⋆ circ ∘ bullet • oplus ⊕ otimes ⊗ cap ∩ cup ∪ wedge ∧ vee ∨ land ∧ lor ∨ neg ¬ lnot ¬",
    "leq ≤ le ≤ geq ≥ ge ≥ neq ≠ ne ≠ approx ≈ equiv ≡ sim ∼ simeq ≃ cong ≅ propto ∝ ll ≪ gg ≫ in ∈ notin ∉ ni ∋",
    "subset ⊂ supset ⊃ subseteq ⊆ supseteq ⊇ perp ⊥ parallel ∥ mid ∣",
    "to → rightarrow → leftarrow ← leftrightarrow ↔ Rightarrow ⇒ Leftarrow ⇐ Leftrightarrow ⇔ implies ⟹ impliedby ⟸ iff ⟺",
    "mapsto ↦ uparrow ↑ downarrow ↓ longrightarrow ⟶ longleftarrow ⟵ hookrightarrow ↪",
    "sum ∑ prod ∏ int ∫ iint ∬ iiint ∭ oint ∮ bigcup ⋃ bigcap ⋂ partial ∂ nabla ∇ infty ∞ emptyset ∅ varnothing ∅",
    "forall ∀ exists ∃ nexists ∄ therefore ∴ because ∵ angle ∠ degree ° prime ′ hbar ℏ ell ℓ Re ℜ Im ℑ aleph ℵ",
    "ldots … cdots ⋯ dots … vdots ⋮ ddots ⋱ top ⊤ bot ⊥ lceil ⌈ rceil ⌉ lfloor ⌊ rfloor ⌋ langle ⟨ rangle ⟩ dag † ddag ‡ checkmark ✓",
)

private val PAD: Set<String> = (
    "leq le geq ge neq ne approx equiv sim simeq cong propto ll gg in notin ni subset supset subseteq supseteq perp " +
        "parallel mid to rightarrow leftarrow leftrightarrow Rightarrow Leftarrow Leftrightarrow implies impliedby iff " +
        "mapsto longrightarrow longleftarrow hookrightarrow times cdot pm mp div ast circ oplus otimes cap cup wedge vee land lor"
    ).split(' ').toSet()

private val FUNCS: Set<String> = (
    "sin cos tan cot sec csc arcsin arccos arctan sinh cosh tanh coth log ln lg exp lim limsup liminf max min sup inf " +
        "det dim gcd ker deg arg Pr hom"
    ).split(' ').toSet()

private val DOUBLE_STRUCK = mapOf('R' to "ℝ", 'N' to "ℕ", 'Z' to "ℤ", 'Q' to "ℚ", 'C' to "ℂ", 'P' to "ℙ", 'H' to "ℍ")
private val ACCENTS = mapOf(
    "vec" to "\u20D7", "hat" to "\u0302", "bar" to "\u0304", "overline" to "\u0304",
    "tilde" to "\u0303", "dot" to "\u0307", "ddot" to "\u0308"
)
private val ENV_BRACKETS = mapOf(
    "pmatrix" to ("(" to ")"), "bmatrix" to ("[" to "]"), "Bmatrix" to ("{" to "}"),
    "vmatrix" to ("|" to "|"), "Vmatrix" to ("‖" to "‖"), "matrix" to ("" to ""), "smallmatrix" to ("" to "")
)
private val UPRIGHT = setOf(
    "text", "textrm", "mathrm", "mbox", "operatorname", "textit", "textsf", "mathsf", "mathtt", "mathit", "mathcal",
    "mathscr", "mathfrak"
)
private val BOLD = setOf("textbf", "mathbf", "boldsymbol", "bm")
private val NOOP = setOf(
    "left", "right", "big", "Big", "bigg", "Bigg", "bigl", "bigr", "Bigl", "Bigr", "displaystyle", "textstyle",
    "scriptstyle", "limits", "nolimits", "mathop", "not"
)

/**
 * Converts LaTeX math to styled text: Greek letters and operators become Unicode, ^ and _ become
 * raised / lowered text, fractions and roots are written linearly, matrices are written row by row.
 * It is an approximation, not a typesetter.
 */
fun latexToAnnotated(src: String): AnnotatedString {
    val nb = AnnotatedString.Builder()
    return try {
        Tex(src, nb).run()
        nb.toAnnotatedString()
    } catch (e: Exception) {
        AnnotatedString(src)
    }
}

private class Tex(private val s: String, private val b: AnnotatedString.Builder) {
    var i = 0
    var steps = 0
    var depth = 0
    var plain = false

    fun run() { seq(true) }

    private fun skipSpaces() { while (i < s.length && s[i].isWhitespace()) i++ }

    private fun peekNonSpace(): Char? {
        var j = i
        while (j < s.length && s[j].isWhitespace()) j++
        return s.getOrNull(j)
    }

    private fun seq(top: Boolean) {
        while (i < s.length) {
            if (++steps > 20000) { b.append(s.substring(i)); i = s.length; return }
            val c = s[i]
            when {
                c == '}' -> { if (!top) return; b.append(c); i++ }
                c == '{' -> group()
                c == '\\' -> command()
                c == '^' -> { i++; script(BaselineShift.Superscript) }
                c == '_' -> { i++; script(BaselineShift.Subscript) }
                c.isWhitespace() -> { if (plain) b.append(c); i++ }
                c.isLetter() && c.code < 128 -> {
                    val st = i
                    while (i < s.length && s[i].isLetter() && s[i].code < 128) i++
                    letters(s.substring(st, i))
                }
                (c == '=' || c == '<' || c == '>') && !plain -> { b.append(" $c "); i++ }
                c == '\'' -> { b.append("′"); i++ }
                c == '~' -> { b.append("\u00A0"); i++ }
                c == '&' -> { b.append(" "); i++ }
                else -> { b.append(c); i++ }
            }
        }
    }

    private fun letters(t: String) {
        if (plain) b.append(t)
        else b.withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { b.append(t) }
    }

    private fun group() {
        if (++depth > 40) { b.append(s.substring(i)); i = s.length; depth--; return }
        i++ // '{'
        seq(false)
        if (i < s.length && s[i] == '}') i++
        depth--
    }

    /** One argument: a {group}, a \command, or a single character. */
    private fun atom() {
        skipSpaces()
        if (i >= s.length) return
        when (s[i]) {
            '{' -> group()
            '\\' -> command()
            else -> {
                val c = s[i]
                i++
                if (c.isLetter() && c.code < 128) letters(c.toString()) else b.append(c)
            }
        }
    }

    private fun script(shift: BaselineShift) {
        b.withStyle(SpanStyle(baselineShift = shift, fontSize = 0.75.em)) { atom() }
    }

    private fun arg(): AnnotatedString {
        val nb = AnnotatedString.Builder()
        val t = Tex(s, nb)
        t.i = i; t.steps = steps; t.depth = depth; t.plain = plain
        t.atom()
        i = t.i; steps = t.steps
        return nb.toAnnotatedString()
    }

    private fun cell(text: String): AnnotatedString {
        val nb = AnnotatedString.Builder()
        val t = Tex(text, nb)
        t.depth = depth + 1; t.steps = steps
        if (t.depth > 40) nb.append(text) else t.run()
        steps = t.steps
        return nb.toAnnotatedString()
    }

    private fun wrapped(a: AnnotatedString) {
        if (a.text.length <= 1 || a.text.all { it.isLetterOrDigit() }) b.append(a)
        else { b.append("("); b.append(a); b.append(")") }
    }

    private fun readBraced(): String? {
        skipSpaces()
        if (i >= s.length || s[i] != '{') return null
        val e = s.indexOf('}', i)
        if (e < 0) return null
        val name = s.substring(i + 1, e)
        i = e + 1
        return name
    }

    private fun command() {
        i++ // backslash
        if (i >= s.length) { b.append("\\"); return }
        val c0 = s[i]
        if (!c0.isLetter()) {
            i++
            when (c0) {
                '\\' -> b.append("\n")
                ',' -> b.append("\u2009")
                ';', ':', ' ' -> b.append(" ")
                '!' -> {}
                '|' -> b.append("‖")
                else -> b.append(c0)
            }
            return
        }
        val st = i
        while (i < s.length && s[i].isLetter()) i++
        val name = s.substring(st, i)
        when {
            name == "frac" || name == "dfrac" || name == "tfrac" -> {
                val a = arg(); val d = arg()
                wrapped(a); b.append("/"); wrapped(d)
            }
            name == "binom" -> {
                val a = arg(); val d = arg()
                b.append("C("); b.append(a); b.append(", "); b.append(d); b.append(")")
            }
            name == "sqrt" -> {
                skipSpaces()
                var root: String? = null
                if (i < s.length && s[i] == '[') {
                    val e = s.indexOf(']', i)
                    if (e > 0) { root = s.substring(i + 1, e); i = e + 1 }
                }
                val a = arg()
                if (root != null) b.withStyle(SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = 0.75.em)) { b.append(root) }
                b.append("√")
                wrapped(a)
            }
            name in UPRIGHT -> { val old = plain; plain = true; atom(); plain = old }
            name in BOLD -> {
                val old = plain; plain = true
                b.withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { atom() }
                plain = old
            }
            name == "mathbb" -> {
                val a = arg().text
                a.forEach { ch -> b.append(DOUBLE_STRUCK[ch] ?: ch.toString()) }
            }
            name in ACCENTS -> { b.append(arg()); b.append(ACCENTS.getValue(name)) }
            name == "overset" || name == "underset" -> { val top = arg(); val base = arg(); b.append(base); b.append(top) }
            name == "pmod" -> { b.append(" (mod "); b.append(arg()); b.append(")") }
            name == "bmod" || name == "mod" -> b.append(" mod ")
            name == "quad" -> b.append("  ")
            name == "qquad" -> b.append("    ")
            name == "begin" -> { val nm = readBraced(); if (nm != null) env(nm) }
            name == "end" -> { readBraced() }
            name in NOOP -> { if (name == "left" || name == "right") { if (i < s.length && s[i] == '.') i++ } }
            name in FUNCS -> {
                b.append(name)
                val nx = peekNonSpace()
                if (nx != null && nx.isLetterOrDigit()) b.append("\u2009")
            }
            SYMBOLS.containsKey(name) -> {
                val sym = SYMBOLS.getValue(name)
                b.append(if (name in PAD && !plain) " $sym " else sym)
            }
            else -> b.append(name)
        }
    }

    private fun env(name: String) {
        val endTag = "\\end{$name}"
        val end = s.indexOf(endTag, i)
        var body = if (end >= 0) s.substring(i, end) else s.substring(i)
        i = if (end >= 0) end + endTag.length else s.length
        if (name == "array" || name == "tabular") {
            val t = body.trimStart()
            body = if (t.startsWith("{")) t.substringAfter('}') else t
        }
        val rows = body.split("\\\\").map { it.trim() }.filter { it.isNotEmpty() }
        val cells = rows.map { r -> r.split("&").map { cell(it.trim()) } }
        val br = ENV_BRACKETS[name]
        when {
            br != null || name == "array" -> {
                val open = br?.first ?: ""
                val close = br?.second ?: ""
                cells.forEachIndexed { ri, row ->
                    if (ri > 0) b.append("\n")
                    b.append(open)
                    row.forEachIndexed { ci, c -> if (ci > 0) b.append("   "); b.append(c) }
                    b.append(close)
                }
            }
            name == "cases" -> cells.forEachIndexed { ri, row ->
                if (ri > 0) b.append("\n")
                b.append(if (ri == 0) "{ " else "  ")
                row.forEachIndexed { ci, c -> if (ci > 0) b.append(",  "); b.append(c) }
            }
            else -> cells.forEachIndexed { ri, row ->
                if (ri > 0) b.append("\n")
                row.forEachIndexed { ci, c -> if (ci > 0) b.append(" "); b.append(c) }
            }
        }
    }
}
