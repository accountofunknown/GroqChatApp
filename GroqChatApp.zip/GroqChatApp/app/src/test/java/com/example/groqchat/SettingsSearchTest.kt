package com.example.groqchat

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** JVM unit smoke tests — no emulator required. */
class SettingsSearchTest {

    @Test
    fun blankQuery_showsAll() {
        assertTrue(settingsSectionVisible("", "Appearance", "Theme"))
        assertEquals(1, settingsSectionScore("", "Appearance"))
    }

    @Test
    fun exactAndPrefixScoreHigherThanWeak() {
        val exact = settingsSectionScore("theme", "theme")
        val prefix = settingsSectionScore("the", "theme")
        val weak = settingsSectionScore("xyz", "theme")
        assertTrue(exact > prefix)
        assertTrue(prefix > weak)
        assertEquals(0, weak)
    }

    @Test
    fun multiWordTokensMatch() {
        assertTrue(settingsSectionVisible("api key", "API key", "token"))
        assertTrue(settingsSectionVisible("rate", "Usage", "limits", "rate"))
        assertFalse(settingsSectionVisible("zzzznotfound", "Appearance", "Theme"))
    }
}
