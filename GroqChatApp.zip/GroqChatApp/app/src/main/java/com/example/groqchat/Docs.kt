package com.example.groqchat

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.util.zip.ZipInputStream

/** Pulls plain text out of PDFs, Word (.docx) files and text-like files so the model can read them. */
object DocReader {
    const val MAX_CHARS = 100_000
    private const val MAX_BYTES = 12_000_000

    class Result(val doc: Doc?, val error: String?)

    fun read(ctx: Context, uri: Uri): Result {
        val name = nameOf(ctx, uri)
        val mime = ctx.contentResolver.getType(uri).orEmpty()
        val lower = name.lowercase()
        return try {
            val raw = when {
                mime == "application/pdf" || lower.endsWith(".pdf") -> pdfText(ctx, uri)
                lower.endsWith(".docx") || mime.contains("wordprocessingml") -> docxText(ctx, uri)
                else -> plainText(ctx, uri)
            } ?: return Result(null, "$name: not a readable text document")
            val text = raw.trim()
            if (text.isEmpty()) return Result(null, "$name: no text found (scanned PDFs need OCR)")
            val cut = if (text.length > MAX_CHARS) text.substring(0, MAX_CHARS) + "\n[… truncated after $MAX_CHARS characters]" else text
            Result(Doc(name, cut), null)
        } catch (e: Throwable) {
            Result(null, "$name: couldn't read (${e.message ?: e.javaClass.simpleName})")
        }
    }

    private fun nameOf(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) { val n = c.getString(0); if (!n.isNullOrBlank()) return n }
            }
        } catch (e: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "document"
    }

    private fun pdfText(ctx: Context, uri: Uri): String? {
        PDFBoxResourceLoader.init(ctx.applicationContext)
        val input = ctx.contentResolver.openInputStream(uri) ?: return null
        return input.use { st -> PDDocument.load(st).use { doc -> PDFTextStripper().getText(doc) } }
    }

    private fun docxText(ctx: Context, uri: Uri): String? {
        val input = ctx.contentResolver.openInputStream(uri) ?: return null
        ZipInputStream(input).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    return xml
                        .replace("</w:p>", "\n").replace("<w:tab/>", "\t").replace("<w:br/>", "\n")
                        .replace(Regex("<[^>]+>"), "")
                        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                        .replace("&quot;", "\"").replace("&apos;", "'")
                }
                e = zip.nextEntry
            }
        }
        return null
    }

    private fun plainText(ctx: Context, uri: Uri): String? {
        val input = ctx.contentResolver.openInputStream(uri) ?: return null
        val bytes = input.use { it.readBytes() }
        if (bytes.size > MAX_BYTES) return null
        val text = bytes.toString(Charsets.UTF_8)
        val bad = text.count { it == '\uFFFD' || (it.code < 9) }
        return if (text.isNotEmpty() && bad * 50 > text.length) null else text   // binary files are rejected
    }
}
