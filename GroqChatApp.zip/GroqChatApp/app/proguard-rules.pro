
# Groq Chat — release keep rules
-keep class com.example.groqchat.** { *; }
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn com.tom_roush.**
-keep class com.tom_roush.** { *; }
