# Groq Chat (Android)
Kotlin + Jetpack Compose client for the Groq API (OpenAI-compatible, https://api.groq.com/openai/v1).

Implemented endpoints / features
- GET  /models                      model list, filtered into chat / whisper / orpheus
- POST /chat/completions            SSE streaming, multi-turn, system prompt, temperature, top_p,
                                    max_completion_tokens, service_tier, JSON mode,
                                    reasoning_effort + include_reasoning, vision (image_url, max 3),
                                    local function calling (tools / tool_calls loop)
- POST /audio/transcriptions        mic -> Whisper
- POST /audio/translations          mic -> English (whisper-large-v3)
- POST /audio/speech                Orpheus TTS (English + Saudi Arabic), chunked to 200 chars, wav
Not included: Batch, Files, Fine-tuning, Responses API (not useful in a chat UI).

Build: open in Android Studio and Run, or use the GitHub Actions workflow (build.yml).
First launch: paste your key from console.groq.com/keys in Settings.
