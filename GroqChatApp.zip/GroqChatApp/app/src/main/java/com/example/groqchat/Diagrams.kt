package com.example.groqchat

import android.content.Context
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONObject

private const val MERMAID_BASE = "https://appassets.androidplatform.net/assets/mermaid/"
private const val ASSETS_BASE = "https://appassets.androidplatform.net/assets/"

/** Mermaid is downloaded and bundled by the Gradle build (see app/build.gradle.kts). */
object MermaidAssets {
    @Volatile private var cached: Boolean? = null

    fun available(ctx: Context): Boolean {
        cached?.let { return it }
        val ok = try {
            ctx.applicationContext.assets.list("mermaid")?.contains("mermaid.min.js") == true
        } catch (e: Exception) {
            false
        }
        cached = ok
        return ok
    }
}

internal fun mermaidHtml(src: String, dark: Boolean, color: Color, interactive: Boolean): String {
    val hex = String.format("#%06X", color.toArgb() and 0xFFFFFF)
    val code = JSONObject.quote(src)
    val theme = if (dark) "dark" else "default"
    val overflow = if (interactive) "auto" else "hidden"
    val viewport = if (interactive) "width=device-width, initial-scale=1, minimum-scale=0.3, maximum-scale=8, user-scalable=yes"
    else "width=device-width, initial-scale=1, maximum-scale=1"
    return """
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="$viewport">
<script src="mermaid.min.js"></script>
<style>
html,body{margin:0;padding:0;background:transparent;overflow:$overflow;color:$hex}
#m{padding:4px;text-align:center}
#m svg{max-width:100%;height:auto}
.err{font-family:monospace;font-size:13px;white-space:pre-wrap;text-align:left;color:#d33}
</style></head><body><div id="m"></div>
<script>
var src = $code;
var el = document.getElementById('m');
function report(){ var r = el.getBoundingClientRect(); try { Android.size(Math.ceil(r.width), Math.ceil(r.height)); } catch (e) {} }
try {
  mermaid.initialize({startOnLoad: false, securityLevel: 'strict', theme: '$theme'});
  mermaid.render('diagram', src).then(function(res){ el.innerHTML = res.svg; report(); setTimeout(report, 200); })
    .catch(function(e){ el.className = 'err'; el.textContent = 'Diagram error: ' + (e && e.message ? e.message : e); report(); });
} catch (e) { el.className = 'err'; el.textContent = 'Diagram error: ' + e; report(); }
</script></body></html>
""".trimIndent()
}

/** Removes scripts, event handlers and foreign content. The preview also runs with JavaScript switched off. */
internal fun sanitizeSvg(svg: String): String = svg
    .replace(Regex("<script[\\s\\S]*?</script\\s*>", RegexOption.IGNORE_CASE), "")
    .replace(Regex("<script[^>]*/>", RegexOption.IGNORE_CASE), "")
    .replace(Regex("<foreignObject[\\s\\S]*?</foreignObject\\s*>", RegexOption.IGNORE_CASE), "")
    .replace(Regex("\\son\\w+\\s*=\\s*(\"[^\"]*\"|'[^']*')", RegexOption.IGNORE_CASE), "")
    .replace(Regex("javascript:", RegexOption.IGNORE_CASE), "")

internal fun svgHtml(svg: String, interactive: Boolean): String {
    val overflow = if (interactive) "auto" else "hidden"
    val viewport = if (interactive) "width=device-width, initial-scale=1, minimum-scale=0.3, maximum-scale=8, user-scalable=yes"
    else "width=device-width, initial-scale=1, maximum-scale=1"
    return """
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="$viewport">
<style>
html,body{margin:0;padding:0;background:transparent;overflow:$overflow}
svg{max-width:100%;height:auto;display:block;margin:0 auto}
</style></head><body>${sanitizeSvg(svg)}</body></html>
""".trimIndent()
}

/** Width / height of an SVG from its viewBox (or width and height attributes). */
internal fun svgAspect(svg: String): Float {
    val vb = Regex("viewBox\\s*=\\s*[\"']\\s*[-\\d.]+[ ,]+[-\\d.]+[ ,]+([\\d.]+)[ ,]+([\\d.]+)", RegexOption.IGNORE_CASE).find(svg)
    var w = vb?.groupValues?.get(1)?.toFloatOrNull()
    var h = vb?.groupValues?.get(2)?.toFloatOrNull()
    if (w == null || h == null || w <= 0f || h <= 0f) {
        w = Regex("\\swidth\\s*=\\s*[\"']([\\d.]+)", RegexOption.IGNORE_CASE).find(svg)?.groupValues?.get(1)?.toFloatOrNull()
        h = Regex("\\sheight\\s*=\\s*[\"']([\\d.]+)", RegexOption.IGNORE_CASE).find(svg)?.groupValues?.get(1)?.toFloatOrNull()
    }
    return if (w != null && h != null && w > 0f && h > 0f) (w / h).coerceIn(0.2f, 5f) else 1.6f
}

/** A Mermaid diagram or SVG image shown as a picture, with a switch to its source and a full-screen view. */
@Composable
fun DiagramBlock(kind: String, source: String) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val clip = LocalClipboardManager.current
    val dark = cs.background.luminance() < 0.5f
    val mermaidOk = remember { MermaidAssets.available(ctx) }
    val canRender = kind == "svg" || mermaidOk
    var showCode by remember(source) { mutableStateOf(!canRender) }
    var full by remember(source) { mutableStateOf(false) }
    var natH by remember(source) { mutableStateOf(160) }
    val isMermaid = kind == "mermaid"

    Surface(
        color = cs.surfaceVariant.copy(alpha = 0.5f), shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (isMermaid) "Mermaid diagram" else "SVG image", fontSize = 11.sp,
                    color = cs.onSurfaceVariant, modifier = Modifier.weight(1f)
                )
                if (canRender) TextButton(onClick = { showCode = !showCode }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text(if (showCode) "Preview" else "Code", fontSize = 11.sp)
                }
                if (canRender) IconButton(onClick = { full = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Fullscreen, "Full screen", Modifier.size(16.dp))
                }
                IconButton(onClick = { clip.setText(AnnotatedString(source)) }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.ContentCopy, "Copy source", Modifier.size(15.dp))
                }
            }
            if (showCode || !canRender) {
                CodeBlock(source, if (isMermaid) "mermaid" else "xml")
            } else {
                val html = remember(source, dark, kind) {
                    if (isMermaid) mermaidHtml(source, dark, cs.onSurface, false) else svgHtml(source, false)
                }
                val base = if (isMermaid) MERMAID_BASE else ASSETS_BASE
                val aspect = remember(source) { if (isMermaid) 0f else svgAspect(source) }
                val sizeMod = if (isMermaid) Modifier.fillMaxWidth().height(natH.coerceIn(60, 900).dp)
                else Modifier.fillMaxWidth().aspectRatio(aspect)
                Box(sizeMod.clip(RoundedCornerShape(8.dp))) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { c -> buildWebView(c, js = isMermaid) { _, h -> natH = h } },
                        update = { wv ->
                            if (wv.tag != html) {
                                wv.tag = html
                                wv.loadDataWithBaseURL(base, html, "text/html", "utf-8", null)
                            }
                        },
                        onRelease = { wv -> wv.destroy() }
                    )
                    // the web view never gets touches: taps open the full-screen view, drags scroll the chat
                    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { full = true } })
                }
            }
        }
    }
    if (full) {
        val html = if (isMermaid) mermaidHtml(source, dark, cs.onSurface, true) else svgHtml(source, true)
        FullscreenWeb(
            title = if (isMermaid) "Diagram · pinch to zoom" else "Image · pinch to zoom",
            html = html, base = if (isMermaid) MERMAID_BASE else ASSETS_BASE,
            js = isMermaid, copyText = source, onDismiss = { full = false }
        )
    }
}

/** A full-screen web page you can pan and pinch-zoom (diagrams, SVG, formulas). */
@Composable
fun FullscreenWeb(title: String, html: String, base: String, js: Boolean, copyText: String, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val clip = LocalClipboardManager.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.surface) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close") }
                    Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    IconButton(onClick = { clip.setText(AnnotatedString(copyText)) }) { Icon(Icons.Default.ContentCopy, "Copy") }
                }
                AndroidView(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    factory = { c -> buildWebView(c, js = js, zoom = true) },
                    update = { wv ->
                        if (wv.tag != html) {
                            wv.tag = html
                            wv.loadDataWithBaseURL(base, html, "text/html", "utf-8", null)
                        }
                    },
                    onRelease = { wv -> wv.destroy() }
                )
            }
        }
    }
}

@Composable
fun FullscreenKatex(tex: String, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val html = remember(tex, cs.onSurface) { katexHtml(tex, cs.onSurface, 26f, interactive = true) }
    FullscreenWeb("Formula · pinch to zoom", html, KATEX_BASE, true, tex, onDismiss)
}

/** Full-screen view of a code block: bigger text, optional line wrapping, scrolls both ways. */
@Composable
fun FullscreenCode(title: String, code: AnnotatedString, raw: String, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val clip = LocalClipboardManager.current
    var wrap by remember { mutableStateOf(false) }
    var size by remember { mutableStateOf(13f) }
    val v = rememberScrollState()
    val h = rememberScrollState()
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.surface) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close") }
                    Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    TextButton(onClick = { size = (size - 1f).coerceAtLeast(8f) }) { Text("A−") }
                    TextButton(onClick = { size = (size + 1f).coerceAtMost(30f) }) { Text("A+") }
                    FilterChip(selected = wrap, onClick = { wrap = !wrap }, label = { Text("Wrap") })
                    IconButton(onClick = { clip.setText(AnnotatedString(raw)) }) { Icon(Icons.Default.ContentCopy, "Copy") }
                }
                val body = Modifier.weight(1f).fillMaxWidth().verticalScroll(v)
                Box((if (wrap) body else body.horizontalScroll(h)).padding(12.dp)) {
                    SelectionContainer {
                        Text(code, fontFamily = FontFamily.Monospace, fontSize = size.sp, lineHeight = (size * 1.45f).sp)
                    }
                }
            }
        }
    }
}
