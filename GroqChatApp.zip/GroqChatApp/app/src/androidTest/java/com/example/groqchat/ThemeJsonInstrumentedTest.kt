package com.example.groqchat

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ThemeJsonInstrumentedTest {

    @Test
    fun exportImportRoundTrip() {
        val original = Settings(
            theme = "dark",
            accent = "blue",
            amoled = true,
            fontScale = 1.1f,
            bubbleRadius = 16,
            compact = true,
        )
        val json = original.exportThemeJson()
        val restored = Settings().importThemeJson(json)
        assertNotNull(restored)
        assertEquals("dark", restored!!.theme)
        assertEquals("blue", restored.accent)
        assertTrue(restored.amoled)
        assertEquals(1.1f, restored.fontScale, 0.001f)
        assertEquals(16, restored.bubbleRadius)
        assertTrue(restored.compact)
    }

    @Test
    fun invalidJsonReturnsNull() {
        assertNull(Settings().importThemeJson("not json {{{"))
        assertNull(Settings().importThemeJson(""))
    }

    @Test
    fun previewLinesNonEmpty() {
        val json = Settings(theme = "light").exportThemeJson()
        val lines = themePreviewLines(json)
        assertNotNull(lines)
        assertTrue(lines!!.isNotEmpty())
    }
}
