package com.example.groqchat

import org.json.JSONArray
import org.json.JSONObject

/** Cross-chat durable facts the model can use (stored encrypted with settings). */
data class MemoryFact(
    val id: String = System.currentTimeMillis().toString(),
    val text: String,
    val created: Long = System.currentTimeMillis(),
) {
    fun toJson() = JSONObject().put("id", id).put("text", text).put("created", created)
    companion object {
        fun fromJson(j: JSONObject) = MemoryFact(
            j.optString("id", System.currentTimeMillis().toString()),
            j.optString("text"),
            j.optLong("created", System.currentTimeMillis()),
        )
    }
}

object MemoryStore {
    fun parse(json: String): List<MemoryFact> = try {
        if (json.isBlank()) emptyList()
        else {
            val a = JSONArray(json)
            (0 until a.length()).map { MemoryFact.fromJson(a.getJSONObject(it)) }
        }
    } catch (_: Exception) { emptyList() }

    fun toJson(list: List<MemoryFact>): String {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        return a.toString()
    }

    fun systemBlock(facts: List<MemoryFact>): String {
        if (facts.isEmpty()) return ""
        val body = facts.joinToString("\n") { "- ${it.text}" }
        return "User memory (facts they asked you to remember; respect privacy and forget if asked):\n$body"
    }
}

/** Citation extracted from tool results or markdown links. */
data class Citation(val title: String, val url: String, val snippet: String = "")

object CitationParser {
    private val mdLink = Regex("""\[([^\]]+)\]\((https?://[^)]+)\)""")
    private val bareUrl = Regex("""https?://[^\s)>\]]+""")

    fun fromText(text: String): List<Citation> {
        val out = linkedMapOf<String, Citation>()
        mdLink.findAll(text).forEach { m ->
            val url = m.groupValues[2]
            out[url] = Citation(m.groupValues[1], url)
        }
        bareUrl.findAll(text).forEach { m ->
            val url = m.value.trimEnd('.', ',', ';')
            if (url !in out) out[url] = Citation(url.removePrefix("https://").removePrefix("http://").take(40), url)
        }
        return out.values.toList()
    }

    fun fromToolResult(name: String, result: String): List<Citation> {
        if (name != "web_search" && name != "fetch_url" && name != "browser_search") return emptyList()
        return fromText(result)
    }
}
