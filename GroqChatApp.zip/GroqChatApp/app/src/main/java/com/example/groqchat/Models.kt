package com.example.groqchat

import org.json.JSONArray
import org.json.JSONObject

fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")

enum class Role(val api: String) { SYSTEM("system"), USER("user"), ASSISTANT("assistant"), TOOL("tool") }

data class ToolCall(val id: String, val name: String, val args: String)

data class Msg(
    val id: Long = System.nanoTime(),
    val role: Role,
    val text: String = "",
    val images: List<String> = emptyList(),
    val reasoning: String = "",
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,
    val toolName: String? = null,
    val model: String? = null,
    val usage: String? = null,
    val error: Boolean = false,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("role", role.name).put("text", text)
        .put("images", JSONArray(images)).put("reasoning", reasoning)
        .put("toolCalls", JSONArray().also { a ->
            toolCalls.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("args", it.args)) }
        })
        .put("toolCallId", toolCallId ?: JSONObject.NULL)
        .put("toolName", toolName ?: JSONObject.NULL)
        .put("model", model ?: JSONObject.NULL)
        .put("usage", usage ?: JSONObject.NULL)
        .put("error", error)

    companion object {
        fun fromJson(j: JSONObject): Msg {
            val imgs = j.optJSONArray("images")
            val tcs = j.optJSONArray("toolCalls")
            return Msg(
                id = j.optLong("id", System.nanoTime()),
                role = Role.valueOf(j.optString("role", "USER")),
                text = j.str("text"),
                images = if (imgs == null) emptyList() else (0 until imgs.length()).map { imgs.getString(it) },
                reasoning = j.str("reasoning"),
                toolCalls = if (tcs == null) emptyList() else (0 until tcs.length()).map {
                    val o = tcs.getJSONObject(it); ToolCall(o.str("id"), o.str("name"), o.str("args"))
                },
                toolCallId = j.str("toolCallId").ifEmpty { null },
                toolName = j.str("toolName").ifEmpty { null },
                model = j.str("model").ifEmpty { null },
                usage = j.str("usage").ifEmpty { null },
                error = j.optBoolean("error", false),
            )
        }
    }
}

data class ModelInfo(val id: String, val owner: String, val ctx: Int, val active: Boolean)

data class Settings(
    val chatModel: String = "llama-3.3-70b-versatile",
    val visionModel: String = "qwen/qwen3.8-27b",
    val sttModel: String = "whisper-large-v3-turbo",
    val ttsModel: String = "canopylabs/orpheus-v1-english",
    val ttsVoice: String = "troy",
    val systemPrompt: String = "You are a helpful assistant.",
    val temperature: Float = 1f,
    val topP: Float = 1f,
    val maxTokens: Int = 2048,
    val reasoningEffort: String = "default",
    val showReasoning: Boolean = false,
    val jsonMode: Boolean = false,
    val tools: Boolean = false,
    val serviceTier: String = "on_demand",
    val translate: Boolean = false,
    val sttLanguage: String = "",
    val autoSpeak: Boolean = false,
    val stream: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("chatModel", chatModel).put("visionModel", visionModel).put("sttModel", sttModel)
        .put("ttsModel", ttsModel).put("ttsVoice", ttsVoice).put("systemPrompt", systemPrompt)
        .put("temperature", temperature.toDouble()).put("topP", topP.toDouble()).put("maxTokens", maxTokens)
        .put("reasoningEffort", reasoningEffort).put("showReasoning", showReasoning)
        .put("jsonMode", jsonMode).put("tools", tools).put("serviceTier", serviceTier)
        .put("translate", translate).put("sttLanguage", sttLanguage)
        .put("autoSpeak", autoSpeak).put("stream", stream)

    companion object {
        fun fromJson(j: JSONObject): Settings {
            val d = Settings()
            return Settings(
                chatModel = j.optString("chatModel", d.chatModel),
                visionModel = j.optString("visionModel", d.visionModel),
                sttModel = j.optString("sttModel", d.sttModel),
                ttsModel = j.optString("ttsModel", d.ttsModel),
                ttsVoice = j.optString("ttsVoice", d.ttsVoice),
                systemPrompt = j.optString("systemPrompt", d.systemPrompt),
                temperature = j.optDouble("temperature", d.temperature.toDouble()).toFloat(),
                topP = j.optDouble("topP", d.topP.toDouble()).toFloat(),
                maxTokens = j.optInt("maxTokens", d.maxTokens),
                reasoningEffort = j.optString("reasoningEffort", d.reasoningEffort),
                showReasoning = j.optBoolean("showReasoning", d.showReasoning),
                jsonMode = j.optBoolean("jsonMode", d.jsonMode),
                tools = j.optBoolean("tools", d.tools),
                serviceTier = j.optString("serviceTier", d.serviceTier),
                translate = j.optBoolean("translate", d.translate),
                sttLanguage = j.optString("sttLanguage", d.sttLanguage),
                autoSpeak = j.optBoolean("autoSpeak", d.autoSpeak),
                stream = j.optBoolean("stream", d.stream),
            )
        }
    }
}

fun isVisionModel(id: String): Boolean {
    val m = id.lowercase()
    return "qwen3.8" in m || "llama-4" in m || "scout" in m || "maverick" in m || "vision" in m
}

fun isReasoningModel(id: String): Boolean {
    val m = id.lowercase()
    return "gpt-oss" in m || "qwen3" in m || "deepseek-r1" in m
}

val ENGLISH_VOICES = listOf("autumn", "diana", "hannah", "austin", "daniel", "troy")
val ARABIC_VOICES = listOf("abdullah", "fahad", "sultan", "lulwa", "noura", "aisha")

enum class Kind(val label: String) {
    CHAT("Chat"), STT("Speech to text"), TTS("Text to speech"), SAFETY("Safety / moderation")
}

fun kindOf(id: String): Kind {
    val m = id.lowercase()
    return when {
        "whisper" in m -> Kind.STT
        "orpheus" in m || "tts" in m -> Kind.TTS
        "guard" in m -> Kind.SAFETY
        else -> Kind.CHAT
    }
}
