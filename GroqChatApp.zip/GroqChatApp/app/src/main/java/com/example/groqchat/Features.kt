package com.example.groqchat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Whether the current window is wide enough for a two-pane layout (tablets / unfolded foldables). */
@Composable
fun isTwoPane(): Boolean {
    val cfg = LocalConfiguration.current
    return cfg.screenWidthDp >= 600
}

/** HSV colour picker for a custom accent. */
@Composable
fun CustomColorPicker(
    initial: Int,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val seed = if (initial != 0) Color(initial) else Color(0xFFD83A1F)
    val hsv = remember {
        val a = FloatArray(3)
        android.graphics.Color.colorToHSV(seed.toArgb(), a)
        mutableStateOf(a)
    }
    var h by remember { mutableStateOf(hsv.value[0]) }
    var s by remember { mutableStateOf(hsv.value[1]) }
    var v by remember { mutableStateOf(hsv.value[2]) }
    val preview = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.custom_color)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(preview)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                )
                Text("Hue ${h.roundToInt()}°", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = h, onValueChange = { h = it }, valueRange = 0f..360f)
                Text("Saturation ${(s * 100).roundToInt()}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = s, onValueChange = { s = it }, valueRange = 0f..1f)
                Text("Brightness ${(v * 100).roundToInt()}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = v, onValueChange = { v = it }, valueRange = 0.2f..1f)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onPick(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
                onDismiss()
            }) { Text("Apply") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/**
 * Wraps a message row with swipe-to-copy / swipe-to-delete and a long-press action menu.
 * When [gesturesEnabled] is false, only long-press menu remains.
 */
@Composable
fun SwipeableMessage(
    messageId: Long,
    isUser: Boolean,
    text: String,
    gesturesEnabled: Boolean = true,
    onCopy: () -> Unit,
    onDelete: (() -> Unit)?,
    onEdit: (() -> Unit)?,
    onShare: (() -> Unit)?,
    onRegenerate: (() -> Unit)?,
    onPin: (() -> Unit)? = null,
    onBranch: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    var offsetX by remember(messageId) { mutableStateOf(0f) }
    var menuOpen by remember(messageId) { mutableStateOf(false) }
    val threshold = 120f
    val cd = stringResource(R.string.cd_long_press_menu)

    Box(
        Modifier
            .fillMaxWidth()
            .semantics { contentDescription = cd }
            .then(
                if (gesturesEnabled) {
                    Modifier.pointerInput(messageId) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                when {
                                    offsetX > threshold -> onCopy()
                                    offsetX < -threshold && onDelete != null -> onDelete()
                                    offsetX < -threshold -> onCopy()
                                }
                                offsetX = 0f
                            },
                            onHorizontalDrag = { _, drag ->
                                offsetX = (offsetX + drag).coerceIn(-200f, 200f)
                            }
                        )
                    }
                } else Modifier
            )
            .pointerInput(messageId) {
                detectTapGestures(onLongPress = { menuOpen = true })
            }
    ) {
        if (gesturesEnabled && offsetX > 20f) {
            Row(
                Modifier.matchParentSize().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.cd_swipe_copy), tint = MaterialTheme.colorScheme.primary)
            }
        } else if (gesturesEnabled && offsetX < -20f) {
            Row(
                Modifier.matchParentSize().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (onDelete != null) Icons.Default.Delete else Icons.Default.ContentCopy,
                    contentDescription = if (onDelete != null) stringResource(R.string.cd_swipe_delete) else stringResource(R.string.cd_swipe_copy),
                    tint = if (onDelete != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
        Box(Modifier.offset(x = (if (gesturesEnabled) offsetX else 0f).dp / 3)) { content() }
    }

    if (menuOpen) {
        AlertDialog(
            onDismissRequest = { menuOpen = false },
            title = { Text("Message actions") },
            text = {
                Column {
                    TextButton(
                        onClick = { onCopy(); menuOpen = false },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text(stringResource(R.string.copy))
                    }
                    if (onEdit != null) {
                        TextButton(
                            onClick = { onEdit(); menuOpen = false },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.Edit, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text(stringResource(R.string.edit))
                        }
                    }
                    if (onShare != null) {
                        TextButton(
                            onClick = { onShare(); menuOpen = false },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.Share, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text(stringResource(R.string.share))
                        }
                    }
                    if (onRegenerate != null) {
                        TextButton(
                            onClick = { onRegenerate(); menuOpen = false },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.Refresh, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text(stringResource(R.string.regenerate))
                        }
                    }
                    if (onPin != null) {
                        TextButton(
                            onClick = { onPin(); menuOpen = false },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.PushPin, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text("Pin / unpin")
                        }
                    }
                    if (onBranch != null) {
                        TextButton(
                            onClick = { onBranch(); menuOpen = false },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.CallSplit, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text("Branch from here")
                        }
                    }
                    if (onDelete != null) {
                        TextButton(
                            onClick = { onDelete(); menuOpen = false },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Delete, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text(stringResource(R.string.delete))
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

fun settingsSectionVisible(query: String, vararg labels: String): Boolean =
    settingsSectionScore(query, *labels) > 0 || query.isBlank()

/** Higher score = better match. 0 = no match. Blank query → score 1 (show all). */
fun settingsSectionScore(query: String, vararg labels: String): Int {
    if (query.isBlank()) return 1
    val q = query.trim().lowercase()
    if (q.isEmpty()) return 1
    val tokens = q.split(Regex("\\s+")).filter { it.isNotEmpty() }
    var best = 0
    for (label in labels) {
        val l = label.lowercase()
        var score = 0
        if (l == q) score = 100
        else if (l.startsWith(q)) score = 80
        else if (l.contains(q)) score = 60
        else if (q.contains(l) && l.length >= 3) score = 40
        else {
            val tokHits = tokens.count { tok -> l.contains(tok) || (tok.length >= 3 && tok.contains(l)) }
            if (tokHits > 0) score = 20 + tokHits * 10
        }
        if (score > best) best = score
    }
    return best
}

fun Settings.exportThemeJson(): String {
    return org.json.JSONObject()
        .put("theme", theme)
        .put("dynamicColor", dynamicColor)
        .put("accent", accent)
        .put("customAccent", customAccent)
        .put("amoled", amoled)
        .put("fontFamily", fontFamily)
        .put("fontScale", fontScale.toDouble())
        .put("bubbleRadius", bubbleRadius)
        .put("compact", compact)
        .toString(2)
}

fun Settings.importThemeJson(text: String): Settings? {
    return try {
        val j = org.json.JSONObject(text.trim())
        if (j.length() == 0) null
        else copy(
            theme = j.optString("theme", theme).ifBlank { theme },
            dynamicColor = j.optBoolean("dynamicColor", dynamicColor),
            accent = j.optString("accent", accent).ifBlank { accent },
            customAccent = j.optInt("customAccent", customAccent),
            amoled = j.optBoolean("amoled", amoled),
            fontFamily = j.optString("fontFamily", fontFamily).ifBlank { fontFamily },
            fontScale = j.optDouble("fontScale", fontScale.toDouble()).toFloat().coerceIn(0.85f, 1.4f),
            bubbleRadius = j.optInt("bubbleRadius", bubbleRadius).coerceIn(4, 32),
            compact = j.optBoolean("compact", compact),
        )
    } catch (_: Exception) {
        null
    }
}

fun themePreviewLines(text: String): List<String>? {
    val s = Settings().importThemeJson(text) ?: return null
    return listOf(
        "Theme: ${s.theme}",
        "Accent: ${if (s.customAccent != 0) "custom" else s.accent}",
        "AMOLED: ${s.amoled}",
        "Font: ${s.fontFamily}",
        "Text size: ${(s.fontScale * 100).roundToInt()}%",
        "Bubble radius: ${s.bubbleRadius}dp",
        "Compact: ${s.compact}",
        "Dynamic colour: ${s.dynamicColor}",
    )
}

fun friendlyErrorMessage(e: Exception): String = when (e) {
    is ApiException -> when (e.code) {
        401 -> "Invalid API key. Open Settings and paste a key from console.groq.com/keys."
        403 -> "Access denied (403). Check that your key is allowed for this model."
        404 -> "Model or endpoint not found (404). Pick another model in Settings."
        413 -> "Request too large. Remove attachments or shorten the chat."
        429 -> buildString {
            append("Rate limit reached")
            e.retryAfter?.let { append(" — retry after ${it}s") }
            append(". Wait a moment or switch model.")
        }
        500, 502, 503 -> "Groq servers are having trouble (${e.code}). Retry in a few seconds."
        else -> "Error ${e.code}: ${e.message ?: "Something went wrong"}"
    }
    is java.io.IOException -> {
        val m = (e.message ?: "").lowercase()
        when {
            m.contains("unable to resolve host") || m.contains("unknown host") ->
                "No internet connection. Check Wi‑Fi or mobile data and retry."
            m.contains("timeout") || m.contains("timed out") ->
                "Connection timed out. Check your network and retry."
            m.contains("cleartext") -> "Secure connection required. Check network settings."
            else -> "Network error. Check your connection and retry."
        }
    }
    else -> e.message?.takeIf { it.isNotBlank() } ?: "Something went wrong. Please retry."
}
