package com.example.groqchat

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

val GroqLight = lightColorScheme(
    primary = Color(0xFFD83A1F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD2),
    onPrimaryContainer = Color(0xFF410100),
    secondary = Color(0xFF765650),
    background = Color(0xFFFFFBFA),
    onBackground = Color(0xFF201A19),
    surface = Color(0xFFFFFBFA),
    onSurface = Color(0xFF201A19),
    surfaceVariant = Color(0xFFF5DDD8),
    onSurfaceVariant = Color(0xFF534341),
    outlineVariant = Color(0xFFD8C2BE),
)

val GroqDark = darkColorScheme(
    primary = Color(0xFFFFB4A5),
    onPrimary = Color(0xFF650B00),
    primaryContainer = Color(0xFF8E1D0A),
    onPrimaryContainer = Color(0xFFFFDAD2),
    secondary = Color(0xFFE7BDB4),
    background = Color(0xFF1A1110),
    onBackground = Color(0xFFF1DFDB),
    surface = Color(0xFF1A1110),
    onSurface = Color(0xFFF1DFDB),
    surfaceVariant = Color(0xFF534341),
    onSurfaceVariant = Color(0xFFD8C2BE),
    outlineVariant = Color(0xFF534341),
)

/** Accent presets: key, label, seed colour. "default" keeps the hand-tuned Groq palette. */
val ACCENT_PRESETS: List<Triple<String, String, Color>> = listOf(
    Triple("default", "Groq", Color(0xFFD83A1F)),
    Triple("blue", "Blue", Color(0xFF3B82F6)),
    Triple("green", "Green", Color(0xFF16A34A)),
    Triple("purple", "Purple", Color(0xFF8B5CF6)),
    Triple("pink", "Pink", Color(0xFFEC4899)),
    Triple("teal", "Teal", Color(0xFF0D9488)),
    Triple("amber", "Amber", Color(0xFFF59E0B)),
    Triple("slate", "Slate", Color(0xFF64748B)),
)

private fun hsv(h: Float, s: Float, v: Float): Color =
    Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))))

/** Builds a full colour scheme from an accent preset. */
fun accentScheme(key: String, dark: Boolean): ColorScheme {
    val seed = ACCENT_PRESETS.firstOrNull { it.first == key }?.third
    if (key == "default" || seed == null) return if (dark) GroqDark else GroqLight
    val c = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), c)
    val h = c[0]
    return if (dark) darkColorScheme(
        primary = hsv(h, 0.45f, 1f), onPrimary = hsv(h, 0.9f, 0.25f),
        primaryContainer = hsv(h, 0.75f, 0.45f), onPrimaryContainer = hsv(h, 0.15f, 1f),
        secondary = hsv(h, 0.3f, 0.9f),
        secondaryContainer = hsv(h, 0.4f, 0.3f), onSecondaryContainer = hsv(h, 0.15f, 0.95f),
        background = hsv(h, 0.15f, 0.1f), onBackground = hsv(h, 0.05f, 0.93f),
        surface = hsv(h, 0.15f, 0.1f), onSurface = hsv(h, 0.05f, 0.93f),
        surfaceVariant = hsv(h, 0.12f, 0.28f), onSurfaceVariant = hsv(h, 0.08f, 0.85f),
        outlineVariant = hsv(h, 0.12f, 0.3f),
    ) else lightColorScheme(
        primary = hsv(h, 0.85f, 0.75f), onPrimary = Color.White,
        primaryContainer = hsv(h, 0.18f, 1f), onPrimaryContainer = hsv(h, 0.9f, 0.25f),
        secondary = hsv(h, 0.5f, 0.45f),
        secondaryContainer = hsv(h, 0.12f, 1f), onSecondaryContainer = hsv(h, 0.8f, 0.25f),
        background = hsv(h, 0.03f, 1f), onBackground = hsv(h, 0.1f, 0.12f),
        surface = hsv(h, 0.03f, 1f), onSurface = hsv(h, 0.1f, 0.12f),
        surfaceVariant = hsv(h, 0.1f, 0.93f), onSurfaceVariant = hsv(h, 0.15f, 0.3f),
        outlineVariant = hsv(h, 0.1f, 0.8f),
    )
}

/** True-black variant of a dark scheme (saves power on OLED screens). */
fun amoledScheme(s: ColorScheme): ColorScheme = s.copy(
    background = Color.Black, surface = Color.Black,
    surfaceVariant = Color(0xFF1C1C1E), surfaceContainerHigh = Color(0xFF161618),
)

/** Full colour scheme from an arbitrary ARGB accent (custom picker). */
fun customAccentScheme(argb: Int, dark: Boolean): ColorScheme {
    val seed = Color(argb)
    val c = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), c)
    val h = c[0]
    return if (dark) darkColorScheme(
        primary = hsv(h, 0.45f, 1f), onPrimary = hsv(h, 0.9f, 0.25f),
        primaryContainer = hsv(h, 0.75f, 0.45f), onPrimaryContainer = hsv(h, 0.15f, 1f),
        secondary = hsv(h, 0.3f, 0.9f),
        secondaryContainer = hsv(h, 0.4f, 0.3f), onSecondaryContainer = hsv(h, 0.15f, 0.95f),
        background = hsv(h, 0.15f, 0.1f), onBackground = hsv(h, 0.05f, 0.93f),
        surface = hsv(h, 0.15f, 0.1f), onSurface = hsv(h, 0.05f, 0.93f),
        surfaceVariant = hsv(h, 0.12f, 0.28f), onSurfaceVariant = hsv(h, 0.08f, 0.85f),
        outlineVariant = hsv(h, 0.12f, 0.3f),
    ) else lightColorScheme(
        primary = hsv(h, 0.85f, 0.75f), onPrimary = Color.White,
        primaryContainer = hsv(h, 0.18f, 1f), onPrimaryContainer = hsv(h, 0.9f, 0.25f),
        secondary = hsv(h, 0.5f, 0.45f),
        secondaryContainer = hsv(h, 0.12f, 1f), onSecondaryContainer = hsv(h, 0.8f, 0.25f),
        background = hsv(h, 0.03f, 1f), onBackground = hsv(h, 0.1f, 0.12f),
        surface = hsv(h, 0.03f, 1f), onSurface = hsv(h, 0.1f, 0.12f),
        surfaceVariant = hsv(h, 0.1f, 0.93f), onSurfaceVariant = hsv(h, 0.15f, 0.3f),
        outlineVariant = hsv(h, 0.1f, 0.8f),
    )
}
