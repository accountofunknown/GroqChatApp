package com.example.groqchat

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Base64
import android.util.LruCache
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

data class ChatMeta(
    val id: String,
    val title: String,
    val updated: Long,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val folder: String = "",
    val tags: String = "",
)

/** A chat that matched a search, with a short excerpt of the matching message text. */
data class ChatHit(val meta: ChatMeta, val snippet: String)

private class ChatDb(ctx: Context) : SQLiteOpenHelper(ctx, "chats.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE chats (id TEXT PRIMARY KEY, title TEXT NOT NULL, updated INTEGER NOT NULL, " +
                "pinned INTEGER NOT NULL DEFAULT 0, archived INTEGER NOT NULL DEFAULT 0, " +
                "folder TEXT NOT NULL DEFAULT '', tags TEXT NOT NULL DEFAULT '')"
        )
        db.execSQL(
            "CREATE TABLE messages (chat_id TEXT NOT NULL, pos INTEGER NOT NULL, h TEXT NOT NULL, " +
                "body TEXT NOT NULL, PRIMARY KEY (chat_id, pos))"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

/**
 * Settings and secrets live in SharedPreferences (secrets encrypted). Chats live in an SQLite database:
 * titles, folders, tags and every message are AES-256-GCM encrypted, and images are stored as separate
 * encrypted files instead of being embedded in the message text.
 */
class Store(private val ctx: Context) {
    private val plain: SharedPreferences = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val secure: SharedPreferences = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("secure_fallback", Context.MODE_PRIVATE)
    }
    private val crypto = Crypto(ctx.getSharedPreferences("keys", Context.MODE_PRIVATE))
    private val db: SQLiteDatabase by lazy { ChatDb(ctx).writableDatabase }
    private val textCache = LruCache<String, String>(30)

    var apiKey: String
        get() = secure.getString("groq_key", "") ?: ""
        set(v) { secure.edit().putString("groq_key", v.trim()).apply() }

    var currentChatId: String
        get() = plain.getString("current", "") ?: ""
        set(v) { plain.edit().putString("current", v).apply() }

    fun loadSettings(): Settings = try {
        Settings.fromJson(JSONObject(plain.getString("s", "{}") ?: "{}"))
    } catch (e: Exception) { Settings() }

    fun saveSettings(s: Settings) { plain.edit().putString("s", s.toJson().toString()).apply() }

    // ------------------------------------------------------------------ chat index

    /** All chats, newest first. Call off the main thread: it may migrate old data and decrypts every title. */
    fun loadIndex(): List<ChatMeta> {
        migrateLegacy()
        purgeOrphans()
        val out = ArrayList<ChatMeta>()
        try {
            db.rawQuery(
                "SELECT id, title, updated, pinned, archived, folder, tags FROM chats ORDER BY updated DESC", null
            ).use { c ->
                while (c.moveToNext()) {
                    out += ChatMeta(
                        id = c.getString(0), title = crypto.unseal(c.getString(1)).ifBlank { "Chat" },
                        updated = c.getLong(2), pinned = c.getInt(3) == 1, archived = c.getInt(4) == 1,
                        folder = crypto.unseal(c.getString(5)), tags = crypto.unseal(c.getString(6))
                    )
                }
            }
        } catch (e: Exception) { }
        return out
    }

    fun saveMeta(m: ChatMeta) {
        try {
            val v = ContentValues().apply {
                put("id", m.id)
                put("title", crypto.seal(m.title))
                put("updated", m.updated)
                put("pinned", if (m.pinned) 1 else 0)
                put("archived", if (m.archived) 1 else 0)
                put("folder", crypto.seal(m.folder))
                put("tags", crypto.seal(m.tags))
            }
            db.insertWithOnConflict("chats", null, v, SQLiteDatabase.CONFLICT_REPLACE)
        } catch (e: Exception) { }
    }

    /** Removes only the list entry. The messages stay until [deleteChat], so a delete can still be undone. */
    fun removeMeta(id: String) {
        try { db.delete("chats", "id = ?", arrayOf(id)) } catch (e: Exception) { }
    }

    // ------------------------------------------------------------------ messages

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun imageDir(chatId: String) = File(ctx.filesDir, "images/$chatId")

    private fun storeImage(chatId: String, dataUrl: String): String {
        val name = sha1(dataUrl)
        val dir = imageDir(chatId)
        dir.mkdirs()
        val f = File(dir, name)
        if (!f.exists()) {
            val inner = if (dataUrl.startsWith(JPEG_PREFIX))
                byteArrayOf(1) + Base64.decode(dataUrl.substring(JPEG_PREFIX.length), Base64.DEFAULT)
            else byteArrayOf(2) + dataUrl.toByteArray(Charsets.UTF_8)
            val enc = crypto.encryptBytes(inner)
            f.writeBytes(if (enc != null) byteArrayOf('E'.code.toByte()) + enc else byteArrayOf('P'.code.toByte()) + inner)
        }
        return "img:$name"
    }

    private fun loadImage(chatId: String, ref: String): String? {
        val f = File(imageDir(chatId), ref.removePrefix("img:"))
        if (!f.exists()) return null
        val raw = try { f.readBytes() } catch (e: Exception) { return null }
        if (raw.size < 2) return null
        val body = raw.copyOfRange(1, raw.size)
        val inner = when (raw[0].toInt().toChar()) {
            'E' -> crypto.decryptBytes(body)
            'P' -> body
            else -> null
        } ?: return null
        if (inner.isEmpty()) return null
        return when (inner[0].toInt()) {
            1 -> JPEG_PREFIX + Base64.encodeToString(inner, 1, inner.size - 1, Base64.NO_WRAP)
            2 -> String(inner, 1, inner.size - 1, Charsets.UTF_8)
            else -> null
        }
    }

    fun loadChat(id: String): List<Msg> {
        val out = ArrayList<Msg>()
        try {
            db.rawQuery("SELECT body FROM messages WHERE chat_id = ? ORDER BY pos", arrayOf(id)).use { c ->
                while (c.moveToNext()) {
                    val txt = crypto.unseal(c.getString(0))
                    if (txt.isEmpty()) continue
                    val m = Msg.fromJson(JSONObject(txt))
                    out += if (m.images.isEmpty()) m
                    else m.copy(images = m.images.mapNotNull { if (it.startsWith("img:")) loadImage(id, it) else it })
                }
            }
        } catch (e: Exception) { }
        return out
    }

    /** Writes only the messages that changed since the last save, in one transaction. */
    fun saveChat(id: String, list: List<Msg>) {
        try {
            val have = HashMap<Int, String>()
            db.rawQuery("SELECT pos, h FROM messages WHERE chat_id = ?", arrayOf(id)).use { c ->
                while (c.moveToNext()) have[c.getInt(0)] = c.getString(1)
            }
            val used = HashSet<String>()
            db.beginTransaction()
            try {
                list.forEachIndexed { i, m ->
                    val o = m.toJson()
                    if (m.images.isNotEmpty()) {
                        val refs = m.images.map { if (it.startsWith("img:")) it else storeImage(id, it) }
                        refs.forEach { used += it.removePrefix("img:") }
                        o.put("images", JSONArray(refs))
                    }
                    val body = o.toString()
                    val h = sha1(body)
                    if (have[i] != h) {
                        val v = ContentValues().apply {
                            put("chat_id", id); put("pos", i); put("h", h); put("body", crypto.seal(body))
                        }
                        db.insertWithOnConflict("messages", null, v, SQLiteDatabase.CONFLICT_REPLACE)
                    }
                }
                db.delete("messages", "chat_id = ? AND pos >= ?", arrayOf(id, list.size.toString()))
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            imageDir(id).listFiles()?.forEach { if (it.name !in used) it.delete() }
            textCache.remove(id)
        } catch (e: Exception) { }
    }

    /** Plain text of a chat (no images), for searching. */
    fun chatText(id: String): String {
        textCache.get(id)?.let { return it }
        val sb = StringBuilder()
        try {
            db.rawQuery("SELECT body FROM messages WHERE chat_id = ? ORDER BY pos", arrayOf(id)).use { c ->
                while (c.moveToNext()) {
                    val txt = crypto.unseal(c.getString(0))
                    if (txt.isEmpty()) continue
                    val o = JSONObject(txt)
                    val role = o.optString("role")
                    if ((role == "USER" || role == "ASSISTANT") && !o.optBoolean("error")) {
                        val t = o.str("text")
                        if (t.isNotBlank()) { if (sb.isNotEmpty()) sb.append('\n'); sb.append(t) }
                    }
                }
            }
        } catch (e: Exception) { }
        val s = sb.toString()
        textCache.put(id, s)
        return s
    }

    /** Permanently deletes a chat with its messages and images. */
    fun deleteChat(id: String) {
        try {
            db.delete("messages", "chat_id = ?", arrayOf(id))
            db.delete("chats", "id = ?", arrayOf(id))
        } catch (e: Exception) { }
        imageDir(id).deleteRecursively()
        textCache.remove(id)
    }

    fun deleteAllChats() {
        try {
            db.execSQL("DELETE FROM messages")
            db.execSQL("DELETE FROM chats")
        } catch (e: Exception) { }
        File(ctx.filesDir, "images").deleteRecursively()
        textCache.evictAll()
        currentChatId = ""
    }

    private fun purgeOrphans() {
        try {
            db.execSQL("DELETE FROM messages WHERE chat_id NOT IN (SELECT id FROM chats)")
            val ids = HashSet<String>()
            db.rawQuery("SELECT id FROM chats", null).use { c -> while (c.moveToNext()) ids += c.getString(0) }
            File(ctx.filesDir, "images").listFiles()?.forEach { if (it.name !in ids) it.deleteRecursively() }
        } catch (e: Exception) { }
    }

    /** One-time move from the old JSON files (index in preferences, one file per chat) into the database. */
    private fun migrateLegacy() {
        if (plain.getBoolean("db_v2", false)) return
        try {
            val metas = ArrayList<ChatMeta>()
            try {
                val a = JSONArray(plain.getString("index", "[]") ?: "[]")
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    metas += ChatMeta(o.getString("id"), o.optString("title", "Chat"), o.optLong("updated"), o.optBoolean("pinned", false))
                }
            } catch (e: Exception) { }
            val oldest = File(ctx.filesDir, "chat.json")
            if (metas.isEmpty() && oldest.exists()) {
                oldest.copyTo(File(ctx.filesDir, "chat_legacy.json"), overwrite = true)
                metas += ChatMeta("legacy", "Previous chat", System.currentTimeMillis())
            }
            for (m in metas) {
                val f = File(ctx.filesDir, "chat_${m.id}.json")
                val msgs: List<Msg> = try {
                    if (f.exists()) {
                        val a = JSONArray(f.readText())
                        (0 until a.length()).map { Msg.fromJson(a.getJSONObject(it)) }
                    } else emptyList()
                } catch (e: Exception) { emptyList() }
                saveChat(m.id, msgs)
                saveMeta(m)
            }
            ctx.filesDir.listFiles { f -> f.name.startsWith("chat_") || f.name.startsWith("idx_") || f.name == "chat.json" }
                ?.forEach { it.delete() }
            plain.edit().remove("index").putBoolean("db_v2", true).apply()
        } catch (e: Exception) {
            // keep the old files and try again on the next start
        }
    }

    // ------------------------------------------------------------------ secrets

    // MCP servers hold auth tokens, so they live in the encrypted preferences.
    fun loadMcp(): List<McpServer> = try {
        val a = JSONArray(secure.getString("mcp", "[]") ?: "[]")
        (0 until a.length()).map { McpServer.fromJson(a.getJSONObject(it)) }
    } catch (e: Exception) { emptyList() }

    fun saveMcp(list: List<McpServer>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        secure.edit().putString("mcp", a.toString()).apply()
    }

    // Custom tools may contain webhook headers / tokens, so they are stored encrypted too.
    fun loadTools(): List<CustomTool> = try {
        val a = JSONArray(secure.getString("tools", "[]") ?: "[]")
        (0 until a.length()).map { CustomTool.fromJson(a.getJSONObject(it)) }
    } catch (e: Exception) { emptyList() }

    fun saveTools(list: List<CustomTool>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        secure.edit().putString("tools", a.toString()).apply()
    }

    private companion object {
        const val JPEG_PREFIX = "data:image/jpeg;base64,"
    }
}
