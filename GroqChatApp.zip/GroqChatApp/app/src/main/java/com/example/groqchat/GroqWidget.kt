package com.example.groqchat

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Home-screen widget that opens the app to a new chat. */
class GroqWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_groq)
            val intent = Intent(context, MainActivity::class.java).apply {
                action = ACTION_NEW_CHAT
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pi = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_title, pi)
            views.setOnClickPendingIntent(R.id.widget_action, pi)
            manager.updateAppWidget(id, views)
        }
    }

    companion object {
        const val ACTION_NEW_CHAT = "com.example.groqchat.NEW_CHAT"
        const val ACTION_OPEN_SETTINGS = "com.example.groqchat.OPEN_SETTINGS"
        const val ACTION_SHARE = "com.example.groqchat.SHARE_TEXT"
    }
}
