package com.example.groqchat

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ClipboardManager
import android.location.Location
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.provider.CalendarContract
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Tools that read something from this phone. The sensitive ones (clipboard, location, calendar) are off
 * until you switch on "Device data tools", and each use is confirmed by you (and by Android for location
 * and calendar) before anything is read.
 */
object DeviceTools {
    val SENSITIVE: Set<String> = linkedSetOf("read_clipboard", "get_location", "get_calendar_events")
    val names: List<String> = listOf("get_battery", "get_device_info") + SENSITIVE.toList()

    private fun fn(name: String, desc: String, props: JSONObject = JSONObject()): JSONObject =
        JSONObject().put("type", "function").put(
            "function", JSONObject().put("name", name).put("description", desc).put(
                "parameters", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray())
            )
        )

    val definitions: List<JSONObject> = listOf(
        fn("get_battery", "Get the phone's battery level and whether it is charging."),
        fn("get_device_info", "Get basic details about this phone: model, Android version, language and time zone."),
        fn("read_clipboard", "Read the text currently on the phone's clipboard. The user is asked to allow this each time."),
        fn("get_location", "Get the phone's approximate location (rounded to about 1 km). The user is asked to allow this."),
        fn(
            "get_calendar_events",
            "List upcoming calendar events with title, time and place. The user is asked to allow this.",
            JSONObject().put("days", JSONObject().put("type", "integer").put("description", "How many days ahead to look (1-30, default 7)"))
        ),
    )

    fun permissionFor(name: String): String? = when (name) {
        "get_location" -> Manifest.permission.ACCESS_COARSE_LOCATION
        "get_calendar_events" -> Manifest.permission.READ_CALENDAR
        else -> null
    }

    fun consentText(name: String): String = when (name) {
        "read_clipboard" -> "read what is on your clipboard right now"
        "get_location" -> "read your approximate location (rounded to about 1 km)"
        "get_calendar_events" -> "read the titles, times and places of your upcoming calendar events"
        else -> "use $name"
    }

    fun describe(name: String): String = when (name) {
        "get_current_time" -> "Returns the current date and time"
        "calculate" -> "Evaluates a math expression"
        "get_battery" -> "Battery level and charging state"
        "get_device_info" -> "Phone model, Android version, language, time zone"
        "read_clipboard" -> "Reads the clipboard (you approve each use)"
        "get_location" -> "Approximate location (you approve each use)"
        "get_calendar_events" -> "Upcoming calendar events (you approve each use)"
        else -> name
    }

    fun run(ctx: Context, name: String, args: String): String = try {
        when (name) {
            "get_battery" -> battery(ctx)
            "get_device_info" -> deviceInfo()
            "read_clipboard" -> clipboard(ctx)
            "get_location" -> location(ctx)
            "get_calendar_events" -> calendar(ctx, args)
            else -> "Unknown tool: $name"
        }
    } catch (e: SecurityException) {
        "Android did not allow access."
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    private fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val plug = when (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "wireless"
            else -> "not plugged in"
        }
        return (if (pct >= 0) "Battery $pct%" else "Battery level unknown") +
            ", " + (if (charging) "charging" else "not charging") + " ($plug)"
    }

    private fun deviceInfo(): String =
        "Device: ${Build.MANUFACTURER} ${Build.MODEL}; Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}); " +
            "language ${Locale.getDefault().toLanguageTag()}; time zone ${TimeZone.getDefault().id}"

    private fun clipboard(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(ctx)?.toString().orEmpty() else ""
        if (text.isBlank()) return "The clipboard is empty, or Android blocked access."
        return if (text.length > 4000) text.take(4000) + "\n[truncated]" else text
    }

    private fun location(ctx: Context): String {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            val l = try { lm.getLastKnownLocation(p) } catch (e: SecurityException) { null }
            if (l != null && (best == null || l.time > best.time)) best = l
        }
        val b = best ?: return "No recent location is available. Open a maps app once and try again."
        val ageMin = (System.currentTimeMillis() - b.time) / 60000
        return "Approximate location: latitude ${String.format(Locale.US, "%.2f", b.latitude)}, " +
            "longitude ${String.format(Locale.US, "%.2f", b.longitude)} (accuracy about ${b.accuracy.toInt()} m, $ageMin min old)"
    }

    private fun calendar(ctx: Context, args: String): String {
        val days = (try { JSONObject(args.ifBlank { "{}" }).optInt("days", 7) } catch (e: Exception) { 7 }).coerceIn(1, 30)
        val now = System.currentTimeMillis()
        val end = now + days * 86_400_000L
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, now)
        ContentUris.appendId(builder, end)
        val cols = arrayOf(
            CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END,
            CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY
        )
        val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        val out = ArrayList<String>()
        ctx.contentResolver.query(builder.build(), cols, null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
            while (c.moveToNext() && out.size < 20) {
                val title = c.getString(0).orEmpty().ifBlank { "(no title)" }
                val begin = c.getLong(1)
                val finish = c.getLong(2)
                val place = c.getString(3).orEmpty()
                val whenText = if (c.getInt(4) == 1) "all day, " + DateFormat.getDateInstance().format(Date(begin))
                else fmt.format(Date(begin)) + " – " + fmt.format(Date(finish))
                out += "- $title · $whenText" + (if (place.isNotBlank()) " · $place" else "")
            }
        }
        return if (out.isEmpty()) "No events in the next $days days." else "Events in the next $days days:\n" + out.joinToString("\n")
    }
}
