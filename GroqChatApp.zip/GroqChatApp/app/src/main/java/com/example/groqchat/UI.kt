package com.example.groqchat

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

// ============================ ROOT ============================

@Composable
fun GroqApp(vm: ChatViewModel) {
    var showSettings by remember { mutableStateOf(vm.apiKey.isBlank()) }
    val ctx = LocalContext.current
    LaunchedEffect(vm.status) {
        vm.status?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.status = null }
    }
    vm.pendingAsk?.let { r ->
        var answer by remember(r) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Tool request: ${r.tool}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("The model is asking you for this result.", fontSize = 13.sp)
                    if (r.args.isNotBlank()) Text(r.args, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    OutlinedTextField(
                        value = answer, onValueChange = { answer = it },
                        label = { Text("Your answer") }, modifier = Modifier.fillMaxWidth(), minLines = 2
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.answerAsk(answer.ifBlank { "(no answer)" }) }) { Text("Send") } },
            dismissButton = { TextButton(onClick = { vm.answerAsk(null) }) { Text("Decline") } }
        )
    }
    BackHandler(showSettings && vm.apiKey.isNotBlank()) { showSettings = false }
    Crossfade(targetState = showSettings, label = "screen") { settingsOpen ->
        if (settingsOpen) SettingsScreen(vm) { showSettings = false } else ChatScreen(vm) { showSettings = true }
    }
}

// ============================ CHAT ============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, openSettings: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val msgs = vm.messages.toList()
    var showModels by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<String?>(null) }
    var deleteTarget by remember { mutableStateOf<ChatMeta?>(null) }
    val scrolledUp by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 240 }
    }
    LaunchedEffect(msgs.size, vm.currentChatId) { listState.scrollToItem(0) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text("Chats", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 24.dp, top = 24.dp, bottom = 12.dp))
                FilledTonalButton(
                    onClick = { vm.newChat(); scope.launch { drawerState.close() } },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("New chat")
                }
                Spacer(Modifier.height(8.dp))
                if (vm.chats.isEmpty()) Text(
                    "Your conversations are saved here.", fontSize = 13.sp, color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(vm.chats.toList(), key = { it.id }) { c ->
                        NavigationDrawerItem(
                            label = { Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = c.id == vm.currentChatId,
                            onClick = { vm.openChat(c.id); scope.launch { drawerState.close() } },
                            badge = {
                                IconButton(onClick = { deleteTarget = c }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Delete, "Delete chat", Modifier.size(18.dp))
                                }
                            },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                }
                HorizontalDivider()
                NavigationDrawerItem(
                    label = { Text("Settings") },
                    icon = { Icon(Icons.Default.Settings, null) },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() }; openSettings() },
                    modifier = Modifier.padding(12.dp).navigationBarsPadding()
                )
            }
        }
    ) {
        Column(Modifier.fillMaxSize().background(cs.background)) {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
                navigationIcon = {
                    IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "Chat history") }
                },
                title = {
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(cs.secondaryContainer)
                            .clickable { showModels = true }.padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            vm.settings.chatModel.substringAfterLast('/'), fontSize = 14.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                            color = cs.onSecondaryContainer
                        )
                        Icon(Icons.Default.ArrowDropDown, "Choose model", tint = cs.onSecondaryContainer)
                    }
                },
                actions = {
                    IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "New chat") }
                }
            )

            if (showModels) {
                OptionSheet(
                    title = "All models (${vm.models.size})",
                    options = vm.models.map { Opt(it.id, "${kindOf(it.id).label} · ${it.ctx / 1000}K context", it.owner.ifBlank { "Other" }) },
                    selected = setOf(vm.settings.chatModel, vm.settings.sttModel, vm.settings.ttsModel),
                    onSelect = { vm.pickModel(it) },
                    onDismiss = { showModels = false }
                )
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (msgs.isEmpty()) {
                    EmptyState(vm)
                } else {
                    val scale = vm.settings.fontScale
                    LazyColumn(
                        state = listState, reverseLayout = true,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        val rev = msgs.asReversed()
                        items(rev.size, key = { rev[it].id }) { i ->
                            MessageItem(vm, rev[i], isLast = i == 0, scale = scale) { preview = it }
                        }
                    }
                }
                if (scrolledUp && msgs.isNotEmpty()) {
                    SmallFloatingActionButton(
                        onClick = { scope.launch { listState.animateScrollToItem(0) } },
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)
                    ) {
                        Icon(Icons.Default.KeyboardArrowDown, "Scroll to latest")
                    }
                }
            }
            InputBar(vm)
        }
    }

    preview?.let { ImagePreview(it) { preview = null } }
    deleteTarget?.let { c ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete chat?") },
            text = { Text("“${c.title}” will be removed from this device.") },
            confirmButton = { TextButton(onClick = { vm.deleteChat(c.id); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Avatar(size: Dp = 28.dp) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(size).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
        Text("G", color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.5f).sp)
    }
}

@Composable
fun EmptyState(vm: ChatViewModel) {
    val cs = MaterialTheme.colorScheme
    val ideas = listOf(
        "💡" to "Explain how transformers work in simple terms",
        "✍️" to "Write a polite email asking for a deadline extension",
        "🐍" to "Write a Python function that checks for palindromes",
        "✈️" to "Plan a 3-day budget trip to Tokyo",
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Avatar(56.dp)
        Spacer(Modifier.height(16.dp))
        Text("How can I help?", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "Type, talk with the mic, or attach images", fontSize = 13.sp, color = cs.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
        )
        ideas.forEach { (emoji, text) ->
            OutlinedCard(
                onClick = { vm.draft = text; vm.send() },
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(emoji, fontSize = 20.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(text, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun MessageItem(vm: ChatViewModel, m: Msg, isLast: Boolean, scale: Float, onImage: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    when (m.role) {
        Role.USER -> Column(Modifier.fillMaxWidth().padding(start = 40.dp), horizontalAlignment = Alignment.End) {
            Surface(color = cs.primaryContainer, shape = RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp)) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (m.images.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        m.images.forEach { DataImage(it, 80.dp) { onImage(it) } }
                    }
                    if (m.text.isNotBlank()) SelectionContainer {
                        Text(m.text, color = cs.onPrimaryContainer, fontSize = (15f * scale).sp, lineHeight = (22f * scale).sp)
                    }
                }
            }
        }
        Role.TOOL -> Row(Modifier.fillMaxWidth().padding(start = 38.dp)) {
            Surface(color = cs.surfaceVariant, shape = RoundedCornerShape(10.dp)) {
                Text(
                    "🔧 ${m.toolName} → ${m.text}", fontSize = 12.sp, color = cs.onSurfaceVariant,
                    maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
        Role.ASSISTANT -> AssistantItem(vm, m, isLast, scale)
        Role.SYSTEM -> {}
    }
}

@Composable
fun AssistantItem(vm: ChatViewModel, m: Msg, isLast: Boolean, scale: Float) {
    val cs = MaterialTheme.colorScheme
    val clip = LocalClipboardManager.current
    val waiting = m.text.isBlank() && m.toolCalls.isEmpty() && m.reasoning.isBlank() && vm.busy && isLast
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Avatar()
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (m.reasoning.isNotBlank()) {
                var open by remember(m.id) { mutableStateOf(false) }
                val live = m.text.isBlank() && vm.busy && isLast
                Surface(
                    color = cs.surfaceVariant, shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().clickable { open = !open }
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Text(
                            if (live) "Thinking…" else if (open) "Thought process ▾" else "Thought process ▸",
                            fontSize = 12.sp, fontWeight = FontWeight.Medium
                        )
                        if (open || live) Text(
                            m.reasoning, fontSize = 12.sp, fontStyle = FontStyle.Italic,
                            color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
            if (m.steps.isNotEmpty()) ToolSteps(m.steps)
            if (waiting) TypingDots()
            if (m.error) {
                Surface(color = cs.errorContainer, shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(m.text, color = cs.onErrorContainer, fontSize = 14.sp)
                        if (isLast && !vm.busy) TextButton(onClick = { vm.regenerate() }) {
                            Icon(Icons.Default.Refresh, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp)); Text("Retry")
                        }
                    }
                }
            } else if (m.text.isNotBlank()) {
                SelectionContainer { RichText(m.text, cs.onSurface, scale) }
            }
            m.toolCalls.forEach {
                Text("→ ${it.name}(${it.args})", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = cs.onSurfaceVariant)
            }
            if (m.text.isNotBlank() && !m.error && !(vm.busy && isLast)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { clip.setText(AnnotatedString(m.text)); vm.status = "Copied" }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.ContentCopy, "Copy", Modifier.size(18.dp))
                    }
                    IconButton(onClick = { vm.speak(m) }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            if (vm.speakingId == m.id) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                            if (vm.speakingId == m.id) "Stop speaking" else "Read aloud", Modifier.size(18.dp)
                        )
                    }
                    if (isLast) IconButton(onClick = { vm.regenerate() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Refresh, "Regenerate", Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(6.dp))
                    Text(
                        listOfNotNull(m.model?.substringAfterLast('/'), m.usage).joinToString(" · "),
                        fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(vertical = 10.dp)) {
        repeat(3) { i ->
            val a by t.animateFloat(
                initialValue = 0.25f, targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(600, delayMillis = i * 150), RepeatMode.Reverse),
                label = "dot$i"
            )
            Box(Modifier.size(8.dp).alpha(a).clip(CircleShape).background(MaterialTheme.colorScheme.onSurfaceVariant))
        }
    }
}

@Composable
fun RecordingIndicator() {
    val t = rememberInfiniteTransition(label = "rec")
    val a by t.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "recAlpha"
    )
    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).alpha(a).clip(CircleShape).background(MaterialTheme.colorScheme.error))
        Spacer(Modifier.width(10.dp))
        Text("Recording… tap ■ to transcribe", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
    }
}

@Composable
fun InputBar(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(3)) { vm.addImages(it) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggleRecord() else vm.status = "Microphone permission denied"
    }
    fun onMic() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (vm.recording || granted) vm.toggleRecord() else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    val canSend = vm.draft.isNotBlank() || vm.attachments.isNotEmpty()

    Surface(
        color = cs.background,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime))
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            AnimatedVisibility(
                visible = vm.attachments.isNotEmpty(),
                enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
            ) {
                Row(
                    Modifier.padding(start = 6.dp, bottom = 8.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    vm.attachments.forEachIndexed { i, a ->
                        Box {
                            DataImage(a, 60.dp)
                            Icon(
                                Icons.Default.Close, "Remove image",
                                Modifier.align(Alignment.TopEnd).size(20.dp).clip(CircleShape)
                                    .background(cs.surface).clickable { vm.attachments.removeAt(i) }.padding(2.dp)
                            )
                        }
                    }
                }
            }
            Surface(shape = RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh) {
                Row(Modifier.padding(4.dp), verticalAlignment = Alignment.Bottom) {
                    IconButton(
                        onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        enabled = !vm.recording
                    ) { Icon(Icons.Default.Image, "Attach image") }

                    Box(Modifier.weight(1f).heightIn(min = 48.dp), contentAlignment = Alignment.CenterStart) {
                        if (vm.recording) RecordingIndicator() else TextField(
                            value = vm.draft, onValueChange = { vm.draft = it },
                            modifier = Modifier.fillMaxWidth(), maxLines = 6,
                            placeholder = { Text(if (vm.transcribing) "Transcribing…" else "Message") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                disabledIndicatorColor = Color.Transparent
                            )
                        )
                    }

                    if (vm.transcribing) {
                        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        }
                    } else if (vm.recording) {
                        FilledIconButton(
                            onClick = { onMic() },
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = cs.error, contentColor = cs.onError),
                            modifier = Modifier.padding(4.dp)
                        ) { Icon(Icons.Default.Stop, "Stop recording") }
                    } else {
                        IconButton(onClick = { onMic() }) { Icon(Icons.Default.Mic, "Voice input") }
                    }

                    if (vm.busy) {
                        FilledIconButton(onClick = { vm.stop() }, modifier = Modifier.padding(4.dp)) {
                            Icon(Icons.Default.Stop, "Stop generating")
                        }
                    } else {
                        FilledIconButton(
                            onClick = { vm.send() }, enabled = canSend && !vm.recording && !vm.transcribing,
                            modifier = Modifier.padding(4.dp)
                        ) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
                    }
                }
            }
        }
    }
}

@Composable
fun ImagePreview(url: String, onDismiss: () -> Unit) {
    val bmp = remember(url) { decodeDataUrl(url, 1) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.92f)).clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            if (bmp != null) Image(
                bitmap = bmp, contentDescription = "Image preview", contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(8.dp)
            )
            IconButton(onClick = onDismiss, modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding()) {
                Icon(Icons.Default.Close, "Close", tint = Color.White)
            }
        }
    }
}

// ============================ RICH TEXT ============================

@Composable
fun RichText(text: String, color: Color, scale: Float) {
    val parts = text.split("```")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEachIndexed { i, p ->
            if (i % 2 == 1) {
                val nl = p.indexOf('\n')
                val lang = if (nl >= 0) p.substring(0, nl).trim() else ""
                val code = if (nl >= 0) p.substring(nl + 1) else p
                CodeBlock(code.trimEnd(), lang)
            } else if (p.isNotBlank()) {
                MarkdownBlocks(p, color, scale)
            }
        }
    }
}

@Composable
fun CodeBlock(code: String, lang: String) {
    val clip = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val highlighted = remember(code, lang, dark) { highlightCode(code, lang, dark) }
    Surface(
        color = cs.surfaceVariant, shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(lang.ifBlank { "code" }, fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                IconButton(onClick = { clip.setText(AnnotatedString(code)) }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.ContentCopy, "Copy code", Modifier.size(15.dp))
                }
            }
            Text(
                highlighted, fontFamily = FontFamily.Monospace, fontSize = 12.5.sp, lineHeight = 18.sp,
                modifier = Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 4.dp)
            )
        }
    }
}

@Composable
fun DataImage(url: String, size: Dp, onClick: (() -> Unit)? = null) {
    val bmp: ImageBitmap? = remember(url) { decodeDataUrl(url, 4) }
    if (bmp != null) Image(
        bitmap = bmp, contentDescription = "Attached image", contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp)).clickable(enabled = onClick != null) { onClick?.invoke() }
    )
}

fun decodeDataUrl(url: String, sample: Int = 4): ImageBitmap? = try {
    val b = Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT)
    BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
} catch (e: Exception) { null }

// ============================ SETTINGS ============================

@Composable
fun SettingsScreen(vm: ChatViewModel, onClose: () -> Unit) {
    val s = vm.settings
    val cs = MaterialTheme.colorScheme
    val uri = LocalUriHandler.current
    var keyText by remember { mutableStateOf(vm.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<String?>(null) }
    var mcpEdit by remember { mutableStateOf<McpEdit?>(null) }
    var toolEdit by remember { mutableStateOf<ToolEdit?>(null) }
    val modelIds = vm.chatModels.map { it.id }
    val sttIds = vm.models.map { it.id }.filter { it.contains("whisper") }
        .ifEmpty { listOf("whisper-large-v3-turbo", "whisper-large-v3") }
    val ttsIds = vm.models.map { it.id }.filter { it.contains("orpheus") }
        .ifEmpty { listOf("canopylabs/orpheus-v1-english", "canopylabs/orpheus-arabic-saudi") }
    val voices = if (s.ttsModel.contains("arabic")) ARABIC_VOICES else ENGLISH_VOICES

    Column(Modifier.fillMaxSize().background(cs.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 6.dp))
            TextButton(onClick = onClose, enabled = vm.apiKey.isNotBlank()) { Text("Done") }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)
                .navigationBarsPadding().imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (vm.apiKey.isBlank()) {
                Card(colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Welcome to Groq Chat", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                        Text("1. Create a free API key on the Groq console", color = cs.onPrimaryContainer, fontSize = 14.sp)
                        Text("2. Paste it below and tap “Save & load models”", color = cs.onPrimaryContainer, fontSize = 14.sp)
                        Text("3. Start chatting", color = cs.onPrimaryContainer, fontSize = 14.sp)
                        Button(onClick = { uri.openUri("https://console.groq.com/keys") }) { Text("Get an API key") }
                    }
                }
            }

            SettingsCard("API key", Icons.Default.Key) {
                OutlinedTextField(
                    value = keyText, onValueChange = { keyText = it }, singleLine = true,
                    label = { Text("gsk_…") },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Show or hide key")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Hint("Stored encrypted on this device and only sent to api.groq.com.")
                Button(onClick = { vm.saveKey(keyText) }, enabled = keyText.isNotBlank() && !vm.loadingModels) {
                    Text(if (vm.loadingModels) "Loading models…" else "Save & load models")
                }
                if (vm.models.isNotEmpty()) Text("✓ ${vm.models.size} models available", color = cs.primary, fontSize = 13.sp)
            }

            SettingsCard("Model", Icons.Default.AutoAwesome) {
                Picker("Chat model", s.chatModel, modelIds, vm.owners) { vm.update(s.copy(chatModel = it)) }
                Picker("Vision model (used when images are attached)", s.visionModel,
                    vm.models.map { it.id }.filter(::isVisionModel), vm.owners) { vm.update(s.copy(visionModel = it)) }
                OutlinedTextField(
                    value = s.systemPrompt, onValueChange = { vm.update(s.copy(systemPrompt = it)) },
                    label = { Text("System prompt") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 6
                )
            }

            SettingsCard("Generation", Icons.Default.Tune) {
                Text("Style", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Precise" to 0.2f, "Balanced" to 0.7f, "Creative" to 1.2f).forEach { (name, v) ->
                        FilterChip(
                            selected = abs(s.temperature - v) < 0.05f,
                            onClick = { vm.update(s.copy(temperature = v)) },
                            label = { Text(name) }
                        )
                    }
                }
                LabeledSlider("Temperature", "%.2f".format(s.temperature), s.temperature, 0f..2f) { vm.update(s.copy(temperature = it)) }
                LabeledSlider("Top P", "%.2f".format(s.topP), s.topP, 0f..1f) { vm.update(s.copy(topP = it)) }
                LabeledSlider("Max completion tokens", s.maxTokens.toString(), s.maxTokens.toFloat(), 256f..8192f) {
                    vm.update(s.copy(maxTokens = ((it / 256f).roundToInt() * 256).coerceAtLeast(256)))
                }
                Picker("Service tier", s.serviceTier, listOf("on_demand", "auto", "flex", "performance")) { vm.update(s.copy(serviceTier = it)) }
                SwitchRow("Stream responses", "Show text as it is generated", s.stream) { vm.update(s.copy(stream = it)) }
            }

            SettingsCard("Reasoning", Icons.Default.Psychology) {
                Text("Effort (gpt-oss and Qwen3 models)", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("default", "none", "low", "medium", "high").forEach { e ->
                        FilterChip(
                            selected = s.reasoningEffort == e,
                            onClick = { vm.update(s.copy(reasoningEffort = e)) },
                            label = { Text(e) }
                        )
                    }
                }
                Hint("“none” only works on Qwen3; gpt-oss supports low, medium and high.")
                SwitchRow("Show reasoning", "Display the model's thinking in a collapsible block", s.showReasoning) { vm.update(s.copy(showReasoning = it)) }
            }

            SettingsCard("Tool use", Icons.Default.Build) {
                val names = vm.functionToolNames
                val modeKey = if (s.toolMode.startsWith("fn:")) "fn" else s.toolMode
                Text("When the model uses tools", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("auto" to "Auto", "off" to "Off", "required" to "Required", "fn" to "Specific").forEach { (k, label) ->
                        FilterChip(
                            selected = modeKey == k,
                            onClick = { vm.update(s.copy(toolMode = if (k == "fn") "fn:" + (names.firstOrNull() ?: "") else k)) },
                            label = { Text(label) }
                        )
                    }
                }
                if (modeKey == "fn") Picker("Tool to force", s.toolMode.removePrefix("fn:"), names) { vm.update(s.copy(toolMode = "fn:$it")) }
                Hint("Auto: the model decides. Off: no tools at all (also pauses server tools and MCP). Required / Specific: forces a function tool on the first step of each reply, then returns to Auto.")
                SwitchRow("Function tools", "Let the model call the tools below", s.tools) { vm.update(s.copy(tools = it)) }
                HorizontalDivider()
                Text("Device tools", fontWeight = FontWeight.SemiBold)
                val off = s.deviceToolsOff.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                LocalTools.names.forEach { n ->
                    SwitchRow(n, if (n == "calculate") "Evaluates a math expression" else "Returns the current date and time", n !in off) { on ->
                        val next = if (on) off - n else off + n
                        vm.update(s.copy(deviceToolsOff = next.joinToString(",")))
                    }
                }
                HorizontalDivider()
                Text("Your tools", fontWeight = FontWeight.SemiBold)
                if (vm.customTools.isEmpty()) Hint("None yet.")
                vm.customTools.forEachIndexed { i, t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { toolEdit = ToolEdit(i, t) }) {
                            Text(t.name, fontWeight = FontWeight.Medium)
                            Text(
                                "${t.kind} · ${t.description}", fontSize = 12.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
                            )
                        }
                        Switch(checked = t.enabled, onCheckedChange = { vm.updateTool(i, t.copy(enabled = it)) })
                        IconButton(onClick = { vm.removeTool(i) }) { Icon(Icons.Default.Delete, "Remove tool") }
                    }
                }
                OutlinedButton(onClick = { toolEdit = ToolEdit(-1, null) }, modifier = Modifier.fillMaxWidth()) { Text("Add custom tool") }
                Hint("Webhook calls your https URL (GET or POST) and returns the response. Static returns fixed text. Ask me pops up a question so you provide the result. Use {{param}} to insert the model's arguments.")
                toolEdit?.let { e ->
                    ToolDialog(e, vm.customTools.map { it.name }, onDismiss = { toolEdit = null }) { saved ->
                        if (e.index < 0) vm.addTool(saved) else vm.updateTool(e.index, saved)
                        toolEdit = null
                    }
                }
            }

            SettingsCard("Output format", Icons.Default.Code) {
                SwitchRow("JSON mode", "Forces valid JSON (turns off streaming and tools). Mention “JSON” in your prompt.", s.jsonMode) { vm.update(s.copy(jsonMode = it)) }
            }

            SettingsCard("Server tools", Icons.Default.Language) {
                SwitchRow("Web browsing", "Groq's browser_search tool (gpt-oss models)", s.browserSearch) { vm.update(s.copy(browserSearch = it)) }
                SwitchRow("Code execution", "Runs Python on Groq's servers (code_interpreter)", s.codeExecution) { vm.update(s.copy(codeExecution = it)) }
                Hint("These run on Groq's servers and only work with gpt-oss models, so replies arrive all at once. Tip: set Reasoning effort to low when browsing.")
                if ((s.browserSearch || s.codeExecution) && !isGptOss(s.chatModel)) {
                    Text(
                        "⚠ Your selected model (${s.chatModel.substringAfterLast('/')}) can't use these tools, so they are skipped. Select a gpt-oss model to use them. Your model is never swapped automatically.",
                        fontSize = 12.sp, color = cs.error
                    )
                }
                HorizontalDivider()
                Text("Remote MCP servers & connectors", fontWeight = FontWeight.SemiBold)
                if (vm.mcpServers.isEmpty()) Hint("None added yet.")
                vm.mcpServers.forEachIndexed { i, srv ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { mcpEdit = McpEdit(i, srv, srv.isConnector) }) {
                            Text(srv.label, fontWeight = FontWeight.Medium)
                            Text(
                                if (srv.isConnector) srv.connector else srv.url, fontSize = 12.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
                            )
                        }
                        Switch(checked = srv.enabled, onCheckedChange = { vm.updateMcp(i, srv.copy(enabled = it)) })
                        IconButton(onClick = { vm.removeMcp(i) }) { Icon(Icons.Default.Delete, "Remove server") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { mcpEdit = McpEdit(-1, null, false) }, modifier = Modifier.weight(1f)) { Text("Add server") }
                    OutlinedButton(onClick = { mcpEdit = McpEdit(-1, null, true) }, modifier = Modifier.weight(1f)) { Text("Google connector") }
                }
                Hint("While an MCP server is enabled, requests use Groq's Responses API: local tools are paused and replies are not streamed. MCP servers can see your conversation, so only add servers you trust.")
                mcpEdit?.let { e ->
                    McpDialog(e, onDismiss = { mcpEdit = null }) { saved ->
                        if (e.index < 0) vm.addMcp(saved) else vm.updateMcp(e.index, saved)
                        mcpEdit = null
                    }
                }
            }

            SettingsCard("Voice", Icons.Default.Mic) {
                Picker("Speech-to-text model", s.sttModel, sttIds, vm.owners) { vm.update(s.copy(sttModel = it)) }
                OutlinedTextField(
                    value = s.sttLanguage, onValueChange = { vm.update(s.copy(sttLanguage = it)) }, singleLine = true,
                    label = { Text("Language code (e.g. en) – blank = auto") }, modifier = Modifier.fillMaxWidth()
                )
                SwitchRow("Translate speech to English", "Uses whisper-large-v3", s.translate) { vm.update(s.copy(translate = it)) }
                HorizontalDivider()
                Picker("Text-to-speech model", s.ttsModel, ttsIds, vm.owners) { m ->
                    vm.update(s.copy(ttsModel = m, ttsVoice = if (m.contains("arabic")) ARABIC_VOICES.first() else ENGLISH_VOICES.last()))
                }
                Text("Voice", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    voices.forEach { v ->
                        FilterChip(selected = s.ttsVoice == v, onClick = { vm.update(s.copy(ttsVoice = v)) }, label = { Text(v) })
                    }
                }
                SwitchRow("Read replies aloud", "Speaks each answer automatically", s.autoSpeak) { vm.update(s.copy(autoSpeak = it)) }
            }

            SettingsCard("Appearance", Icons.Default.Palette) {
                Text("Theme", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (k, label) ->
                        FilterChip(selected = s.theme == k, onClick = { vm.update(s.copy(theme = k)) }, label = { Text(label) })
                    }
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    SwitchRow("Use system colors", "Match your wallpaper (Material You)", s.dynamicColor) { vm.update(s.copy(dynamicColor = it)) }
                }
                LabeledSlider("Text size", "${(s.fontScale * 100).roundToInt()}%", s.fontScale, 0.85f..1.4f) { vm.update(s.copy(fontScale = it)) }
            }

            SettingsCard("Data", Icons.Default.Delete) {
                OutlinedButton(onClick = { confirm = "chats" }, modifier = Modifier.fillMaxWidth()) { Text("Delete all chats") }
                OutlinedButton(onClick = { confirm = "reset" }, modifier = Modifier.fillMaxWidth()) { Text("Reset settings") }
                OutlinedButton(
                    onClick = { confirm = "key" }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error)
                ) { Text("Remove API key") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    confirm?.let { what ->
        val title = when (what) {
            "chats" -> "Delete all chats?"
            "reset" -> "Reset settings?"
            else -> "Remove API key?"
        }
        val body = when (what) {
            "chats" -> "Every saved conversation is removed from this device."
            "reset" -> "All options return to their defaults. Your API key is kept."
            else -> "You will need to paste your key again to use the app."
        }
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = {
                TextButton(onClick = {
                    when (what) {
                        "chats" -> vm.clearAllChats()
                        "reset" -> vm.update(com.example.groqchat.Settings())
                        else -> { vm.saveKey(""); keyText = "" }
                    }
                    confirm = null
                }) { Text("Confirm") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun SettingsCard(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
fun Hint(text: String) {
    Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title)
            Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun LabeledSlider(label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Row { Text(label, modifier = Modifier.weight(1f)); Text(valueText, color = MaterialTheme.colorScheme.primary) }
        Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun Picker(
    label: String, value: String, options: List<String>,
    owners: Map<String, String> = emptyMap(), onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(value.ifBlank { "—" }, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ArrowDropDown, null)
        }
    }
    if (open) OptionSheet(
        title = label,
        options = (listOf(value) + options).filter { it.isNotBlank() }.distinct()
            .map { Opt(it, "", owners[it]?.ifBlank { "Other" } ?: "") },
        selected = setOf(value),
        onSelect = onSelect,
        onDismiss = { open = false }
    )
}

data class Opt(val id: String, val sub: String = "", val group: String = "")

/** Scrollable, searchable bottom sheet. Options with a group are listed under publisher headers. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptionSheet(
    title: String,
    options: List<Opt>,
    selected: Set<String>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var q by remember { mutableStateOf("") }
    val query = q.trim()
    val shown = options.filter { query.isEmpty() || it.id.contains(query, true) || it.group.contains(query, true) }
    val grouped = shown.groupBy { it.group }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.85f).navigationBarsPadding()) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
            if (options.size > 6) OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text("Search model or publisher") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (options.isEmpty()) Text(
                "Nothing to show yet. Save your API key in Settings to load the list.",
                modifier = Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LazyColumn(Modifier.weight(1f)) {
                grouped.forEach { (g, list) ->
                    if (g.isNotBlank()) item(key = "header_$g") {
                        Text(
                            "$g  ·  ${list.size}", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 20.dp, vertical = 6.dp)
                        )
                    }
                    items(list, key = { "$g/${it.id}" }) { o ->
                        ListItem(
                            headlineContent = { Text(o.id) },
                            supportingContent = if (o.sub.isNotBlank()) ({ Text(o.sub) }) else null,
                            trailingContent = if (o.id in selected) ({ Icon(Icons.Default.Check, "Selected") }) else null,
                            modifier = Modifier.clickable { onSelect(o.id); onDismiss() }
                        )
                    }
                }
            }
        }
    }
}

// ============================ SERVER TOOLS ============================

@Composable
fun ToolSteps(steps: List<ToolStep>) {
    val cs = MaterialTheme.colorScheme
    var open by remember(steps) { mutableStateOf(false) }
    Surface(
        color = cs.surfaceVariant, shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().clickable { open = !open }
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                "🛠 Used ${steps.size} tool step${if (steps.size == 1) "" else "s"} ${if (open) "▾" else "▸"}",
                fontSize = 12.sp, fontWeight = FontWeight.Medium
            )
            if (open) steps.forEach { st ->
                Column {
                    Text(st.title.ifBlank { st.kind }, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    if (st.detail.isNotBlank()) Text(
                        st.detail, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = cs.onSurfaceVariant,
                        maxLines = 12, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

data class McpEdit(val index: Int, val server: McpServer?, val connector: Boolean)

private val CONNECTORS = listOf(
    "Gmail" to "connector_gmail",
    "Google Calendar" to "connector_googlecalendar",
    "Google Drive" to "connector_googledrive",
)

@Composable
fun McpDialog(edit: McpEdit, onDismiss: () -> Unit, onSave: (McpServer) -> Unit) {
    val init = edit.server
    val isConn = edit.connector
    val uri = LocalUriHandler.current
    var label by remember { mutableStateOf(init?.label ?: "") }
    var url by remember { mutableStateOf(init?.url ?: "") }
    var connector by remember { mutableStateOf(init?.connector?.ifBlank { null } ?: CONNECTORS.first().second) }
    var header by remember { mutableStateOf(init?.headerName ?: "Authorization") }
    var token by remember { mutableStateOf(init?.token ?: "") }
    var desc by remember { mutableStateOf(init?.description ?: "") }
    var allowed by remember { mutableStateOf(init?.allowedTools ?: "") }
    val valid = if (isConn) token.isNotBlank() else (label.isNotBlank() && url.trim().startsWith("https://"))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isConn) "Google connector" else "MCP server") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isConn) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CONNECTORS.forEach { (name, id) ->
                            FilterChip(selected = connector == id, onClick = { connector = id }, label = { Text(name) })
                        }
                    }
                    OutlinedTextField(
                        value = token, onValueChange = { token = it }, singleLine = true,
                        label = { Text("Google OAuth access token") },
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                    )
                    Hint("Read-only access. Tokens last about an hour; create one in Google's OAuth Playground using the scope for this connector (gmail.readonly, calendar.events or drive.readonly).")
                    TextButton(onClick = { uri.openUri("https://developers.google.com/oauthplayground") }) { Text("Open OAuth Playground") }
                } else {
                    OutlinedTextField(
                        value = label, onValueChange = { label = it }, singleLine = true,
                        label = { Text("Name (e.g. Huggingface)") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = url, onValueChange = { url = it }, singleLine = true,
                        label = { Text("Server URL (https://…)") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = header, onValueChange = { header = it }, singleLine = true,
                        label = { Text("Auth header name") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = token, onValueChange = { token = it }, singleLine = true,
                        label = { Text("Token / key (optional)") },
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = desc, onValueChange = { desc = it },
                        label = { Text("What this server does (helps the model)") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = allowed, onValueChange = { allowed = it }, singleLine = true,
                        label = { Text("Allowed tools, comma-separated (optional)") }, modifier = Modifier.fillMaxWidth()
                    )
                }
                Hint("The token is stored encrypted on this device and sent only with your requests to Groq.")
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                val name = CONNECTORS.firstOrNull { it.second == connector }?.first ?: "Connector"
                onSave(
                    McpServer(
                        label = if (isConn) name else label.trim(),
                        url = if (isConn) "" else url.trim(),
                        connector = if (isConn) connector else "",
                        headerName = header.trim().ifBlank { "Authorization" },
                        token = token.trim(), description = desc.trim(), allowedTools = allowed.trim(),
                        enabled = init?.enabled ?: true
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ============================ CUSTOM TOOLS ============================

data class ToolEdit(val index: Int, val tool: CustomTool?)

@Composable
fun ToolDialog(edit: ToolEdit, taken: List<String>, onDismiss: () -> Unit, onSave: (CustomTool) -> Unit) {
    val init = edit.tool
    var name by remember { mutableStateOf(init?.name ?: "") }
    var desc by remember { mutableStateOf(init?.description ?: "") }
    var params by remember { mutableStateOf(init?.params ?: "") }
    var kind by remember { mutableStateOf(init?.kind ?: "webhook") }
    var response by remember { mutableStateOf(init?.response ?: "") }
    var method by remember { mutableStateOf(init?.method ?: "GET") }
    var url by remember { mutableStateOf(init?.url ?: "") }
    var headers by remember { mutableStateOf(init?.headers ?: "") }
    val others = taken.filterIndexed { i, _ -> i != edit.index }
    val nameError = when {
        name.isBlank() -> null
        !CustomTools.NAME.matches(name) -> "Letters, numbers, _ or - only (max 64)"
        name in others || name in LocalTools.names -> "That name is already used"
        else -> null
    }
    val valid = name.isNotBlank() && nameError == null && desc.isNotBlank() && when (kind) {
        "webhook" -> url.trim().startsWith("https://")
        "static" -> response.isNotBlank()
        else -> true
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (init == null) "New tool" else "Edit tool") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name (e.g. get_weather)") },
                    isError = nameError != null, supportingText = { nameError?.let { Text(it) } },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc, onValueChange = { desc = it },
                    label = { Text("What it does (the model reads this)") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = params, onValueChange = { params = it }, minLines = 2,
                    label = { Text("Parameters, one per line") },
                    supportingText = { Text("name type[*] description\ne.g.  city string* City name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Types: string, number, integer, boolean. A * after the type means required.", fontSize = 11.sp)
                Text("When the model calls it", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("webhook" to "Webhook", "static" to "Static", "ask" to "Ask me").forEach { (k, label) ->
                        FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(label) })
                    }
                }
                when (kind) {
                    "webhook" -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("GET", "POST").forEach { m ->
                                FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m) })
                            }
                        }
                        OutlinedTextField(
                            value = url, onValueChange = { url = it }, singleLine = true,
                            label = { Text("https:// URL, e.g. …?q={{city}}") }, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = headers, onValueChange = { headers = it }, minLines = 2,
                            label = { Text("Headers, one per line (optional)") },
                            supportingText = { Text("Authorization: Bearer abc123") }, modifier = Modifier.fillMaxWidth()
                        )
                        Hint("POST sends the model's arguments as JSON. Only the first 4000 characters of the reply are returned to the model.")
                    }
                    "static" -> OutlinedTextField(
                        value = response, onValueChange = { response = it }, minLines = 2,
                        label = { Text("Result text (use {{param}})") }, modifier = Modifier.fillMaxWidth()
                    )
                    else -> Hint("A dialog will ask you to type the result each time the model calls this tool.")
                }
                Hint("Tools are stored encrypted on this device. Webhooks run from your phone, so only use URLs you trust.")
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                onSave(
                    CustomTool(
                        name = name.trim(), description = desc.trim(), params = params.trim(), kind = kind,
                        response = response, method = method, url = url.trim(), headers = headers.trim(),
                        enabled = init?.enabled ?: true
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
