package com.example.groqchat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** User-defined function tools: schema building and execution (static text or https webhook). */
object CustomTools {
    val NAME = Regex("^[a-zA-Z0-9_-]{1,64}$")
    private val PARAM_NAME = Regex("^[A-Za-z_][A-Za-z0-9_]*$")
    private val PLACEHOLDER = Regex("\\{\\{\\s*(\\w+)\\s*\\}\\}")
    private val TYPES = setOf("string", "number", "integer", "boolean")

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    fun valid(t: CustomTool): Boolean =
        NAME.matches(t.name) && (t.kind != "webhook" || t.url.trim().startsWith("https://"))

    /** One parameter per line:  name type[*] description   (a * after the type marks it required). */
    fun schema(params: String): JSONObject {
        val props = JSONObject()
        val required = JSONArray()
        params.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
            val parts = line.split(Regex("\\s+"), limit = 3)
            val name = parts[0]
            if (!PARAM_NAME.matches(name)) return@forEach
            val rawType = parts.getOrNull(1) ?: "string"
            val type = rawType.trimEnd('*').lowercase().let { if (it in TYPES) it else "string" }
            val desc = parts.getOrNull(2) ?: ""
            val p = JSONObject().put("type", type)
            if (desc.isNotBlank()) p.put("description", desc)
            props.put(name, p)
            if (rawType.endsWith("*")) required.put(name)
        }
        return JSONObject().put("type", "object").put("properties", props).put("required", required)
    }

    fun definition(t: CustomTool): JSONObject = JSONObject().put("type", "function").put(
        "function", JSONObject()
            .put("name", t.name)
            .put("description", t.description.ifBlank { t.name })
            .put("parameters", schema(t.params))
    )

    /** Replaces {{param}} placeholders with values from the model's JSON arguments. */
    fun fill(template: String, args: String, encode: Boolean = false): String {
        val obj = try { if (args.isBlank()) JSONObject() else JSONObject(args) } catch (e: Exception) { JSONObject() }
        return PLACEHOLDER.replace(template) { m ->
            val v = if (obj.isNull(m.groupValues[1])) "" else obj.opt(m.groupValues[1]).toString()
            if (encode) URLEncoder.encode(v, "UTF-8") else v
        }
    }

    suspend fun webhook(t: CustomTool, args: String): String = withContext(Dispatchers.IO) {
        try {
            val url = fill(t.url.trim(), args, encode = true)
            if (!url.startsWith("https://")) return@withContext "Error: webhook URL must start with https://"
            val rb = Request.Builder().url(url)
            t.headers.lines().forEach { l ->
                val i = l.indexOf(':')
                if (i > 0) rb.header(l.substring(0, i).trim(), fill(l.substring(i + 1).trim(), args))
            }
            if (t.method == "POST") {
                val body = if (args.isBlank()) "{}" else args
                rb.post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
            } else {
                rb.get()
            }
            client.newCall(rb.build()).execute().use { r ->
                val text = r.body?.string().orEmpty().take(4000)
                if (r.isSuccessful) text.ifBlank { "(empty response)" } else "HTTP ${r.code}: $text"
            }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
}
