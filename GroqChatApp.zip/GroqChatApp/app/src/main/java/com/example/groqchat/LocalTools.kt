package com.example.groqchat

import org.json.JSONArray
import org.json.JSONObject
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.*

/** Local function-calling tools executed on the device and returned to the model. */
object LocalTools {
    private fun fn(name: String, desc: String, props: JSONObject, required: List<String>) =
        JSONObject().put("type", "function").put(
            "function", JSONObject().put("name", name).put("description", desc).put(
                "parameters", JSONObject().put("type", "object").put("properties", props)
                    .put("required", JSONArray(required))
            )
        )

    val definitions: JSONArray = JSONArray().apply {
        put(fn(
            "get_current_time",
            "Get the current date and time, optionally for an IANA time zone such as Asia/Tokyo.",
            JSONObject().put("timezone", JSONObject().put("type", "string").put("description", "IANA zone id")),
            emptyList()
        ))
        put(fn(
            "calculate",
            "Evaluate a math expression. Supports + - * / % ^ parentheses, pi, e, sqrt, sin, cos, tan, ln, log, abs.",
            JSONObject().put("expression", JSONObject().put("type", "string").put("description", "e.g. (3+4)*sqrt(2)")),
            listOf("expression")
        ))
    }

    fun run(name: String, args: String): String = try {
        val a = if (args.isBlank()) JSONObject() else JSONObject(args)
        when (name) {
            "get_current_time" -> {
                val z = a.str("timezone").ifBlank { ZoneId.systemDefault().id }
                ZonedDateTime.now(ZoneId.of(z)).format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy HH:mm:ss (z)"))
            }
            "calculate" -> {
                val v = Parser(a.str("expression")).parse()
                if (v == v.toLong().toDouble() && abs(v) < 1e15) v.toLong().toString() else v.toString()
            }
            else -> "Unknown tool: $name"
        }
    } catch (e: Exception) { "Error: ${e.message}" }

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); skip(); if (i < s.length) error("Unexpected '${s[i]}'"); return v }
        fun skip() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun eat(c: Char): Boolean { skip(); if (i < s.length && s[i] == c) { i++; return true }; return false }
        fun expr(): Double { var v = term(); while (true) { if (eat('+')) v += term() else if (eat('-')) v -= term() else return v } }
        fun term(): Double {
            var v = factor()
            while (true) { if (eat('*')) v *= factor() else if (eat('/')) v /= factor() else if (eat('%')) v %= factor() else return v }
        }
        fun factor(): Double { val b = unary(); return if (eat('^')) b.pow(factor()) else b }
        fun unary(): Double { if (eat('-')) return -unary(); if (eat('+')) return unary(); return atom() }
        fun atom(): Double {
            skip()
            if (eat('(')) { val v = expr(); if (!eat(')')) error("Missing )"); return v }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st != i) return s.substring(st, i).toDouble()
            while (i < s.length && s[i].isLetter()) i++
            val name = s.substring(st, i)
            if (name.isEmpty()) error("Unexpected input")
            if (name == "pi") return PI
            if (name == "e") return E
            if (!eat('(')) error("Unknown name '$name'")
            val x = expr()
            if (!eat(')')) error("Missing )")
            return when (name) {
                "sqrt" -> sqrt(x); "sin" -> sin(x); "cos" -> cos(x); "tan" -> tan(x)
                "ln" -> ln(x); "log" -> log10(x); "abs" -> abs(x)
                else -> error("Unknown function '$name'")
            }
        }
    }
}
