package com.example.groqchat

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

@Composable
fun GroqApp(vm: ChatViewModel) {
    var showSettings by remember { mutableStateOf(vm.apiKey.isBlank()) }
    val ctx = LocalContext.current
    LaunchedEffect(vm.status) {
        vm.status?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.status = null }
    }
    BackHandler(showSettings && vm.apiKey.isNotBlank()) { showSettings = false }
    if (showSettings) SettingsScreen(vm) { showSettings = false } else ChatScreen(vm) { showSettings = true }
}

// ============================ CHAT ============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, openSettings: () -> Unit) {
    val listState = rememberLazyListState()
    val msgs = vm.messages.toList()
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(msgs.size) { listState.scrollToItem(0) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        TopAppBar(
            title = {
                Box {
                    Column(Modifier.clickable { menu = true }) {
                        Text("Groq Chat", fontWeight = FontWeight.Bold)
                        Text(
                            vm.settings.chatModel, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        val list = vm.chatModels
                        if (list.isEmpty()) DropdownMenuItem(text = { Text("No models loaded – check API key") }, onClick = { menu = false })
                        list.forEach { m ->
                            DropdownMenuItem(
                                text = { Column { Text(m.id); Text("${m.owner} · ${m.ctx / 1000}K context", fontSize = 11.sp) } },
                                onClick = { vm.update(vm.settings.copy(chatModel = m.id)); menu = false }
                            )
                        }
                    }
                }
            },
            actions = {
                IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "New chat") }
                IconButton(onClick = openSettings) { Icon(Icons.Default.Settings, "Settings") }
            }
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) {
                Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Ask anything", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Type, talk with the mic, or attach up to 3 images.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    state = listState, reverseLayout = true,
                    contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val rev = msgs.asReversed()
                    items(rev.size, key = { rev[it].id }) { i -> MessageItem(vm, rev[i], isLast = i == 0) }
                }
            }
        }
        InputBar(vm)
    }
}

@Composable
fun MessageItem(vm: ChatViewModel, m: Msg, isLast: Boolean) {
    val cs = MaterialTheme.colorScheme
    when (m.role) {
        Role.USER -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
            Surface(
                color = cs.primaryContainer,
                shape = RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp),
                modifier = Modifier.widthIn(max = 320.dp)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (m.images.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        m.images.forEach { DataImage(it, 72.dp) }
                    }
                    if (m.text.isNotBlank()) SelectionContainer { Text(m.text, color = cs.onPrimaryContainer) }
                }
            }
        }
        Role.TOOL -> Text(
            "🔧 ${m.toolName}: ${m.text}", fontSize = 12.sp, color = cs.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(cs.surfaceVariant).padding(8.dp)
        )
        Role.ASSISTANT -> AssistantItem(vm, m, isLast)
        Role.SYSTEM -> {}
    }
}

@Composable
fun AssistantItem(vm: ChatViewModel, m: Msg, isLast: Boolean) {
    val cs = MaterialTheme.colorScheme
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (m.reasoning.isNotBlank()) {
            var open by remember(m.id) { mutableStateOf(false) }
            Surface(
                color = cs.surfaceVariant, shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().clickable { open = !open }
            ) {
                Column(Modifier.padding(8.dp)) {
                    Text(if (open) "Thinking ▾" else "Thinking ▸", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    if (open) Text(m.reasoning, fontSize = 12.sp, fontStyle = FontStyle.Italic, color = cs.onSurfaceVariant)
                }
            }
        }
        if (m.text.isBlank() && m.toolCalls.isEmpty() && m.reasoning.isBlank() && vm.busy && isLast) {
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
        }
        if (m.error) Text(m.text, color = cs.error)
        else if (m.text.isNotBlank()) SelectionContainer { RichText(m.text, cs.onSurface) }
        m.toolCalls.forEach {
            Text("→ ${it.name}(${it.args})", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = cs.onSurfaceVariant)
        }
        if (m.text.isNotBlank() && !m.error) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { clip.setText(AnnotatedString(m.text)) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ContentCopy, "Copy", Modifier.size(18.dp))
                }
                IconButton(onClick = { vm.speak(m) }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        if (vm.speakingId == m.id) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                        "Speak", Modifier.size(18.dp)
                    )
                }
                if (isLast && !vm.busy) IconButton(onClick = { vm.regenerate() }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Refresh, "Regenerate", Modifier.size(18.dp))
                }
                Spacer(Modifier.width(6.dp))
                Text(
                    listOfNotNull(m.model, m.usage).joinToString(" · "),
                    fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun InputBar(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(3)) { vm.addImages(it) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggleRecord() else vm.status = "Microphone permission denied"
    }
    fun onMic() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (vm.recording || granted) vm.toggleRecord() else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    Surface(
        tonalElevation = 3.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime))
    ) {
        Column(Modifier.padding(8.dp)) {
            if (vm.attachments.isNotEmpty()) {
                Row(Modifier.padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    vm.attachments.forEachIndexed { i, a ->
                        Box {
                            DataImage(a, 56.dp)
                            Icon(
                                Icons.Default.Close, "Remove",
                                Modifier.align(Alignment.TopEnd).size(18.dp).clip(RoundedCornerShape(9.dp))
                                    .background(cs.surface).clickable { vm.attachments.removeAt(i) }
                            )
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.Bottom) {
                IconButton(onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) { Icon(Icons.Default.Image, "Attach image") }
                IconButton(onClick = { onMic() }) {
                    if (vm.transcribing) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    else Icon(
                        if (vm.recording) Icons.Default.Stop else Icons.Default.Mic, "Microphone",
                        tint = if (vm.recording) cs.error else LocalContentColor.current
                    )
                }
                OutlinedTextField(
                    value = vm.draft, onValueChange = { vm.draft = it },
                    modifier = Modifier.weight(1f), maxLines = 6,
                    placeholder = { Text(if (vm.recording) "Listening… tap stop" else "Message") }
                )
                if (vm.busy) IconButton(onClick = { vm.stop() }) { Icon(Icons.Default.Stop, "Stop generating") }
                else IconButton(
                    onClick = { vm.send() },
                    enabled = vm.draft.isNotBlank() || vm.attachments.isNotEmpty()
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
            }
        }
    }
}

// ============================ RICH TEXT ============================

@Composable
fun RichText(text: String, color: Color) {
    val parts = text.split("```")
    val codeBg = MaterialTheme.colorScheme.surfaceVariant
    Column {
        parts.forEachIndexed { i, p ->
            if (i % 2 == 1) {
                val nl = p.indexOf('\n')
                val lang = if (nl >= 0) p.substring(0, nl).trim() else ""
                val code = if (nl >= 0) p.substring(nl + 1) else p
                CodeBlock(code.trimEnd(), lang)
            } else if (p.isNotBlank()) {
                Text(markdown(p.trim('\n'), codeBg), color = color, fontSize = 15.sp, lineHeight = 22.sp)
            }
        }
    }
}

@Composable
fun CodeBlock(code: String, lang: String) {
    val clip = LocalClipboardManager.current
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(Modifier.padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(lang.ifBlank { "code" }, fontSize = 11.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { clip.setText(AnnotatedString(code)) }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.ContentCopy, "Copy code", Modifier.size(14.dp))
                }
            }
            Text(
                code, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                modifier = Modifier.horizontalScroll(rememberScrollState())
            )
        }
    }
}

fun markdown(s: String, codeBg: Color): AnnotatedString = buildAnnotatedString {
    val lines = s.split("\n")
    lines.forEachIndexed { li, raw ->
        val t = raw.trimStart()
        when {
            t.startsWith("#") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 17.sp)) { append(t.trimStart('#').trim()) }
            t.startsWith("- ") || t.startsWith("* ") -> { append("• "); inline(t.drop(2), codeBg) }
            else -> inline(raw, codeBg)
        }
        if (li < lines.lastIndex) append("\n")
    }
}

private fun AnnotatedString.Builder.inline(s: String, codeBg: Color) {
    var i = 0
    while (i < s.length) {
        if (s.startsWith("**", i)) {
            val e = s.indexOf("**", i + 2)
            if (e > 0) { withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, e)) }; i = e + 2; continue }
        }
        if (s[i] == '`') {
            val e = s.indexOf('`', i + 1)
            if (e > 0) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(s.substring(i + 1, e)) }
                i = e + 1; continue
            }
        }
        append(s[i]); i++
    }
}

@Composable
fun DataImage(url: String, size: Dp) {
    val bmp: ImageBitmap? = remember(url) { decodeDataUrl(url) }
    if (bmp != null) Image(
        bitmap = bmp, contentDescription = "Attached image", contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(RoundedCornerShape(8.dp))
    )
}

fun decodeDataUrl(url: String): ImageBitmap? = try {
    val b = Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT)
    BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap()
} catch (e: Exception) { null }

// ============================ SETTINGS ============================

@Composable
fun SettingsScreen(vm: ChatViewModel, onClose: () -> Unit) {
    val s = vm.settings
    var keyText by remember { mutableStateOf(vm.apiKey) }
    val modelIds = vm.chatModels.map { it.id }
    val sttIds = vm.models.map { it.id }.filter { it.contains("whisper") }
        .ifEmpty { listOf("whisper-large-v3-turbo", "whisper-large-v3") }
    val ttsIds = vm.models.map { it.id }.filter { it.contains("orpheus") }
        .ifEmpty { listOf("canopylabs/orpheus-v1-english", "canopylabs/orpheus-arabic-saudi") }
    val voices = if (s.ttsModel.contains("arabic")) ARABIC_VOICES else ENGLISH_VOICES

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 8.dp))
            IconButton(onClick = onClose, enabled = vm.apiKey.isNotBlank()) { Icon(Icons.Default.Close, "Close") }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)
                .navigationBarsPadding().imePadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Section("Groq API key")
            OutlinedTextField(
                value = keyText, onValueChange = { keyText = it }, singleLine = true,
                label = { Text("gsk_…") }, visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Text("Create a key at console.groq.com/keys. It is stored encrypted on this device only.", fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = { vm.saveKey(keyText) }, enabled = keyText.isNotBlank() && !vm.loadingModels) {
                Text(if (vm.loadingModels) "Loading models…" else "Save & load models")
            }

            Section("Chat")
            Picker("Model", s.chatModel, modelIds) { vm.update(s.copy(chatModel = it)) }
            Picker("Vision model (used when images are attached)", s.visionModel, vm.models.map { it.id }.filter(::isVisionModel)) {
                vm.update(s.copy(visionModel = it))
            }
            OutlinedTextField(
                value = s.systemPrompt, onValueChange = { vm.update(s.copy(systemPrompt = it)) },
                label = { Text("System prompt") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 6
            )
            LabeledSlider("Temperature", "%.2f".format(s.temperature), s.temperature, 0f..2f) { vm.update(s.copy(temperature = it)) }
            LabeledSlider("Top P", "%.2f".format(s.topP), s.topP, 0f..1f) { vm.update(s.copy(topP = it)) }
            LabeledSlider("Max completion tokens", s.maxTokens.toString(), s.maxTokens.toFloat(), 256f..8192f) {
                vm.update(s.copy(maxTokens = ((it / 256f).roundToInt() * 256).coerceAtLeast(256)))
            }
            Picker("Service tier", s.serviceTier, listOf("on_demand", "auto", "flex", "performance")) { vm.update(s.copy(serviceTier = it)) }
            SwitchRow("Stream responses", "Show tokens as they arrive", s.stream) { vm.update(s.copy(stream = it)) }
            SwitchRow("JSON mode", "Forces valid JSON output (disables streaming and tools). Mention “JSON” in your prompt.", s.jsonMode) { vm.update(s.copy(jsonMode = it)) }
            SwitchRow("Local tools", "Let the model call get_current_time and calculate on your device", s.tools) { vm.update(s.copy(tools = it)) }

            Section("Reasoning (gpt-oss, Qwen3 models)")
            Picker("Reasoning effort", s.reasoningEffort, listOf("default", "none", "low", "medium", "high")) { vm.update(s.copy(reasoningEffort = it)) }
            Text("“none” is only valid for Qwen3 models; gpt-oss supports low / medium / high.", fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            SwitchRow("Show reasoning", "Display the model's thinking in a collapsible block", s.showReasoning) { vm.update(s.copy(showReasoning = it)) }

            Section("Speech to text (mic)")
            Picker("Whisper model", s.sttModel, sttIds) { vm.update(s.copy(sttModel = it)) }
            OutlinedTextField(
                value = s.sttLanguage, onValueChange = { vm.update(s.copy(sttLanguage = it)) }, singleLine = true,
                label = { Text("Language (ISO-639-1, e.g. en – blank = auto)") }, modifier = Modifier.fillMaxWidth()
            )
            SwitchRow("Translate to English", "Uses /audio/translations with whisper-large-v3", s.translate) { vm.update(s.copy(translate = it)) }

            Section("Text to speech")
            Picker("Orpheus model", s.ttsModel, ttsIds) { m ->
                vm.update(s.copy(ttsModel = m, ttsVoice = if (m.contains("arabic")) ARABIC_VOICES.first() else ENGLISH_VOICES.last()))
            }
            Picker("Voice", s.ttsVoice, voices) { vm.update(s.copy(ttsVoice = it)) }
            SwitchRow("Auto-speak replies", "Read each answer aloud (max 200 chars per request, first ~10 chunks)", s.autoSpeak) { vm.update(s.copy(autoSpeak = it)) }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun Section(title: String) {
    Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun LabeledSlider(label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Row { Text(label, modifier = Modifier.weight(1f)); Text(valueText, color = MaterialTheme.colorScheme.primary) }
        Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun Picker(label: String, value: String, options: List<String>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(value.ifBlank { "—" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                (listOf(value) + options).filter { it.isNotBlank() }.distinct().forEach { o ->
                    DropdownMenuItem(text = { Text(o) }, onClick = { onSelect(o); open = false })
                }
            }
        }
    }
}
