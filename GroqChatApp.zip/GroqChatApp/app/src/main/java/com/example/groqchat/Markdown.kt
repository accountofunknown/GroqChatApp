package com.example.groqchat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ============================ PARSER ============================

sealed interface MdBlock
data class MdPara(val text: String) : MdBlock
data class MdHeading(val level: Int, val text: String) : MdBlock
data class MdBullet(val indent: Int, val marker: String, val text: String) : MdBlock
data class MdQuote(val text: String) : MdBlock
data class MdTable(val rows: List<List<String>>) : MdBlock
object MdRule : MdBlock

private val RULE = Regex("^(-{3,}|\\*{3,}|_{3,})$")
private val HEADING = Regex("^#{1,6}\\s+.*$")
private val UL = Regex("^(\\s*)[-*+]\\s+(.*)$")
private val OL = Regex("^(\\s*)(\\d{1,3})[.)]\\s+(.*)$")
private val TABLE_SEP = Regex("^\\s*\\|?\\s*:?-{3,}:?\\s*(\\|\\s*:?-{3,}:?\\s*)*\\|?\\s*$")
private const val ESCAPABLE = "\\`*_{}[]()#+-.!|>~"
private val BULLETS = listOf("•", "◦", "▪", "▪")

private fun splitRow(line: String): List<String> {
    var s = line.trim()
    if (s.startsWith("|")) s = s.drop(1)
    if (s.endsWith("|")) s = s.dropLast(1)
    return s.split("|").map { it.trim() }
}

private fun taskText(s: String): String = when {
    s.startsWith("[ ] ") -> "☐ " + s.drop(4)
    s.startsWith("[x] ", ignoreCase = true) -> "☑ " + s.drop(4)
    else -> s
}

fun parseMarkdown(src: String): List<MdBlock> {
    val lines = src.replace("\r\n", "\n").replace('\r', '\n').split('\n')
    val out = mutableListOf<MdBlock>()
    val para = StringBuilder()
    fun flush() {
        if (para.isNotBlank()) out.add(MdPara(para.toString().trim()))
        para.setLength(0)
    }
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val t = line.trim()
        if (t.isEmpty()) { flush(); i++; continue }

        if (t.contains('|') && i + 1 < lines.size && lines[i + 1].contains('-') && TABLE_SEP.matches(lines[i + 1])) {
            flush()
            val rows = mutableListOf(splitRow(t))
            i += 2
            while (i < lines.size && lines[i].isNotBlank() && lines[i].contains('|')) {
                rows.add(splitRow(lines[i])); i++
            }
            out.add(MdTable(rows))
            continue
        }
        if (RULE.matches(t)) { flush(); out.add(MdRule); i++; continue }
        if (HEADING.matches(t)) {
            flush()
            val n = t.takeWhile { it == '#' }.length
            out.add(MdHeading(n, t.drop(n).trim()))
            i++; continue
        }
        if (t.startsWith(">")) {
            flush()
            val q = StringBuilder()
            while (i < lines.size && lines[i].trim().startsWith(">")) {
                if (q.isNotEmpty()) q.append('\n')
                q.append(lines[i].trim().removePrefix(">").trim())
                i++
            }
            out.add(MdQuote(q.toString()))
            continue
        }
        val spaced = line.replace("\t", "    ")
        val ul = UL.matchEntire(spaced)
        if (ul != null) {
            flush()
            val level = (ul.groupValues[1].length / 2).coerceAtMost(3)
            out.add(MdBullet(level, BULLETS[level], taskText(ul.groupValues[2])))
            i++; continue
        }
        val ol = OL.matchEntire(spaced)
        if (ol != null) {
            flush()
            val level = (ol.groupValues[1].length / 2).coerceAtMost(3)
            out.add(MdBullet(level, ol.groupValues[2] + ".", ol.groupValues[3]))
            i++; continue
        }
        if (para.isNotEmpty()) para.append('\n')
        para.append(t)
        i++
    }
    flush()
    return out
}

// ============================ INLINE ============================

private fun closingEmphasis(s: String, start: Int): Int {
    val ch = s[start]
    if (start + 1 >= s.length || s[start + 1].isWhitespace() || s[start + 1] == ch) return -1
    if (ch == '_' && start > 0 && s[start - 1].isLetterOrDigit()) return -1
    var j = start + 1
    while (j < s.length) {
        if (s[j] == ch && !s[j - 1].isWhitespace()) {
            val next = s.getOrNull(j + 1)
            val okEnd = if (ch == '_') (next == null || !next.isLetterOrDigit()) else next != ch
            if (okEnd) return j
        }
        j++
    }
    return -1
}

/** Bold, italic, strike-through, `code`, [links](url) and bare URLs. Unclosed markers stay literal (streaming-safe). */
fun inlineMarkdown(s: String, codeBg: Color, link: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && i + 1 < s.length && s[i + 1] in ESCAPABLE) { append(s[i + 1]); i += 2; continue }
        if (c == '`') {
            val e = s.indexOf('`', i + 1)
            if (e > i) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(s.substring(i + 1, e)) }
                i = e + 1; continue
            }
        }
        if (s.startsWith("**", i) || s.startsWith("__", i)) {
            val d = s.substring(i, i + 2)
            val e = s.indexOf(d, i + 2)
            if (e > i + 2) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(inlineMarkdown(s.substring(i + 2, e), codeBg, link)) }
                i = e + 2; continue
            }
        }
        if (s.startsWith("~~", i)) {
            val e = s.indexOf("~~", i + 2)
            if (e > i + 2) {
                withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { append(inlineMarkdown(s.substring(i + 2, e), codeBg, link)) }
                i = e + 2; continue
            }
        }
        if (c == '*' || c == '_') {
            val e = closingEmphasis(s, i)
            if (e > 0) {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(inlineMarkdown(s.substring(i + 1, e), codeBg, link)) }
                i = e + 1; continue
            }
        }
        if (c == '[') {
            val close = s.indexOf(']', i + 1)
            if (close > i && close + 1 < s.length && s[close + 1] == '(') {
                val end = s.indexOf(')', close + 2)
                if (end > close) {
                    val url = s.substring(close + 2, end).trim().substringBefore(' ')
                    pushStringAnnotation("URL", url)
                    withStyle(SpanStyle(color = link, textDecoration = TextDecoration.Underline)) {
                        append(inlineMarkdown(s.substring(i + 1, close), codeBg, link))
                    }
                    pop()
                    i = end + 1; continue
                }
            }
        }
        if (c == 'h' && (s.startsWith("http://", i) || s.startsWith("https://", i))) {
            var e = i
            while (e < s.length && !s[e].isWhitespace() && s[e] !in "<>)]") e++
            while (e > i && s[e - 1] in ".,;:!?") e--
            val url = s.substring(i, e)
            pushStringAnnotation("URL", url)
            withStyle(SpanStyle(color = link, textDecoration = TextDecoration.Underline)) { append(url) }
            pop()
            i = e; continue
        }
        append(c)
        i++
    }
}

private fun bold(a: AnnotatedString): AnnotatedString = buildAnnotatedString {
    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(a) }
}

// ============================ COMPOSE ============================

/** Text that opens [links](url) when tapped. Long-press selection still works through the parent SelectionContainer. */
@Composable
fun MdText(
    text: AnnotatedString, color: Color, fontSize: TextUnit, lineHeight: TextUnit,
    modifier: Modifier = Modifier
) {
    val uri = LocalUriHandler.current
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val hasLinks = text.getStringAnnotations("URL", 0, text.length).isNotEmpty()
    val m = if (hasLinks) modifier.pointerInput(text) {
        detectTapGestures { pos ->
            val l = layout ?: return@detectTapGestures
            val off = l.getOffsetForPosition(pos)
            text.getStringAnnotations("URL", off, off).firstOrNull()?.let { runCatching { uri.openUri(it.item) } }
        }
    } else modifier
    Text(text, color = color, fontSize = fontSize, lineHeight = lineHeight, modifier = m, onTextLayout = { layout = it })
}

@Composable
fun MarkdownBlocks(src: String, color: Color, scale: Float) {
    val cs = MaterialTheme.colorScheme
    val blocks = remember(src) { parseMarkdown(src) }
    val codeBg = cs.surfaceVariant
    val link = cs.primary
    val fs = 15f * scale
    val lh = (fs * 1.5f).sp
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        blocks.forEach { b ->
            when (b) {
                is MdPara -> MdText(inlineMarkdown(b.text, codeBg, link), color, fs.sp, lh)
                is MdHeading -> {
                    val sz = when (b.level) { 1 -> 22f; 2 -> 19f; 3 -> 17f; else -> 15.5f } * scale
                    MdText(bold(inlineMarkdown(b.text, codeBg, link)), color, sz.sp, (sz * 1.35f).sp, Modifier.padding(top = 4.dp))
                }
                is MdBullet -> Row(Modifier.padding(start = (b.indent * 16).dp)) {
                    Text(b.marker, color = color, fontSize = fs.sp, lineHeight = lh, modifier = Modifier.widthIn(min = 24.dp))
                    MdText(inlineMarkdown(b.text, codeBg, link), color, fs.sp, lh, Modifier.weight(1f))
                }
                is MdQuote -> Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(Modifier.width(3.dp).fillMaxHeight().background(cs.primary.copy(alpha = 0.6f)))
                    Spacer(Modifier.width(10.dp))
                    MdText(inlineMarkdown(b.text, codeBg, link), cs.onSurfaceVariant, fs.sp, lh)
                }
                is MdTable -> MdTableView(b, color, scale)
                MdRule -> HorizontalDivider(Modifier.padding(vertical = 4.dp))
            }
        }
    }
}

@Composable
fun MdTableView(t: MdTable, color: Color, scale: Float) {
    val cs = MaterialTheme.colorScheme
    val fs = 14f * scale
    val cols = t.rows.maxOf { it.size }
    val widths = (0 until cols).map { c ->
        (t.rows.maxOf { r -> r.getOrNull(c)?.length ?: 0 } * 7.5f * scale + 28f).coerceIn(64f, 240f).dp
    }
    val total = widths.fold(0.dp) { a, w -> a + w }
    val shape = RoundedCornerShape(8.dp)
    Column(Modifier.horizontalScroll(rememberScrollState()).clip(shape).border(1.dp, cs.outlineVariant, shape)) {
        t.rows.forEachIndexed { ri, row ->
            Row(Modifier.background(if (ri == 0) cs.surfaceVariant else Color.Transparent)) {
                for (c in 0 until cols) {
                    val a = inlineMarkdown(row.getOrNull(c) ?: "", cs.surfaceVariant, cs.primary)
                    MdText(
                        if (ri == 0) bold(a) else a, color, fs.sp, (fs * 1.4f).sp,
                        Modifier.width(widths[c]).padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
            if (ri < t.rows.lastIndex) Box(Modifier.width(total).height(1.dp).background(cs.outlineVariant))
        }
    }
}
