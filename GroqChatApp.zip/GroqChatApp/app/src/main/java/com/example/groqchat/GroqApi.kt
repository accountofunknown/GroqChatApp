package com.example.groqchat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext
import kotlin.math.roundToInt

class ApiException(val code: Int, message: String, val retryAfter: String?) : Exception(message)

data class ChatResult(
    val text: String,
    val reasoning: String,
    val toolCalls: List<ToolCall>,
    val usage: String?,
    val finish: String?,
    val steps: List<ToolStep> = emptyList(),
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val completionMs: Long = 0L,
    val rate: String? = null,
)

/** Thin client for https://api.groq.com/openai/v1 (chat, models, audio STT / translation / TTS). */
class GroqApi(private val key: () -> String) {
    private val base = "https://api.groq.com/openai/v1"
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun req(path: String) = Request.Builder()
        .url(base + path)
        .header("Authorization", "Bearer ${key()}")

    private fun error(r: Response): ApiException {
        val body = r.body?.string().orEmpty()
        val msg = try {
            JSONObject(body).getJSONObject("error").getString("message")
        } catch (e: Exception) {
            body.take(300).ifBlank { r.message }
        }
        return ApiException(r.code, msg, r.header("retry-after"))
    }

    // GET /models
    suspend fun listModels(): List<ModelInfo> = withContext(Dispatchers.IO) {
        client.newCall(req("/models").get().build()).execute().use { r ->
            if (!r.isSuccessful) throw error(r)
            val arr = JSONObject(r.body!!.string()).getJSONArray("data")
            (0 until arr.length()).map { arr.getJSONObject(it) }
                .map { ModelInfo(it.getString("id"), it.str("owned_by"), it.optInt("context_window"), it.optBoolean("active", true)) }
                .filter { it.active }
                .sortedBy { it.id }
        }
    }

    // POST /chat/completions (streaming via SSE or plain)
    suspend fun chat(body: JSONObject, stream: Boolean, onDelta: (String, String) -> Unit): ChatResult =
        withContext(Dispatchers.IO) {
            val call = client.newCall(req("/chat/completions").post(body.toString().toRequestBody(jsonType)).build())
            val handle = coroutineContext[Job]!!.invokeOnCompletion { if (it != null) call.cancel() }
            try {
                call.execute().use { r ->
                    if (!r.isSuccessful) throw error(r)
                    val limits = r.header("x-ratelimit-remaining-requests")?.let { "$it req left" }
                    val base = if (stream) parseStream(r, onDelta) else parseFull(JSONObject(r.body!!.string()))
                    base.copy(usage = listOfNotNull(base.usage, limits).joinToString(" · ").ifBlank { null }, rate = rateOf(r))
                }
            } finally {
                handle.dispose()
            }
        }

    private fun rateOf(r: Response): String? {
        val req = r.header("x-ratelimit-remaining-requests")
        val tok = r.header("x-ratelimit-remaining-tokens")
        return listOfNotNull(req?.let { "$it requests left" }, tok?.let { "$it tokens left" })
            .joinToString(" · ").ifBlank { null }
    }

    /** prompt tokens, completion tokens, completion time in ms (chat completions and Responses API shapes). */
    private fun nums(j: JSONObject): Triple<Int, Int, Long> {
        val u = j.optJSONObject("usage") ?: j.optJSONObject("x_groq")?.optJSONObject("usage") ?: return Triple(0, 0, 0L)
        val p = if (u.has("prompt_tokens")) u.optInt("prompt_tokens") else u.optInt("input_tokens")
        val c = if (u.has("completion_tokens")) u.optInt("completion_tokens") else u.optInt("output_tokens")
        return Triple(p, c, (u.optDouble("completion_time", 0.0) * 1000).toLong())
    }

    private fun usageOf(j: JSONObject): String? {
        val u = j.optJSONObject("usage") ?: j.optJSONObject("x_groq")?.optJSONObject("usage") ?: return null
        val total = u.optInt("total_tokens")
        val time = u.optDouble("completion_time", 0.0)
        val comp = u.optInt("completion_tokens")
        val tps = if (time > 0 && comp > 0) " · ${(comp / time).roundToInt()} tok/s" else ""
        return "$total tokens$tps"
    }

    private fun parseFull(j: JSONObject): ChatResult {
        val ch = j.getJSONArray("choices").getJSONObject(0)
        val m = ch.getJSONObject("message")
        val calls = mutableListOf<ToolCall>()
        m.optJSONArray("tool_calls")?.let { a ->
            for (i in 0 until a.length()) {
                val t = a.getJSONObject(i)
                val f = t.getJSONObject("function")
                calls += ToolCall(t.str("id"), f.str("name"), f.str("arguments"))
            }
        }
        val steps = mutableListOf<ToolStep>()
        m.optJSONArray("executed_tools")?.let { a ->
            for (i in 0 until a.length()) steps += stepOf(a.getJSONObject(i))
        }
        val (pt, ct, ms) = nums(j)
        return ChatResult(m.str("content"), m.str("reasoning"), calls, usageOf(j), ch.str("finish_reason"), steps, pt, ct, ms)
    }

    private fun parseStream(r: Response, onDelta: (String, String) -> Unit): ChatResult {
        val text = StringBuilder()
        val reasoning = StringBuilder()
        val calls = sortedMapOf<Int, Array<StringBuilder>>()
        var usage: String? = null
        var lastNums = Triple(0, 0, 0L)
        var finish: String? = null
        var lastEmit = 0L
        val src = r.body!!.source()
        while (true) {
            val line = src.readUtf8Line() ?: break
            if (!line.startsWith("data:")) continue
            val data = line.removePrefix("data:").trim()
            if (data == "[DONE]") break
            if (data.isEmpty()) continue
            val j = JSONObject(data)
            j.optJSONObject("error")?.let { throw ApiException(500, it.str("message"), null) }
            usageOf(j)?.let { usage = it; lastNums = nums(j) }
            val choices = j.optJSONArray("choices") ?: continue
            if (choices.length() == 0) continue
            val ch = choices.getJSONObject(0)
            ch.str("finish_reason").takeIf { it.isNotEmpty() }?.let { finish = it }
            val d = ch.optJSONObject("delta") ?: continue
            text.append(d.str("content"))
            reasoning.append(d.str("reasoning"))
            d.optJSONArray("tool_calls")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val t = arr.getJSONObject(i)
                    val e = calls.getOrPut(t.optInt("index", i)) { arrayOf(StringBuilder(), StringBuilder(), StringBuilder()) }
                    e[0].append(t.str("id"))
                    t.optJSONObject("function")?.let { f ->
                        e[1].append(f.str("name"))
                        e[2].append(f.str("arguments"))
                    }
                }
            }
            val now = System.currentTimeMillis()
            if (now - lastEmit > 40) {
                lastEmit = now
                onDelta(text.toString(), reasoning.toString())
            }
        }
        val toolCalls = calls.values.map { ToolCall(it[0].toString(), it[1].toString(), it[2].toString()) }
        return ChatResult(text.toString(), reasoning.toString(), toolCalls, usage, finish, emptyList(), lastNums.first, lastNums.second, lastNums.third)
    }

    private fun field(o: JSONObject, k: String): String = if (!o.has(k) || o.isNull(k)) "" else o.get(k).toString()

    /** Turns any server-side tool record (executed_tools entry, mcp_call, ...) into a readable step. */
    private fun stepOf(o: JSONObject): ToolStep {
        val type = field(o, "type").ifBlank { "tool" }
        val args = field(o, "arguments")
        val out = listOf("output", "search_results", "code_results").map { field(o, it) }.firstOrNull { it.isNotBlank() } ?: ""
        val title = listOf(field(o, "server_label"), field(o, "name").ifBlank { type })
            .filter { it.isNotBlank() }.joinToString(" · ")
        val detail = buildString {
            if (args.isNotBlank()) append("Input: ").append(args.take(600))
            if (out.isNotBlank()) { if (isNotEmpty()) append("\n"); append("Result: ").append(out.take(900)) }
        }
        return ToolStep(type, title, detail)
    }

    // POST /responses  (remote MCP servers, connectors, built-in tools)
    suspend fun respond(body: JSONObject): ChatResult = withContext(Dispatchers.IO) {
        val call = client.newCall(req("/responses").post(body.toString().toRequestBody(jsonType)).build())
        val handle = coroutineContext[Job]!!.invokeOnCompletion { if (it != null) call.cancel() }
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) throw error(r)
                parseResponses(JSONObject(r.body!!.string())).copy(rate = rateOf(r))
            }
        } finally {
            handle.dispose()
        }
    }

    private fun parseResponses(j: JSONObject): ChatResult {
        val text = StringBuilder()
        val reasoning = StringBuilder()
        val steps = mutableListOf<ToolStep>()
        val out = j.optJSONArray("output") ?: JSONArray()
        for (i in 0 until out.length()) {
            val item = out.getJSONObject(i)
            val type = item.str("type")
            when (type) {
                "message" -> item.optJSONArray("content")?.let { c ->
                    for (k in 0 until c.length()) {
                        val p = c.getJSONObject(k)
                        if (p.str("type") == "output_text") text.append(p.str("text"))
                    }
                }
                "reasoning" -> item.optJSONArray("content")?.let { c ->
                    for (k in 0 until c.length()) {
                        if (reasoning.isNotEmpty()) reasoning.append("\n")
                        reasoning.append(c.getJSONObject(k).str("text"))
                    }
                }
                "mcp_list_tools" -> {
                    val tools = item.optJSONArray("tools") ?: JSONArray()
                    val names = (0 until tools.length()).map { tools.getJSONObject(it).str("name") }
                    steps += ToolStep(type, "${item.str("server_label")} · ${names.size} tools", names.joinToString(", "))
                }
                else -> steps += stepOf(item)
            }
        }
        if (text.isEmpty()) text.append(j.str("output_text"))
        val usage = j.optJSONObject("usage")?.let { "${it.optInt("total_tokens")} tokens" }
        val (pt, ct, ms) = nums(j)
        return ChatResult(text.toString().trim(), reasoning.toString().trim(), emptyList(), usage, j.str("status"), steps, pt, ct, ms)
    }

    // POST /audio/transcriptions  or  /audio/translations (to English)
    suspend fun transcribe(file: File, model: String, language: String, translate: Boolean): String =
        withContext(Dispatchers.IO) {
            val m = if (translate) "whisper-large-v3" else model
            val form = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, file.asRequestBody("audio/mp4".toMediaType()))
                .addFormDataPart("model", m)
                .addFormDataPart("response_format", "json")
            if (!translate && language.isNotBlank()) form.addFormDataPart("language", language.trim())
            val path = if (translate) "/audio/translations" else "/audio/transcriptions"
            client.newCall(req(path).post(form.build()).build()).execute().use { r ->
                if (!r.isSuccessful) throw error(r)
                JSONObject(r.body!!.string()).getString("text").trim()
            }
        }

    // POST /audio/speech (Orpheus, wav, max 200 chars per request)
    suspend fun speech(text: String, model: String, voice: String, out: File) =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("model", model).put("input", text)
                .put("voice", voice).put("response_format", "wav")
            client.newCall(req("/audio/speech").post(body.toString().toRequestBody(jsonType)).build()).execute().use { r ->
                if (!r.isSuccessful) throw error(r)
                out.outputStream().use { o -> r.body!!.byteStream().copyTo(o) }
            }
        }
}
