package com.example.groqchat

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import kotlin.math.max

/** Downloads https images for markdown. Small in-memory cache; no disk cache. */
object ImageLoader {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val cache = LruCache<String, ImageBitmap>(6)
    private const val MAX_BYTES = 8_000_000L
    private const val MAX_SIDE = 1600

    suspend fun load(url: String): ImageBitmap? {
        cache.get(url)?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val bmp = client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    val body = r.body
                    if (!r.isSuccessful || body == null || body.contentLength() > MAX_BYTES) return@use null
                    val bytes = body.bytes()
                    if (bytes.size > MAX_BYTES) return@use null
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                        ?.asImageBitmap()
                }
                if (bmp != null) cache.put(url, bmp)
                bmp
            } catch (e: Exception) {
                null
            }
        }
    }
}

/**
 * Markdown image. Never loads on its own: a model reply could point at a tracking URL, so the
 * image is fetched only after the user taps it.
 */
@Composable
fun MdImageView(alt: String, url: String) {
    val cs = MaterialTheme.colorScheme
    var requested by remember(url) { mutableStateOf(false) }
    val label = alt.ifBlank { "Image" }
    if (!url.startsWith("https://")) {
        Text("🖼 $label (only https images are supported)", fontSize = 13.sp, color = cs.onSurfaceVariant)
        return
    }
    val host = remember(url) { try { java.net.URI(url).host ?: url } catch (e: Exception) { url } }
    if (!requested) {
        Surface(
            color = cs.surfaceVariant, shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().clickable { requested = true }
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🖼", fontSize = 22.sp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(label, fontSize = 14.sp)
                    Text("Tap to load from $host", fontSize = 12.sp, color = cs.onSurfaceVariant)
                }
            }
        }
        return
    }
    val state by produceState(initialValue = false to (null as ImageBitmap?), url) {
        value = true to ImageLoader.load(url)
    }
    val done = state.first
    val bmp = state.second
    when {
        !done -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
        }
        bmp == null -> Text("🖼 Couldn't load $label", fontSize = 13.sp, color = cs.error)
        else -> Column {
            Image(
                bitmap = bmp, contentDescription = alt, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            )
            if (alt.isNotBlank()) Text(alt, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }
    }
}
