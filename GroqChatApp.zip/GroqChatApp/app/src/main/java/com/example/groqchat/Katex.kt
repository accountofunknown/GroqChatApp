package com.example.groqchat

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.UnfoldLess
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream

private const val KATEX_BASE = "https://appassets.androidplatform.net/assets/katex/"

/** KaTeX is downloaded and bundled by the Gradle build (see app/build.gradle.kts). */
object KatexAssets {
    @Volatile private var cached: Boolean? = null

    fun available(ctx: Context): Boolean {
        cached?.let { return it }
        val ok = try {
            ctx.applicationContext.assets.list("katex")?.contains("katex.min.js") == true
        } catch (e: Exception) {
            false
        }
        cached = ok
        return ok
    }
}

/** Receives the formula's natural size (CSS px == dp) from the page. */
class SizeBridge(private val onSize: (Int, Int) -> Unit) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun size(w: Int, h: Int) {
        main.post { onSize(w, h) }
    }
}

private fun katexHtml(tex: String, color: Color, sizeSp: Float): String {
    val hex = String.format("#%06X", color.toArgb() and 0xFFFFFF)
    val src = JSONObject.quote(tex)
    val size = sizeSp.toInt()
    return """
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="katex.min.css">
<script src="katex.min.js"></script>
<style>
html,body{margin:0;padding:0;background:transparent;overflow:hidden}
body{color:$hex;font-size:${size}px;text-align:center}
#m{display:inline-block;padding:6px 2px;text-align:center}
.katex-display{margin:0}
.err{font-family:monospace;font-size:13px;white-space:pre;text-align:left}
</style></head><body><div id="m"></div>
<script>
var src = $src;
var el = document.getElementById('m');
function report(){
  var r = el.getBoundingClientRect();
  Android.size(Math.ceil(r.width), Math.ceil(r.height));
}
try {
  if (typeof katex === 'undefined') { throw new Error('katex missing'); }
  katex.render(src, el, {displayMode: true, throwOnError: false, strict: 'ignore', trust: false});
} catch (e) { el.className = 'err'; el.textContent = src; }
[0, 60, 200, 500, 1200].forEach(function(t){ setTimeout(report, t); });
if (document.fonts && document.fonts.ready) { document.fonts.ready.then(report); }
</script></body></html>
""".trimIndent()
}

@SuppressLint("SetJavaScriptEnabled")
private fun buildWebView(c: Context, onSize: (Int, Int) -> Unit): WebView {
    val loader = WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(c))
        .build()
    return WebView(c).apply {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isLongClickable = false
        setOnLongClickListener { true }
        settings.javaScriptEnabled = true      // KaTeX is a JavaScript library
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.domStorageEnabled = false
        settings.textZoom = 100
        addJavascriptInterface(SizeBridge(onSize), "Android")
        webViewClient = object : WebViewClient() {
            // Bundled assets are served from the app. Other sub-resources (e.g. from model-written TeX) get an
            // empty 404. The page itself (main frame, supplied via loadDataWithBaseURL) must be left alone,
            // otherwise Android shows its "Web page not available" error page.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                loader.shouldInterceptRequest(request.url)?.let { return it }
                if (request.isForMainFrame) return null
                return WebResourceResponse("text/plain", "utf-8", 404, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
        }
    }
}

/**
 * One typeset display formula (bundled KaTeX).
 *
 * The web view is laid out at the formula's natural size and never touched itself: a transparent
 * Compose layer on top handles taps, and Compose handles scrolling. So the formula scrolls left/right
 * (and up/down while collapsed) smoothly with the rest of the chat, and tapping a tall formula
 * expands or collapses it.
 */
@Composable
fun KatexBlock(tex: String, color: Color, sizeSp: Float) {
    val clip = LocalClipboardManager.current
    var expanded by remember(tex) { mutableStateOf(false) }
    var natW by remember(tex) { mutableStateOf(0) }
    var natH by remember(tex) { mutableStateOf(56) }
    val html = remember(tex, color, sizeSp) { katexHtml(tex, color, sizeSp) }
    val cap = 260.dp
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()

    Box(Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val contentW = if (natW.dp > maxWidth) natW.dp else maxWidth
            val contentH = natH.coerceIn(24, 6000).dp
            val tall = contentH > cap
            ScrollBox(expanded || !tall, cap, vScroll, hScroll) {
                Box(Modifier.width(contentW).height(contentH)) {
                    key(html) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { c -> buildWebView(c) { w, h -> natW = w; natH = h } },
                            update = { wv ->
                                if (wv.tag != html) {
                                    wv.tag = html
                                    wv.loadDataWithBaseURL(KATEX_BASE, html, "text/html", "utf-8", null)
                                }
                            },
                            onRelease = { wv -> wv.destroy() }
                        )
                    }
                    // Transparent layer: the web view never gets touches; taps expand/collapse, drags scroll.
                    Box(
                        Modifier.fillMaxSize().pointerInput(tall) {
                            detectTapGestures { if (tall) expanded = !expanded }
                        }
                    )
                }
            }
        }
        IconButton(
            onClick = { clip.setText(AnnotatedString(tex)) },
            modifier = Modifier.align(Alignment.TopEnd).size(28.dp).alpha(0.55f)
        ) { Icon(Icons.Default.ContentCopy, "Copy LaTeX", Modifier.size(14.dp)) }
        if (natH.dp > cap) {
            Icon(
                if (expanded) Icons.Default.UnfoldLess else Icons.Default.UnfoldMore,
                if (expanded) "Tap to collapse" else "Tap to expand",
                Modifier.align(Alignment.BottomEnd).padding(4.dp).size(18.dp).alpha(0.6f)
            )
        }
    }
}
