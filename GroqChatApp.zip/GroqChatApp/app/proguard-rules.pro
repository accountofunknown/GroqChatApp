# Groq Chat — release keep rules
-keep class com.example.groqchat.** { *; }
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn com.tom_roush.**
-keep class com.tom_roush.** { *; }

# Tink / security-crypto references optional errorprone annotations
-dontwarn com.google.errorprone.annotations.**
-dontwarn com.google.crypto.tink.**
-keep class com.google.crypto.tink.** { *; }
-keep class androidx.security.crypto.** { *; }
