package com.example.groqchat

import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val st = vm.settings
            val systemDark = isSystemInDarkTheme()
            val dark = when (st.theme) {
                "dark" -> true
                "light" -> false
                else -> systemDark
            }
            val ctx = LocalContext.current
            val base = if (Build.VERSION.SDK_INT >= 31 && st.dynamicColor) {
                if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            } else {
                accentScheme(st.accent, dark)
            }
            val scheme = if (dark && st.amoled) amoledScheme(base) else base
            // Keep status / navigation bar icons readable when the app theme differs from the system theme.
            DisposableEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT) { dark }
                )
                onDispose { }
            }
            MaterialTheme(colorScheme = scheme) {
                CompositionLocalProvider(
                    LocalTextStyle provides LocalTextStyle.current.copy(fontFamily = fontFamilyOf(st.fontFamily))
                ) {
                    Surface(Modifier.fillMaxSize()) { GroqApp(vm) }
                }
            }
        }
    }
}
