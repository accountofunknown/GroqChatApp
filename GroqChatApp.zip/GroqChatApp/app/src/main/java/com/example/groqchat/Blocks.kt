package com.example.groqchat

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp

/**
 * Content that scrolls left/right and, while collapsed, also up/down inside a height-capped box.
 * When [expanded] the height cap and the vertical scroll are removed so the whole content shows
 * (it still scrolls left/right). The content is measured with unbounded width and height, so
 * code and formulas never wrap.
 */
@Composable
fun ScrollBox(
    expanded: Boolean,
    maxHeight: Dp,
    vScroll: ScrollState,
    hScroll: ScrollState,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val capped = if (expanded) modifier else modifier.heightIn(max = maxHeight).verticalScroll(vScroll)
    Box(capped.horizontalScroll(hScroll)) { content() }
}
