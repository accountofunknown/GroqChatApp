package com.example.groqchat

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChatMeta(val id: String, val title: String, val updated: Long, val pinned: Boolean = false)

/** A chat that matched a search, with a short excerpt of the matching message text. */
data class ChatHit(val meta: ChatMeta, val snippet: String)

class Store(private val ctx: Context) {
    private val plain: SharedPreferences = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val secure: SharedPreferences = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("secure_fallback", Context.MODE_PRIVATE)
    }

    private fun chatFile(id: String) = File(ctx.filesDir, "chat_$id.json")
    private fun textFile(id: String) = File(ctx.filesDir, "idx_$id.txt")

    private fun textOf(list: List<Msg>): String =
        list.filter { (it.role == Role.USER || it.role == Role.ASSISTANT) && !it.error && it.text.isNotBlank() }
            .joinToString("\n") { it.text }

    /** Plain text of a chat (no images) for searching. Kept in a small side file so searching never has to parse whole chats. */
    fun chatText(id: String): String {
        val f = textFile(id)
        if (f.exists()) return try { f.readText() } catch (e: Exception) { "" }
        val text = textOf(loadChat(id))
        try { f.writeText(text) } catch (e: Exception) { }
        return text
    }

    var apiKey: String
        get() = secure.getString("groq_key", "") ?: ""
        set(v) { secure.edit().putString("groq_key", v.trim()).apply() }

    var currentChatId: String
        get() = plain.getString("current", "") ?: ""
        set(v) { plain.edit().putString("current", v).apply() }

    fun loadSettings(): Settings = try {
        Settings.fromJson(JSONObject(plain.getString("s", "{}") ?: "{}"))
    } catch (e: Exception) { Settings() }

    fun saveSettings(s: Settings) { plain.edit().putString("s", s.toJson().toString()).apply() }

    fun loadIndex(): List<ChatMeta> {
        val list = try {
            val a = JSONArray(plain.getString("index", "[]") ?: "[]")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                ChatMeta(o.getString("id"), o.optString("title", "Chat"), o.optLong("updated"), o.optBoolean("pinned", false))
            }
        } catch (e: Exception) { emptyList() }
        if (list.isNotEmpty()) return list
        val legacy = File(ctx.filesDir, "chat.json")
        if (legacy.exists()) {
            try {
                legacy.copyTo(chatFile("legacy"), overwrite = true)
                legacy.delete()
                val m = listOf(ChatMeta("legacy", "Previous chat", System.currentTimeMillis()))
                saveIndex(m)
                return m
            } catch (e: Exception) { }
        }
        return emptyList()
    }

    fun saveIndex(list: List<ChatMeta>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("updated", it.updated).put("pinned", it.pinned)) }
        plain.edit().putString("index", a.toString()).apply()
    }

    fun loadChat(id: String): List<Msg> = try {
        val f = chatFile(id)
        if (!f.exists()) emptyList() else {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { Msg.fromJson(a.getJSONObject(it)) }
        }
    } catch (e: Exception) { emptyList() }

    fun saveChat(id: String, list: List<Msg>) {
        try {
            val a = JSONArray()
            list.forEach { a.put(it.toJson()) }
            chatFile(id).writeText(a.toString())
            textFile(id).writeText(textOf(list))
        } catch (e: Exception) { }
    }

    fun deleteChat(id: String) { chatFile(id).delete(); textFile(id).delete() }

    fun deleteAllChats() {
        ctx.filesDir.listFiles { f -> f.name.startsWith("chat_") || f.name.startsWith("idx_") }?.forEach { it.delete() }
        saveIndex(emptyList())
        currentChatId = ""
    }

    // MCP servers hold auth tokens, so they live in the encrypted preferences.
    fun loadMcp(): List<McpServer> = try {
        val a = JSONArray(secure.getString("mcp", "[]") ?: "[]")
        (0 until a.length()).map { McpServer.fromJson(a.getJSONObject(it)) }
    } catch (e: Exception) { emptyList() }

    fun saveMcp(list: List<McpServer>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        secure.edit().putString("mcp", a.toString()).apply()
    }

    // Custom tools may contain webhook headers / tokens, so they are stored encrypted too.
    fun loadTools(): List<CustomTool> = try {
        val a = JSONArray(secure.getString("tools", "[]") ?: "[]")
        (0 until a.length()).map { CustomTool.fromJson(a.getJSONObject(it)) }
    } catch (e: Exception) { emptyList() }

    fun saveTools(list: List<CustomTool>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        secure.edit().putString("tools", a.toString()).apply()
    }
}
