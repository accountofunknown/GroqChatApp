package com.example.groqchat

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Envelope encryption for chats. A random 256-bit data key encrypts the data (fast, done in software);
 * that data key is itself stored encrypted by a non-exportable AES key held in the Android Keystore.
 * Everything uses AES-256-GCM. If the Keystore is unusable the app keeps working, but stores plain text.
 */
class Crypto(private val prefs: SharedPreferences) {
    private val alias = "groqchat_key_encryption_key"
    @Volatile private var dek: SecretKey? = null
    @Volatile private var broken = false

    private fun kek(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun gcmEncrypt(key: SecretKey, plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key)
        return c.iv + c.doFinal(plain)          // 12-byte IV first
    }

    private fun gcmDecrypt(key: SecretKey, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data, 0, 12))
        return c.doFinal(data, 12, data.size - 12)
    }

    private fun newDataKey(): ByteArray {
        val fresh = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val wrapped = Base64.encodeToString(gcmEncrypt(kek(), fresh), Base64.NO_WRAP)
        prefs.edit().putString("dek", wrapped).commit()
        return fresh
    }

    @Synchronized
    private fun dataKey(): SecretKey? {
        dek?.let { return it }
        if (broken) return null
        return try {
            val stored = prefs.getString("dek", null)
            val unwrapped = stored?.let {
                try { gcmDecrypt(kek(), Base64.decode(it, Base64.NO_WRAP)) } catch (e: Exception) { null }
            }
            // If an old data key can no longer be unwrapped, old data is unreadable anyway: start a fresh key.
            val bytes = unwrapped ?: newDataKey()
            SecretKeySpec(bytes, "AES").also { dek = it }
        } catch (e: Exception) {
            broken = true
            null
        }
    }

    /** Encrypts text for a database column. Empty text stays empty. */
    fun seal(text: String): String {
        if (text.isEmpty()) return text
        val k = dataKey() ?: return text
        return try {
            PREFIX + Base64.encodeToString(gcmEncrypt(k, text.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        } catch (e: Exception) { text }
    }

    /** Reverse of [seal]. Text saved without the prefix (old data) is returned as is; unreadable data gives "". */
    fun unseal(stored: String): String {
        if (!stored.startsWith(PREFIX)) return stored
        val k = dataKey() ?: return ""
        return try {
            String(gcmDecrypt(k, Base64.decode(stored.substring(PREFIX.length), Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) { "" }
    }

    fun encryptBytes(plain: ByteArray): ByteArray? {
        val k = dataKey() ?: return null
        return try { gcmEncrypt(k, plain) } catch (e: Exception) { null }
    }

    fun decryptBytes(data: ByteArray): ByteArray? {
        val k = dataKey() ?: return null
        return try { gcmDecrypt(k, data) } catch (e: Exception) { null }
    }

    private companion object {
        const val PREFIX = "E1:"
    }
}
