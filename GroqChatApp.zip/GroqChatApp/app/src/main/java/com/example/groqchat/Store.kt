package com.example.groqchat

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Store(private val ctx: Context) {
    private val plain: SharedPreferences = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val secure: SharedPreferences = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("secure_fallback", Context.MODE_PRIVATE)
    }
    private val chatFile get() = File(ctx.filesDir, "chat.json")

    var apiKey: String
        get() = secure.getString("groq_key", "") ?: ""
        set(v) { secure.edit().putString("groq_key", v.trim()).apply() }

    fun loadSettings(): Settings = try {
        Settings.fromJson(JSONObject(plain.getString("s", "{}") ?: "{}"))
    } catch (e: Exception) { Settings() }

    fun saveSettings(s: Settings) { plain.edit().putString("s", s.toJson().toString()).apply() }

    fun loadChat(): List<Msg> = try {
        if (!chatFile.exists()) emptyList() else {
            val a = JSONArray(chatFile.readText())
            (0 until a.length()).map { Msg.fromJson(a.getJSONObject(it)) }
        }
    } catch (e: Exception) { emptyList() }

    fun saveChat(list: List<Msg>) {
        try {
            val a = JSONArray()
            list.forEach { a.put(it.toJson()) }
            chatFile.writeText(a.toString())
        } catch (_: Exception) { }
    }
}
