package com.example.groqchat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.Placeholder
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

// ============================ PARSER ============================

sealed interface MdBlock
data class MdPara(val text: String) : MdBlock
data class MdHeading(val level: Int, val text: String) : MdBlock
data class MdBullet(val indent: Int, val marker: String, val text: String) : MdBlock
data class MdQuote(val text: String, val depth: Int = 1) : MdBlock
data class MdTable(val rows: List<List<String>>) : MdBlock
data class MdImage(val alt: String, val url: String) : MdBlock
data class MdMath(val tex: String, val closed: Boolean = true) : MdBlock
object MdRule : MdBlock

private val RULE = Regex("^(-{3,}|\\*{3,}|_{3,})$")
private val HEADING = Regex("^#{1,6}\\s+.*$")
private val UL = Regex("^(\\s*)[-*+]\\s+(.*)$")
private val OL = Regex("^(\\s*)(\\d{1,3})[.)]\\s+(.*)$")
private val TABLE_SEP = Regex("^\\s*\\|?\\s*:?-{3,}:?\\s*(\\|\\s*:?-{3,}:?\\s*)*\\|?\\s*$")
private val IMAGE = Regex("""^!\[([^\]]*)\]\((\S+?)(?:\s+"[^"]*")?\)$""")

private val HTML_IMG = Regex("""^<img\s[^>]*>$""", RegexOption.IGNORE_CASE)
private val HTML_SRC = Regex("""src\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
private val HTML_ALT = Regex("""alt\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
private val HTML_HREF = Regex("""href\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
private val HTML_HEADING = Regex("""^<h([1-6])[^>]*>(.*?)</h\1>$""", RegexOption.IGNORE_CASE)
private val HTML_HR = Regex("""^<hr\s*/?>$""", RegexOption.IGNORE_CASE)
private val HTML_LI = Regex("""^<li[^>]*>(.*?)(?:</li>)?$""", RegexOption.IGNORE_CASE)
private val HTML_P = Regex("""^<p[^>]*>(.*?)(?:</p>)?$""", RegexOption.IGNORE_CASE)
private val HTML_SKIP = Regex(
    """^</?(?:ul|ol|p|div|span|section|article|center|details|summary|blockquote)(?:\s[^>]*)?>$""",
    RegexOption.IGNORE_CASE
)
private val HTML_TAG = Regex("""<(/?)([a-zA-Z][a-zA-Z0-9]*)((?:\s[^>]*)?)/?>""")

private const val ESCAPABLE = "\\`*_{}[]()#+-.!|>~$"
private const val DD = "\$\$"
private val BULLETS = listOf("•", "◦", "▪", "▪")
private val FORMAT_TAGS = setOf("b", "strong", "i", "em", "u", "ins", "s", "del", "strike", "code", "kbd", "tt", "mark", "sub", "sup", "small")
private val WRAPPER_TAGS = setOf("span", "div", "p", "font", "center", "section", "article", "ul", "ol", "li", "details", "summary", "blockquote")
private val ENTITIES = mapOf(
    "&amp;" to "&", "&lt;" to "<", "&gt;" to ">", "&quot;" to "\"", "&#39;" to "'", "&apos;" to "'", "&nbsp;" to "\u00A0"
)

private fun splitRow(line: String): List<String> {
    var s = line.trim()
    if (s.startsWith("|")) s = s.drop(1)
    if (s.endsWith("|")) s = s.dropLast(1)
    return s.split("|").map { it.trim() }
}

private fun taskText(s: String): String = when {
    s.startsWith("[ ] ") -> "☐ " + s.drop(4)
    s.startsWith("[x] ", ignoreCase = true) -> "☑ " + s.drop(4)
    else -> s
}

fun parseMarkdown(src: String): List<MdBlock> {
    val lines = src.replace("\r\n", "\n").replace('\r', '\n').split('\n')
    val out = mutableListOf<MdBlock>()
    val para = StringBuilder()
    fun flush() {
        if (para.isNotBlank()) out.add(MdPara(para.toString().trim()))
        para.setLength(0)
    }
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val t = line.trim()
        if (t.isEmpty()) { flush(); i++; continue }

        // display math:  $$ ... $$   or   \[ ... \]
        if (t.startsWith(DD) || t.startsWith("\\[")) {
            flush()
            val open = if (t.startsWith(DD)) DD else "\\["
            val close = if (open == DD) DD else "\\]"
            val first = t.removePrefix(open)
            if (first.contains(close)) {
                out.add(MdMath(first.substringBefore(close).trim()))
                i++
            } else {
                val sb = StringBuilder(first)
                var closed = false
                i++
                while (i < lines.size) {
                    val l = lines[i]
                    i++
                    if (l.contains(close)) { sb.append('\n').append(l.substringBefore(close)); closed = true; break }
                    sb.append('\n').append(l)
                }
                out.add(MdMath(sb.toString().trim(), closed))
            }
            continue
        }

        if (t.contains('|') && i + 1 < lines.size && lines[i + 1].contains('-') && TABLE_SEP.matches(lines[i + 1])) {
            flush()
            val rows = mutableListOf(splitRow(t))
            i += 2
            while (i < lines.size && lines[i].isNotBlank() && lines[i].contains('|')) {
                rows.add(splitRow(lines[i])); i++
            }
            out.add(MdTable(rows))
            continue
        }
        if (RULE.matches(t) || HTML_HR.matches(t)) { flush(); out.add(MdRule); i++; continue }
        if (HEADING.matches(t)) {
            flush()
            val n = t.takeWhile { it == '#' }.length
            out.add(MdHeading(n, t.drop(n).trim()))
            i++; continue
        }

        val img = IMAGE.matchEntire(t)
        if (img != null) { flush(); out.add(MdImage(img.groupValues[1], img.groupValues[2])); i++; continue }
        if (HTML_IMG.matches(t)) {
            val src2 = HTML_SRC.find(t)?.groupValues?.get(1)
            if (src2 != null) {
                flush()
                out.add(MdImage(HTML_ALT.find(t)?.groupValues?.get(1) ?: "", src2))
                i++; continue
            }
        }
        val hh = HTML_HEADING.matchEntire(t)
        if (hh != null) { flush(); out.add(MdHeading(hh.groupValues[1].toInt(), hh.groupValues[2].trim())); i++; continue }
        if (HTML_SKIP.matches(t)) { flush(); i++; continue }
        val li = HTML_LI.matchEntire(t)
        if (li != null) { flush(); out.add(MdBullet(0, BULLETS[0], li.groupValues[1].trim())); i++; continue }
        val hp = HTML_P.matchEntire(t)
        if (hp != null) { flush(); if (hp.groupValues[1].isNotBlank()) out.add(MdPara(hp.groupValues[1].trim())); i++; continue }

        if (t.startsWith(">")) {
            flush()
            val q = StringBuilder()
            var cur = -1
            fun emit() {
                if (cur > 0) out.add(MdQuote(q.toString().trimEnd(), cur))
                q.setLength(0)
            }
            while (i < lines.size && lines[i].trim().startsWith(">")) {
                var l = lines[i].trim()
                var d = 0
                while (l.startsWith(">")) { d++; l = l.drop(1).trimStart() }
                if (d != cur) { emit(); cur = d }
                if (q.isNotEmpty()) q.append('\n')
                q.append(l)
                i++
            }
            emit()
            continue
        }
        val spaced = line.replace("\t", "    ")
        val ul = UL.matchEntire(spaced)
        if (ul != null) {
            flush()
            val level = (ul.groupValues[1].length / 2).coerceAtMost(3)
            out.add(MdBullet(level, BULLETS[level], taskText(ul.groupValues[2])))
            i++; continue
        }
        val ol = OL.matchEntire(spaced)
        if (ol != null) {
            flush()
            val level = (ol.groupValues[1].length / 2).coerceAtMost(3)
            out.add(MdBullet(level, ol.groupValues[2] + ".", ol.groupValues[3]))
            i++; continue
        }
        if (para.isNotEmpty()) para.append('\n')
        para.append(t)
        i++
    }
    flush()
    return out
}

// ============================ INLINE ============================

private fun closingEmphasis(s: String, start: Int): Int {
    val ch = s[start]
    if (start + 1 >= s.length || s[start + 1].isWhitespace() || s[start + 1] == ch) return -1
    if (ch == '_' && start > 0 && s[start - 1].isLetterOrDigit()) return -1
    var j = start + 1
    while (j < s.length) {
        if (s[j] == ch && !s[j - 1].isWhitespace()) {
            val next = s.getOrNull(j + 1)
            val okEnd = if (ch == '_') (next == null || !next.isLetterOrDigit()) else next != ch
            if (okEnd) return j
        }
        j++
    }
    return -1
}

/** Closing '$' of an inline formula that opens at [start] (rules avoid treating prices like $5 and $10 as math). */
private fun closingDollar(s: String, start: Int): Int {
    if (start + 1 >= s.length || s[start + 1].isWhitespace() || s[start + 1] == '$') return -1
    var j = start + 1
    while (j < s.length) {
        val ch = s[j]
        if (ch == '\\') { j += 2; continue }
        if (ch == '\n') return -1
        if (ch == '$' && !s[j - 1].isWhitespace() && !(j + 1 < s.length && s[j + 1].isDigit())) return j
        j++
    }
    return -1
}

private fun tagStyle(name: String, codeBg: Color): SpanStyle = when (name) {
    "b", "strong" -> SpanStyle(fontWeight = FontWeight.Bold)
    "i", "em" -> SpanStyle(fontStyle = FontStyle.Italic)
    "u", "ins" -> SpanStyle(textDecoration = TextDecoration.Underline)
    "s", "del", "strike" -> SpanStyle(textDecoration = TextDecoration.LineThrough)
    "code", "kbd", "tt" -> SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)
    "mark" -> SpanStyle(background = Color(0x66FFEB3B))
    "sub" -> SpanStyle(baselineShift = BaselineShift.Subscript, fontSize = 0.75.em)
    "sup" -> SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = 0.75.em)
    "small" -> SpanStyle(fontSize = 0.85.em)
    else -> SpanStyle()
}

private val MATH_FONT = SpanStyle(fontFamily = FontFamily.Serif)

/**
 * Bold, italic, strike-through, `code`, links, bare URLs, $math$, \(math\), common inline HTML tags
 * and HTML entities. Unclosed markers stay literal, so half-streamed text never breaks.
 */
fun inlineMarkdown(s: String, codeBg: Color, link: Color, math: MathCtx? = null): AnnotatedString = buildAnnotatedString {
    // With KaTeX available a formula becomes a placeholder that is filled with a real typeset formula; otherwise styled text.
    fun putMath(tex: String) {
        if (math != null && math.items.size < math.max) {
            math.items.add(tex)
            appendInlineContent("math${math.items.size - 1}", tex)
        } else {
            withStyle(MATH_FONT) { append(latexToAnnotated(tex)) }
        }
    }
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && s.startsWith("\\(", i)) {
            val e = s.indexOf("\\)", i + 2)
            if (e > i + 2) {
                putMath(s.substring(i + 2, e))
                i = e + 2; continue
            }
        }
        if (c == '\\' && i + 1 < s.length && s[i + 1] in ESCAPABLE) { append(s[i + 1]); i += 2; continue }
        if (c == '`') {
            val e = s.indexOf('`', i + 1)
            if (e > i) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(s.substring(i + 1, e)) }
                i = e + 1; continue
            }
        }
        if (c == '$') {
            if (s.startsWith(DD, i)) {
                val e = s.indexOf(DD, i + 2)
                if (e > i + 2) {
                    putMath(s.substring(i + 2, e))
                    i = e + 2; continue
                }
            }
            val e = closingDollar(s, i)
            if (e > i) {
                putMath(s.substring(i + 1, e))
                i = e + 1; continue
            }
        }
        if (s.startsWith("**", i) || s.startsWith("__", i)) {
            val d = s.substring(i, i + 2)
            val e = s.indexOf(d, i + 2)
            if (e > i + 2) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(inlineMarkdown(s.substring(i + 2, e), codeBg, link, math)) }
                i = e + 2; continue
            }
        }
        if (s.startsWith("~~", i)) {
            val e = s.indexOf("~~", i + 2)
            if (e > i + 2) {
                withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { append(inlineMarkdown(s.substring(i + 2, e), codeBg, link, math)) }
                i = e + 2; continue
            }
        }
        if (c == '*' || c == '_') {
            val e = closingEmphasis(s, i)
            if (e > 0) {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(inlineMarkdown(s.substring(i + 1, e), codeBg, link, math)) }
                i = e + 1; continue
            }
        }
        if (c == '[') {
            val close = s.indexOf(']', i + 1)
            if (close > i && close + 1 < s.length && s[close + 1] == '(') {
                val end = s.indexOf(')', close + 2)
                if (end > close) {
                    val url = s.substring(close + 2, end).trim().substringBefore(' ')
                    pushStringAnnotation("URL", url)
                    withStyle(SpanStyle(color = link, textDecoration = TextDecoration.Underline)) {
                        append(inlineMarkdown(s.substring(i + 1, close), codeBg, link, math))
                    }
                    pop()
                    i = end + 1; continue
                }
            }
        }
        if (c == 'h' && (s.startsWith("http://", i) || s.startsWith("https://", i))) {
            var e = i
            while (e < s.length && !s[e].isWhitespace() && s[e] !in "<>)]") e++
            while (e > i && s[e - 1] in ".,;:!?") e--
            val url = s.substring(i, e)
            pushStringAnnotation("URL", url)
            withStyle(SpanStyle(color = link, textDecoration = TextDecoration.Underline)) { append(url) }
            pop()
            i = e; continue
        }
        if (c == '<') {
            val m = HTML_TAG.find(s, i)?.takeIf { it.range.first == i }
            if (m != null) {
                val closing = m.groupValues[1] == "/"
                val name = m.groupValues[2].lowercase()
                val attrs = m.groupValues[3]
                val after = m.range.last + 1
                if (name == "br") { append('\n'); i = after; continue }
                if (closing) {
                    if (name in WRAPPER_TAGS || name in FORMAT_TAGS || name == "a") { i = after; continue }
                } else {
                    if (name in WRAPPER_TAGS) { i = after; continue }
                    if (name == "img") { append(HTML_ALT.find(attrs)?.groupValues?.get(1) ?: ""); i = after; continue }
                    if (name in FORMAT_TAGS || name == "a") {
                        val e = s.indexOf("</$name>", after, ignoreCase = true)
                        if (e >= 0) {
                            val inner = s.substring(after, e)
                            if (name == "a") {
                                val href = HTML_HREF.find(attrs)?.groupValues?.get(1)
                                if (href != null) {
                                    pushStringAnnotation("URL", href)
                                    withStyle(SpanStyle(color = link, textDecoration = TextDecoration.Underline)) {
                                        append(inlineMarkdown(inner, codeBg, link, math))
                                    }
                                    pop()
                                } else {
                                    append(inlineMarkdown(inner, codeBg, link, math))
                                }
                            } else {
                                withStyle(tagStyle(name, codeBg)) { append(inlineMarkdown(inner, codeBg, link, math)) }
                            }
                            i = e + name.length + 3; continue
                        }
                    }
                }
            }
        }
        if (c == '&') {
            val ent = ENTITIES.entries.firstOrNull { s.startsWith(it.key, i) }
            if (ent != null) { append(ent.value); i += ent.key.length; continue }
        }
        append(c)
        i++
    }
}

private fun bold(a: AnnotatedString): AnnotatedString = buildAnnotatedString {
    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(a) }
}

// ============================ COMPOSE ============================

/** Text that opens [links](url) when tapped. Long-press selection still works through the parent SelectionContainer. */
@Composable
fun MdText(
    text: AnnotatedString, color: Color, fontSize: TextUnit, lineHeight: TextUnit,
    modifier: Modifier = Modifier,
    inline: Map<String, InlineTextContent> = emptyMap()
) {
    val uri = LocalUriHandler.current
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val hasLinks = text.getStringAnnotations("URL", 0, text.length).isNotEmpty()
    val m = if (hasLinks) modifier.pointerInput(text) {
        detectTapGestures { pos ->
            val l = layout ?: return@detectTapGestures
            val off = l.getOffsetForPosition(pos)
            text.getStringAnnotations("URL", off, off).firstOrNull()?.let { runCatching { uri.openUri(it.item) } }
        }
    } else modifier
    Text(text, color = color, fontSize = fontSize, lineHeight = lineHeight, modifier = m, inlineContent = inline, onTextLayout = { layout = it })
}

@Composable
fun MarkdownBlocks(src: String, color: Color, scale: Float) {
    val cs = MaterialTheme.colorScheme
    val blocks = remember(src) { parseMarkdown(src) }
    val codeBg = cs.surfaceVariant
    val link = cs.primary
    val fs = 15f * scale
    val lh = (fs * 1.5f).sp
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        blocks.forEach { b ->
            when (b) {
                is MdPara -> MdInline(b.text, color, fs.sp, lh)
                is MdHeading -> {
                    val sz = when (b.level) { 1 -> 22f; 2 -> 19f; 3 -> 17f; else -> 15.5f } * scale
                    MdInline(b.text, color, sz.sp, (sz * 1.35f).sp, Modifier.padding(top = 4.dp), bold = true)
                }
                is MdBullet -> Row(Modifier.padding(start = (b.indent * 16).dp)) {
                    Text(b.marker, color = color, fontSize = fs.sp, lineHeight = lh, modifier = Modifier.widthIn(min = 24.dp))
                    MdInline(b.text, color, fs.sp, lh, Modifier.weight(1f))
                }
                is MdQuote -> Row(Modifier.height(IntrinsicSize.Min)) {
                    repeat(b.depth.coerceAtMost(5)) {
                        Box(Modifier.width(3.dp).fillMaxHeight().background(cs.primary.copy(alpha = 0.6f)))
                        Spacer(Modifier.width(8.dp))
                    }
                    MdInline(b.text, cs.onSurfaceVariant, fs.sp, lh)
                }
                is MdTable -> MdTableView(b, color, scale)
                is MdImage -> MdImageView(b.alt, b.url)
                is MdMath -> MdMathView(b.tex, b.closed, color, scale)
                MdRule -> HorizontalDivider(Modifier.padding(vertical = 4.dp))
            }
        }
    }
}

/** Display math: real KaTeX typesetting once the formula is complete; text approximation while streaming or if KaTeX is missing. */
@Composable
fun MdMathView(tex: String, closed: Boolean, color: Color, scale: Float) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val available = remember { KatexAssets.available(ctx) }
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        if (available && closed) {
            KatexBlock(tex, color, 17f * scale)
        } else {
            val text = remember(tex) { latexToAnnotated(tex) }
            var expanded by remember(tex) { mutableStateOf(false) }
            ScrollBox(expanded, 260.dp, rememberScrollState(), rememberScrollState()) {
                Text(
                    text, color = color, fontFamily = FontFamily.Serif, fontSize = (18f * scale).sp, lineHeight = (26f * scale).sp,
                    modifier = Modifier.padding(4.dp).pointerInput(Unit) { detectTapGestures { expanded = !expanded } }
                )
            }
        }
    }
}

@Composable
fun MdTableView(t: MdTable, color: Color, scale: Float) {
    val cs = MaterialTheme.colorScheme
    val fs = 14f * scale
    val cols = t.rows.maxOf { it.size }
    val widths = (0 until cols).map { c ->
        (t.rows.maxOf { r -> r.getOrNull(c)?.length ?: 0 } * 7.5f * scale + 28f).coerceIn(64f, 240f).dp
    }
    val total = widths.fold(0.dp) { a, w -> a + w }
    val shape = RoundedCornerShape(8.dp)
    Column(Modifier.horizontalScroll(rememberScrollState()).clip(shape).border(1.dp, cs.outlineVariant, shape)) {
        t.rows.forEachIndexed { ri, row ->
            Row(Modifier.background(if (ri == 0) cs.surfaceVariant else Color.Transparent)) {
                for (c in 0 until cols) {
                    val a = inlineMarkdown(row.getOrNull(c) ?: "", cs.surfaceVariant, cs.primary)
                    MdText(
                        if (ri == 0) bold(a) else a, color, fs.sp, (fs * 1.4f).sp,
                        Modifier.width(widths[c]).padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
            if (ri < t.rows.lastIndex) Box(Modifier.width(total).height(1.dp).background(cs.outlineVariant))
        }
    }
}

// ============================ INLINE FORMULAS ============================

/** Collects the formulas found while turning one piece of text into styled text. */
class MathCtx(val max: Int = 8) {
    val items = ArrayList<String>()
}

/** Natural sizes (CSS px) reported by the inline formula web views, shared so a re-render needs no new guess. */
object MathSizes {
    val map = mutableStateMapOf<String, IntSize>()

    fun put(key: String, w: Int, h: Int) {
        val v = IntSize(w, h)
        if (map[key] != v) map[key] = v
    }
}

/**
 * Markdown text where $x^2$ and \(x^2\) are real KaTeX formulas that flow inside the line.
 * Without KaTeX (or beyond 8 formulas in one paragraph) formulas fall back to styled text.
 */
@Composable
fun MdInline(
    src: String, color: Color, fontSize: TextUnit, lineHeight: TextUnit,
    modifier: Modifier = Modifier, bold: Boolean = false
) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val available = remember { KatexAssets.available(ctx) }
    val codeBg = cs.surfaceVariant
    val link = cs.primary
    val math = remember(src, available) {
        if (available && (src.contains('$') || src.contains("\\("))) MathCtx() else null
    }
    val text = remember(src, codeBg, link, math, bold) {
        val t = inlineMarkdown(src, codeBg, link, math)
        if (bold) bold(t) else t
    }
    val cssPx = with(density) { fontSize.toDp().value }
    val inline: Map<String, InlineTextContent> = if (math == null || math.items.isEmpty()) emptyMap() else {
        math.items.mapIndexed { i, tex ->
            val key = "$tex|$cssPx|${color.toArgb()}"
            val known = MathSizes.map[key]
            val w = known?.width ?: maxOf(14, tex.length * 8)
            val h = known?.height ?: (cssPx * 1.5f).toInt()
            "math$i" to InlineTextContent(
                Placeholder(
                    width = with(density) { (w + 2).dp.toSp() }, height = with(density) { h.dp.toSp() },
                    placeholderVerticalAlign = PlaceholderVerticalAlign.TextCenter
                )
            ) {
                Box(Modifier.fillMaxSize()) {
                    KatexInline(tex, color, cssPx) { ww, hh -> MathSizes.put(key, ww, hh) }
                    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } })
                }
            }
        }.toMap()
    }
    MdText(text, color, fontSize, lineHeight, modifier, inline)
}
