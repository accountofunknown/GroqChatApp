package com.example.groqchat

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Home-screen widget: continue last chat or start a new one. */
class GroqWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val title = prefs.getString("widget_last_title", null)?.takeIf { it.isNotBlank() }
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_groq)
            views.setTextViewText(R.id.widget_title, title ?: context.getString(R.string.app_name))
            views.setTextViewText(
                R.id.widget_action,
                if (title != null) context.getString(R.string.widget_continue) else context.getString(R.string.shortcut_new_chat)
            )
            val open = Intent(context, MainActivity::class.java).apply {
                action = if (title != null) ACTION_OPEN_LAST else ACTION_NEW_CHAT
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pi = PendingIntent.getActivity(
                context, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_title, pi)
            views.setOnClickPendingIntent(R.id.widget_action, pi)
            manager.updateAppWidget(id, views)
        }
    }

    companion object {
        const val ACTION_NEW_CHAT = "com.example.groqchat.NEW_CHAT"
        const val ACTION_OPEN_SETTINGS = "com.example.groqchat.OPEN_SETTINGS"
        const val ACTION_OPEN_LAST = "com.example.groqchat.OPEN_LAST"
        const val ACTION_SHARE = "com.example.groqchat.SHARE_TEXT"
    }
}
