package com.example.groqchat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Whether the current window is wide enough for a two-pane layout (tablets / unfolded foldables). */
@Composable
fun isTwoPane(): Boolean {
    val cfg = LocalConfiguration.current
    return cfg.screenWidthDp >= 600
}

/** HSV colour picker for a custom accent. */
@Composable
fun CustomColorPicker(
    initial: Int,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val seed = if (initial != 0) Color(initial) else Color(0xFFD83A1F)
    val hsv = remember {
        val a = FloatArray(3)
        android.graphics.Color.colorToHSV(seed.toArgb(), a)
        mutableStateOf(a)
    }
    var h by remember { mutableStateOf(hsv.value[0]) }
    var s by remember { mutableStateOf(hsv.value[1]) }
    var v by remember { mutableStateOf(hsv.value[2]) }
    val preview = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.custom_color)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(preview)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                )
                Text("Hue ${h.roundToInt()}°", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = h, onValueChange = { h = it }, valueRange = 0f..360f)
                Text("Saturation ${(s * 100).roundToInt()}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = s, onValueChange = { s = it }, valueRange = 0f..1f)
                Text("Brightness ${(v * 100).roundToInt()}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = v, onValueChange = { v = it }, valueRange = 0.2f..1f)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onPick(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
                onDismiss()
            }) { Text("Apply") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/**
 * Wraps a message row with swipe-to-copy / swipe-to-delete and a long-press action menu.
 * Swipe right → copy, swipe left → delete (user messages) or copy (assistant).
 */
@Composable
fun SwipeableMessage(
    messageId: String,
    isUser: Boolean,
    text: String,
    onCopy: () -> Unit,
    onDelete: (() -> Unit)?,
    onEdit: (() -> Unit)?,
    onShare: (() -> Unit)?,
    onRegenerate: (() -> Unit)?,
    content: @Composable () -> Unit
) {
    var offsetX by remember(messageId) { mutableStateOf(0f) }
    var menuOpen by remember(messageId) { mutableStateOf(false) }
    val threshold = 120f
    val cd = stringResource(R.string.cd_long_press_menu)

    Box(
        Modifier
            .fillMaxWidth()
            .semantics { contentDescription = cd }
            .pointerInput(messageId) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        when {
                            offsetX > threshold -> onCopy()
                            offsetX < -threshold && onDelete != null -> onDelete()
                            offsetX < -threshold -> onCopy()
                        }
                        offsetX = 0f
                    },
                    onHorizontalDrag = { _, drag ->
                        offsetX = (offsetX + drag).coerceIn(-200f, 200f)
                    }
                )
            }
            .pointerInput(messageId) {
                detectTapGestures(onLongPress = { menuOpen = true })
            }
    ) {
        // Background hints while dragging
        if (offsetX > 20f) {
            Row(
                Modifier.matchParentSize().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.cd_swipe_copy), tint = MaterialTheme.colorScheme.primary)
            }
        } else if (offsetX < -20f) {
            Row(
                Modifier.matchParentSize().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (onDelete != null) Icons.Default.Delete else Icons.Default.ContentCopy,
                    contentDescription = if (onDelete != null) stringResource(R.string.cd_swipe_delete) else stringResource(R.string.cd_swipe_copy),
                    tint = if (onDelete != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
        Box(Modifier.offset(x = offsetX.dp / 3)) { content() }
    }

    if (menuOpen) {
        AlertDialog(
            onDismissRequest = { menuOpen = false },
            title = { Text("Message actions") },
            text = {
                Column {
                    TextButton(onClick = { onCopy(); menuOpen = false }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.ContentCopy, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.copy))
                    }
                    if (onEdit != null) {
                        TextButton(onClick = { onEdit(); menuOpen = false }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Edit, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.edit))
                        }
                    }
                    if (onShare != null) {
                        TextButton(onClick = { onShare(); menuOpen = false }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Share, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.share))
                        }
                    }
                    if (onRegenerate != null) {
                        TextButton(onClick = { onRegenerate(); menuOpen = false }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Refresh, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.regenerate))
                        }
                    }
                    if (onDelete != null) {
                        TextButton(
                            onClick = { onDelete(); menuOpen = false },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Delete, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.delete))
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

/** Simple filter for the long Settings screen. */
fun settingsSectionVisible(query: String, vararg labels: String): Boolean {
    if (query.isBlank()) return true
    val q = query.trim().lowercase()
    return labels.any { it.lowercase().contains(q) }
}

/** Theme JSON export helper (appearance-only subset). */
fun Settings.exportThemeJson(): String {
    return org.json.JSONObject()
        .put("theme", theme)
        .put("dynamicColor", dynamicColor)
        .put("accent", accent)
        .put("customAccent", customAccent)
        .put("amoled", amoled)
        .put("fontFamily", fontFamily)
        .put("fontScale", fontScale.toDouble())
        .put("bubbleRadius", bubbleRadius)
        .put("compact", compact)
        .toString(2)
}

fun Settings.importThemeJson(text: String): Settings? = try {
    val j = org.json.JSONObject(text)
    copy(
        theme = j.optString("theme", theme),
        dynamicColor = j.optBoolean("dynamicColor", dynamicColor),
        accent = j.optString("accent", accent),
        customAccent = j.optInt("customAccent", customAccent),
        amoled = j.optBoolean("amoled", amoled),
        fontFamily = j.optString("fontFamily", fontFamily),
        fontScale = j.optDouble("fontScale", fontScale.toDouble()).toFloat(),
        bubbleRadius = j.optInt("bubbleRadius", bubbleRadius),
        compact = j.optBoolean("compact", compact),
    )
} catch (_: Exception) { null }
