package com.example.groqchat

import org.json.JSONArray
import org.json.JSONObject

fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")

enum class Role(val api: String) { SYSTEM("system"), USER("user"), ASSISTANT("assistant"), TOOL("tool") }

data class ToolCall(val id: String, val name: String, val args: String)

/** One server-side tool action (built-in tool or MCP call) shown under a reply. */
data class ToolStep(val kind: String, val title: String, val detail: String)

/** A user-defined function tool. kind: "static" (fixed text), "webhook" (https call) or "ask" (you answer). */
data class CustomTool(
    val name: String,
    val description: String,
    val params: String = "",
    val kind: String = "webhook",
    val response: String = "",
    val method: String = "GET",
    val url: String = "",
    val headers: String = "",
    val enabled: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("name", name).put("description", description).put("params", params).put("kind", kind)
        .put("response", response).put("method", method).put("url", url).put("headers", headers)
        .put("enabled", enabled)

    companion object {
        fun fromJson(j: JSONObject) = CustomTool(
            name = j.str("name"), description = j.str("description"), params = j.str("params"),
            kind = j.str("kind").ifBlank { "webhook" }, response = j.str("response"),
            method = j.str("method").ifBlank { "GET" }, url = j.str("url"), headers = j.str("headers"),
            enabled = j.optBoolean("enabled", true),
        )
    }
}

/** A remote MCP server (custom URL) or a Groq Google Workspace connector. Stored encrypted. */
data class McpServer(
    val label: String,
    val url: String = "",
    val connector: String = "",
    val headerName: String = "Authorization",
    val token: String = "",
    val description: String = "",
    val allowedTools: String = "",
    val enabled: Boolean = true,
) {
    val isConnector: Boolean get() = connector.isNotBlank()
    val usable: Boolean get() = enabled && (isConnector || url.trim().startsWith("https://"))

    fun toJson(): JSONObject = JSONObject()
        .put("label", label).put("url", url).put("connector", connector).put("headerName", headerName)
        .put("token", token).put("description", description).put("allowedTools", allowedTools)
        .put("enabled", enabled)

    /** The entry placed in the request's `tools` array. */
    fun toTool(): JSONObject {
        val t = JSONObject().put("type", "mcp").put("server_label", label).put("require_approval", "never")
        if (isConnector) {
            t.put("connector_id", connector)
            if (token.isNotBlank()) t.put("authorization", token.trim().removePrefix("Bearer ").trim())
        } else {
            t.put("server_url", url.trim())
            if (token.isNotBlank()) {
                val name = headerName.ifBlank { "Authorization" }
                val v = if (name.equals("Authorization", true) && !token.trim().startsWith("Bearer ", true))
                    "Bearer ${token.trim()}" else token.trim()
                t.put("headers", JSONObject().put(name, v))
            }
        }
        if (description.isNotBlank()) t.put("server_description", description.trim())
        val allowed = allowedTools.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (allowed.isNotEmpty()) t.put("allowed_tools", JSONArray(allowed))
        return t
    }

    companion object {
        fun fromJson(j: JSONObject) = McpServer(
            label = j.str("label"), url = j.str("url"), connector = j.str("connector"),
            headerName = j.str("headerName").ifBlank { "Authorization" }, token = j.str("token"),
            description = j.str("description"), allowedTools = j.str("allowedTools"),
            enabled = j.optBoolean("enabled", true),
        )
    }
}

data class Msg(
    val id: Long = System.nanoTime(),
    val role: Role,
    val text: String = "",
    val images: List<String> = emptyList(),
    val reasoning: String = "",
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,
    val toolName: String? = null,
    val model: String? = null,
    val usage: String? = null,
    val error: Boolean = false,
    val steps: List<ToolStep> = emptyList(),
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("role", role.name).put("text", text)
        .put("images", JSONArray(images)).put("reasoning", reasoning)
        .put("toolCalls", JSONArray().also { a ->
            toolCalls.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("args", it.args)) }
        })
        .put("toolCallId", toolCallId ?: JSONObject.NULL)
        .put("toolName", toolName ?: JSONObject.NULL)
        .put("model", model ?: JSONObject.NULL)
        .put("usage", usage ?: JSONObject.NULL)
        .put("error", error)
        .put("steps", JSONArray().also { a ->
            steps.forEach { a.put(JSONObject().put("kind", it.kind).put("title", it.title).put("detail", it.detail)) }
        })

    companion object {
        fun fromJson(j: JSONObject): Msg {
            val imgs = j.optJSONArray("images")
            val tcs = j.optJSONArray("toolCalls")
            return Msg(
                id = j.optLong("id", System.nanoTime()),
                role = Role.valueOf(j.optString("role", "USER")),
                text = j.str("text"),
                images = if (imgs == null) emptyList() else (0 until imgs.length()).map { imgs.getString(it) },
                reasoning = j.str("reasoning"),
                toolCalls = if (tcs == null) emptyList() else (0 until tcs.length()).map {
                    val o = tcs.getJSONObject(it); ToolCall(o.str("id"), o.str("name"), o.str("args"))
                },
                toolCallId = j.str("toolCallId").ifEmpty { null },
                toolName = j.str("toolName").ifEmpty { null },
                model = j.str("model").ifEmpty { null },
                usage = j.str("usage").ifEmpty { null },
                error = j.optBoolean("error", false),
                steps = j.optJSONArray("steps")?.let { a ->
                    (0 until a.length()).map { i ->
                        val o = a.getJSONObject(i); ToolStep(o.str("kind"), o.str("title"), o.str("detail"))
                    }
                } ?: emptyList(),
            )
        }
    }
}

data class ModelInfo(val id: String, val owner: String, val ctx: Int, val active: Boolean)

data class Settings(
    val chatModel: String = "llama-3.3-70b-versatile",
    val visionModel: String = "qwen/qwen3.8-27b",
    val sttModel: String = "whisper-large-v3-turbo",
    val ttsModel: String = "canopylabs/orpheus-v1-english",
    val ttsVoice: String = "troy",
    val systemPrompt: String = "You are a helpful assistant.",
    val temperature: Float = 1f,
    val topP: Float = 1f,
    val maxTokens: Int = 2048,
    val reasoningEffort: String = "default",
    val showReasoning: Boolean = false,
    val jsonMode: Boolean = false,
    val tools: Boolean = false,
    val serviceTier: String = "on_demand",
    val translate: Boolean = false,
    val sttLanguage: String = "",
    val autoSpeak: Boolean = false,
    val stream: Boolean = true,
    val theme: String = "system",
    val dynamicColor: Boolean = false,
    val fontScale: Float = 1f,
    val browserSearch: Boolean = false,
    val codeExecution: Boolean = false,
    val toolMode: String = "auto",
    val deviceToolsOff: String = "",
    val identityHint: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("chatModel", chatModel).put("visionModel", visionModel).put("sttModel", sttModel)
        .put("ttsModel", ttsModel).put("ttsVoice", ttsVoice).put("systemPrompt", systemPrompt)
        .put("temperature", temperature.toDouble()).put("topP", topP.toDouble()).put("maxTokens", maxTokens)
        .put("reasoningEffort", reasoningEffort).put("showReasoning", showReasoning)
        .put("jsonMode", jsonMode).put("tools", tools).put("serviceTier", serviceTier)
        .put("translate", translate).put("sttLanguage", sttLanguage)
        .put("autoSpeak", autoSpeak).put("stream", stream)
        .put("theme", theme).put("dynamicColor", dynamicColor).put("fontScale", fontScale.toDouble())
        .put("browserSearch", browserSearch).put("codeExecution", codeExecution)
        .put("toolMode", toolMode).put("deviceToolsOff", deviceToolsOff)
        .put("identityHint", identityHint)

    companion object {
        fun fromJson(j: JSONObject): Settings {
            val d = Settings()
            return Settings(
                chatModel = j.optString("chatModel", d.chatModel),
                visionModel = j.optString("visionModel", d.visionModel),
                sttModel = j.optString("sttModel", d.sttModel),
                ttsModel = j.optString("ttsModel", d.ttsModel),
                ttsVoice = j.optString("ttsVoice", d.ttsVoice),
                systemPrompt = j.optString("systemPrompt", d.systemPrompt),
                temperature = j.optDouble("temperature", d.temperature.toDouble()).toFloat(),
                topP = j.optDouble("topP", d.topP.toDouble()).toFloat(),
                maxTokens = j.optInt("maxTokens", d.maxTokens),
                reasoningEffort = j.optString("reasoningEffort", d.reasoningEffort),
                showReasoning = j.optBoolean("showReasoning", d.showReasoning),
                jsonMode = j.optBoolean("jsonMode", d.jsonMode),
                tools = j.optBoolean("tools", d.tools),
                serviceTier = j.optString("serviceTier", d.serviceTier),
                translate = j.optBoolean("translate", d.translate),
                sttLanguage = j.optString("sttLanguage", d.sttLanguage),
                autoSpeak = j.optBoolean("autoSpeak", d.autoSpeak),
                stream = j.optBoolean("stream", d.stream),
                theme = j.optString("theme", d.theme),
                dynamicColor = j.optBoolean("dynamicColor", d.dynamicColor),
                fontScale = j.optDouble("fontScale", d.fontScale.toDouble()).toFloat(),
                browserSearch = j.optBoolean("browserSearch", d.browserSearch),
                codeExecution = j.optBoolean("codeExecution", d.codeExecution),
                toolMode = j.optString("toolMode", d.toolMode),
                deviceToolsOff = j.optString("deviceToolsOff", d.deviceToolsOff),
                identityHint = j.optBoolean("identityHint", d.identityHint),
            )
        }
    }
}

fun isVisionModel(id: String): Boolean {
    val m = id.lowercase()
    return "qwen3.8" in m || "llama-4" in m || "scout" in m || "maverick" in m || "vision" in m
}

fun isReasoningModel(id: String): Boolean {
    val m = id.lowercase()
    return "gpt-oss" in m || "qwen3" in m || "deepseek-r1" in m
}

val ENGLISH_VOICES = listOf("autumn", "diana", "hannah", "austin", "daniel", "troy")
val ARABIC_VOICES = listOf("abdullah", "fahad", "sultan", "lulwa", "noura", "aisha")

enum class Kind(val label: String) {
    CHAT("Chat"), STT("Speech to text"), TTS("Text to speech"), SAFETY("Safety / moderation")
}

fun kindOf(id: String): Kind {
    val m = id.lowercase()
    return when {
        "whisper" in m -> Kind.STT
        "orpheus" in m || "tts" in m -> Kind.TTS
        "guard" in m -> Kind.SAFETY
        else -> Kind.CHAT
    }
}

const val BUILTIN_MODEL = "openai/gpt-oss-120b"

fun isGptOss(id: String): Boolean = "gpt-oss" in id.lowercase()
