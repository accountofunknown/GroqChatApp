package com.example.groqchat

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val main = Handler(Looper.getMainLooper())
    private val recorder = Recorder(app)
    private val player = Player()

    var apiKey by mutableStateOf(store.apiKey)
        private set
    var settings by mutableStateOf(store.loadSettings())
        private set
    var models by mutableStateOf<List<ModelInfo>>(emptyList())
        private set
    var loadingModels by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var recording by mutableStateOf(false)
        private set
    var transcribing by mutableStateOf(false)
        private set
    var speakingId by mutableStateOf<Long?>(null)
        private set
    var draft by mutableStateOf("")
    var status by mutableStateOf<String?>(null)
    val messages = mutableStateListOf<Msg>()
    val chats = mutableStateListOf<ChatMeta>()
    var currentChatId by mutableStateOf("")
        private set
    val attachments = mutableStateListOf<String>()

    private val api = GroqApi { apiKey }
    private var job: Job? = null

    val chatModels: List<ModelInfo>
        get() = models.filter {
            val id = it.id.lowercase()
            !id.contains("whisper") && !id.contains("orpheus") && !id.contains("guard") && !id.contains("tts")
        }

    val owners: Map<String, String>
        get() = models.associate { it.id to it.owner }

    /** Picking any model from the full list assigns it to the matching role. */
    fun pickModel(id: String) {
        when (kindOf(id)) {
            Kind.STT -> { update(settings.copy(sttModel = id)); status = "Speech-to-text model: $id" }
            Kind.TTS -> {
                val v = if (id.contains("arabic")) ARABIC_VOICES.first() else ENGLISH_VOICES.last()
                update(settings.copy(ttsModel = id, ttsVoice = v)); status = "Text-to-speech model: $id"
            }
            else -> update(settings.copy(chatModel = id))
        }
    }

    // ---------- settings / key ----------
    fun update(s: Settings) { settings = s; store.saveSettings(s) }

    fun saveKey(k: String) {
        store.apiKey = k
        apiKey = k.trim()
        refreshModels()
    }

    fun refreshModels() {
        if (apiKey.isBlank()) return
        viewModelScope.launch {
            loadingModels = true
            try {
                models = api.listModels()
                val chat = chatModels
                if (chat.isNotEmpty() && chat.none { it.id == settings.chatModel }) {
                    val pick = chat.firstOrNull { it.id == "llama-3.3-70b-versatile" }
                        ?: chat.firstOrNull { it.id.contains("gpt-oss") } ?: chat.first()
                    update(settings.copy(chatModel = pick.id))
                }
                status = "${models.size} models loaded"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status = friendly(e) }
            finally { loadingModels = false }
        }
    }

    // ---------- chat ----------
    fun send() {
        val text = draft.trim()
        if (busy || (text.isEmpty() && attachments.isEmpty())) return
        if (apiKey.isBlank()) { status = "Add your Groq API key in Settings"; return }
        if (currentChatId.isEmpty()) {
            currentChatId = System.currentTimeMillis().toString()
            store.currentChatId = currentChatId
        }
        messages += Msg(role = Role.USER, text = text, images = attachments.toList())
        attachments.clear()
        draft = ""
        run()
    }

    fun stop() { job?.cancel() }

    /** Saves the open chat (if any) and switches to a blank one. Nothing is deleted. */
    fun newChat() {
        persist()
        resetView()
        currentChatId = ""
        store.currentChatId = ""
    }

    fun openChat(id: String) {
        if (id == currentChatId) return
        persist()
        resetView()
        currentChatId = id
        store.currentChatId = id
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) { store.loadChat(id) }
            if (currentChatId == id) { messages.clear(); messages.addAll(loaded) }
        }
    }

    fun deleteChat(id: String) {
        if (id == currentChatId) { resetView(); currentChatId = ""; store.currentChatId = "" }
        chats.removeAll { it.id == id }
        store.saveIndex(chats.toList())
        viewModelScope.launch(Dispatchers.IO) { store.deleteChat(id) }
    }

    fun clearAllChats() {
        resetView()
        currentChatId = ""
        chats.clear()
        viewModelScope.launch(Dispatchers.IO) { store.deleteAllChats() }
    }

    private fun resetView() {
        job?.cancel(); player.stop(); speakingId = null
        busy = false
        messages.clear(); attachments.clear(); draft = ""
    }

    fun regenerate() {
        if (busy) return
        while (messages.isNotEmpty() && messages.last().role != Role.USER) messages.removeAt(messages.lastIndex)
        if (messages.isNotEmpty()) run()
    }

    private fun run() {
        busy = true
        val cid = currentChatId
        job = viewModelScope.launch {
            try {
                var rounds = 0
                while (true) {
                    val reply = streamOne()
                    if (reply.toolCalls.isEmpty() || rounds++ >= 4) break
                    for (tc in reply.toolCalls) {
                        val result = withContext(Dispatchers.Default) { LocalTools.run(tc.name, tc.args) }
                        messages += Msg(role = Role.TOOL, text = result, toolCallId = tc.id, toolName = tc.name)
                    }
                }
                if (settings.autoSpeak) messages.lastOrNull { it.role == Role.ASSISTANT && it.text.isNotBlank() }?.let { speak(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages += Msg(role = Role.ASSISTANT, text = friendly(e), error = true)
            } finally {
                if (cid == currentChatId) { busy = false; persist() }
            }
        }
    }

    private suspend fun streamOne(): Msg {
        val body = buildBody()
        val model = body.getString("model")
        val stream = body.optBoolean("stream")
        val idx = messages.size
        messages += Msg(role = Role.ASSISTANT, model = model)
        val res = try {
            api.chat(body, stream) { t, r ->
                main.post { if (idx < messages.size) messages[idx] = messages[idx].copy(text = t, reasoning = r) }
            }
        } catch (e: Exception) {
            if (idx < messages.size && messages[idx].text.isEmpty() && messages[idx].reasoning.isEmpty()) messages.removeAt(idx)
            throw e
        }
        val final = Msg(
            id = messages[idx].id, role = Role.ASSISTANT, text = res.text, reasoning = res.reasoning,
            toolCalls = res.toolCalls, model = model, usage = res.usage
        )
        messages[idx] = final
        return final
    }

    private fun buildBody(): JSONObject {
        val s = settings
        val hasImages = messages.any { it.images.isNotEmpty() }
        val model = if (hasImages && !isVisionModel(s.chatModel)) s.visionModel else s.chatModel

        // Vision requests accept at most 3 images: keep the most recent ones.
        var budget = 3
        val keep = HashSet<Long>()
        for (m in messages.asReversed()) if (m.images.isNotEmpty() && budget >= m.images.size) { keep += m.id; budget -= m.images.size }

        val arr = JSONArray()
        if (s.systemPrompt.isNotBlank()) arr.put(JSONObject().put("role", "system").put("content", s.systemPrompt))
        for (m in messages) {
            if (m.error) continue
            when (m.role) {
                Role.USER -> {
                    if (m.images.isNotEmpty() && m.id in keep) {
                        val parts = JSONArray()
                        parts.put(JSONObject().put("type", "text").put("text", m.text.ifBlank { "Describe this image." }))
                        m.images.forEach {
                            parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", it)))
                        }
                        arr.put(JSONObject().put("role", "user").put("content", parts))
                    } else {
                        val t = if (m.images.isNotEmpty()) "[image omitted] ${m.text}" else m.text
                        arr.put(JSONObject().put("role", "user").put("content", t))
                    }
                }
                Role.ASSISTANT -> {
                    if (m.text.isBlank() && m.toolCalls.isEmpty()) continue
                    val o = JSONObject().put("role", "assistant")
                    o.put("content", if (m.text.isBlank()) JSONObject.NULL else m.text)
                    if (m.toolCalls.isNotEmpty()) {
                        val tc = JSONArray()
                        m.toolCalls.forEach {
                            tc.put(JSONObject().put("id", it.id).put("type", "function")
                                .put("function", JSONObject().put("name", it.name).put("arguments", it.args)))
                        }
                        o.put("tool_calls", tc)
                    }
                    arr.put(o)
                }
                Role.TOOL -> arr.put(JSONObject().put("role", "tool").put("tool_call_id", m.toolCallId).put("content", m.text))
                Role.SYSTEM -> {}
            }
        }

        val b = JSONObject()
            .put("model", model)
            .put("messages", arr)
            .put("temperature", s.temperature.toDouble())
            .put("top_p", s.topP.toDouble())
            .put("max_completion_tokens", s.maxTokens)
            .put("stream", s.stream && !s.jsonMode)
        if (s.jsonMode) b.put("response_format", JSONObject().put("type", "json_object"))
        else if (s.tools) b.put("tools", LocalTools.definitions).put("tool_choice", "auto")
        if (s.serviceTier != "on_demand") b.put("service_tier", s.serviceTier)
        if (isReasoningModel(model)) {
            if (s.reasoningEffort != "default") b.put("reasoning_effort", s.reasoningEffort)
            if (s.showReasoning) b.put("include_reasoning", true)
        }
        return b
    }

    // ---------- images ----------
    fun addImages(uris: List<Uri>) {
        viewModelScope.launch {
            for (u in uris) {
                if (attachments.size >= 3) { status = "Max 3 images per request"; break }
                val d = withContext(Dispatchers.IO) {
                    try { uriToDataUrl(getApplication(), u) } catch (e: Exception) { null }
                }
                if (d != null) attachments += d else status = "Couldn't read image"
            }
        }
    }

    // ---------- speech to text ----------
    fun toggleRecord() {
        if (recording) {
            recording = false
            val f = recorder.stop()
            if (f != null) transcribe(f) else status = "Recording too short"
        } else {
            if (apiKey.isBlank()) { status = "Add your Groq API key in Settings"; return }
            try { recorder.start(); recording = true } catch (e: Exception) { status = "Mic error: ${e.message}" }
        }
    }

    private fun transcribe(f: File) {
        transcribing = true
        viewModelScope.launch {
            try {
                val t = api.transcribe(f, settings.sttModel, settings.sttLanguage, settings.translate)
                draft = (draft + " " + t).trim()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status = friendly(e) }
            finally { transcribing = false; f.delete() }
        }
    }

    // ---------- text to speech ----------
    fun speak(m: Msg) {
        if (speakingId == m.id) { player.stop(); speakingId = null; return }
        player.stop()
        speakingId = m.id
        viewModelScope.launch {
            try {
                val chunks = TtsText.chunks(m.text)
                val files = mutableListOf<File>()
                for ((i, c) in chunks.withIndex()) {
                    val f = File(getApplication<Application>().cacheDir, "tts_${m.id}_$i.wav")
                    api.speech(c, settings.ttsModel, settings.ttsVoice, f)
                    files += f
                    if (speakingId != m.id) { files.forEach { it.delete() }; return@launch }
                }
                if (files.isEmpty()) speakingId = null
                else player.playAll(files) { speakingId = null }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status = friendly(e); speakingId = null }
        }
    }

    // ---------- helpers ----------
    private fun persist() {
        val id = currentChatId
        if (id.isEmpty() || messages.isEmpty()) return
        val snap = messages.toList()
        val old = chats.firstOrNull { it.id == id }
        val title = old?.title
            ?: snap.firstOrNull { it.role == Role.USER }?.text?.trim()?.replace("\n", " ")?.take(48)?.ifBlank { null }
            ?: "Image chat"
        chats.removeAll { it.id == id }
        chats.add(0, ChatMeta(id, title, System.currentTimeMillis()))
        store.saveIndex(chats.toList())
        viewModelScope.launch(Dispatchers.IO) { store.saveChat(id, snap) }
    }

    private fun friendly(e: Exception): String = when (e) {
        is ApiException -> when (e.code) {
            401 -> "Invalid API key (401). Check Settings."
            429 -> "Rate limit reached" + (e.retryAfter?.let { " – retry in ${it}s" } ?: "") + ". ${e.message}"
            else -> "Error ${e.code}: ${e.message}"
        }
        is IOException -> "Network error: ${e.message}"
        else -> e.message ?: e.javaClass.simpleName
    }

    override fun onCleared() { player.stop() }

    init {
        chats.addAll(store.loadIndex())
        val cur = store.currentChatId
        if (cur.isNotEmpty() && chats.any { it.id == cur }) {
            currentChatId = cur
            messages.addAll(store.loadChat(cur))
        }
        refreshModels()
    }
}
