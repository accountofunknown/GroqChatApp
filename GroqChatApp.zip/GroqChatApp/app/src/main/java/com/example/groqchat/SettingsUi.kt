package com.example.groqchat

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

fun SettingsScreen(vm: ChatViewModel, onClose: () -> Unit) {
    val s = vm.settings
    val cs = MaterialTheme.colorScheme
    val uri = LocalUriHandler.current
    val clipboardMgr = LocalClipboardManager.current
    var keyText by remember { mutableStateOf(vm.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<String?>(null) }
    var mcpEdit by remember { mutableStateOf<McpEdit?>(null) }
    var toolEdit by remember { mutableStateOf<ToolEdit?>(null) }
    var showUsage by remember { mutableStateOf(false) }
    var tplDialog by remember { mutableStateOf(false) }
    var savePersonaOpen by remember { mutableStateOf(false) }
    val modelIds = vm.chatModels.map { it.id }
    val sttIds = vm.models.map { it.id }.filter { it.contains("whisper") }
        .ifEmpty { listOf("whisper-large-v3-turbo", "whisper-large-v3") }
    val ttsIds = vm.models.map { it.id }.filter { it.contains("orpheus") }
        .ifEmpty { listOf("canopylabs/orpheus-v1-english", "canopylabs/orpheus-arabic-saudi") }
    val voices = if (s.ttsModel.contains("arabic")) ARABIC_VOICES else ENGLISH_VOICES

    var settingsQuery by rememberSaveable { mutableStateOf("") }
    var showColorPicker by remember { mutableStateOf(false) }
    var themePreviewText by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().background(cs.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 6.dp))
            TextButton(onClick = onClose, enabled = vm.apiKey.isNotBlank()) { Text("Done") }
        }
        OutlinedTextField(
            value = settingsQuery,
            onValueChange = { settingsQuery = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
            placeholder = { Text("Search settings") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search settings") },
            trailingIcon = {
                if (settingsQuery.isNotEmpty()) {
                    IconButton(onClick = { settingsQuery = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear")
                    }
                }
            }
        )
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)
                .navigationBarsPadding().imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (vm.apiKey.isBlank()) {
                Card(colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Welcome to Groq Chat", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                        Text("1. Create a free API key on the Groq console", color = cs.onPrimaryContainer, fontSize = 14.sp)
                        Text("2. Paste it below and tap “Save & load models”", color = cs.onPrimaryContainer, fontSize = 14.sp)
                        Text("3. Start chatting", color = cs.onPrimaryContainer, fontSize = 14.sp)
                        Button(onClick = { uri.openUri("https://console.groq.com/keys") }) { Text("Get an API key") }
                    }
                }
            }

            if (settingsSectionVisible(settingsQuery, "API key", "key", "token")) SettingsCard("API key", Icons.Default.Key, startOpen = vm.apiKey.isBlank()) {
                OutlinedTextField(
                    value = keyText, onValueChange = { keyText = it }, singleLine = true,
                    label = { Text("gsk_…") },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Show or hide key")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Hint("Stored encrypted on this device and only sent to api.groq.com.")
                Button(onClick = { vm.saveKey(keyText) }, enabled = keyText.isNotBlank() && !vm.loadingModels) {
                    Text(if (vm.loadingModels) "Loading models…" else "Save & load models")
                }
                if (vm.models.isNotEmpty()) Text("✓ ${vm.models.size} models available", color = cs.primary, fontSize = 13.sp)
            }

            if (settingsSectionVisible(settingsQuery, "Model", "chat model", "vision")) SettingsCard("Model", Icons.Default.AutoAwesome, startOpen = true) {
                Picker("Chat model", s.chatModel, modelIds, vm.owners) { vm.update(s.copy(chatModel = it)) }
                Picker("Vision model (used when images are attached)", s.visionModel,
                    vm.models.map { it.id }.filter(::isVisionModel), vm.owners) { vm.update(s.copy(visionModel = it)) }
                OutlinedTextField(
                    value = s.systemPrompt, onValueChange = { vm.update(s.copy(systemPrompt = it)) },
                    label = { Text("System prompt") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 6
                )
                Text("Personas", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (BUILTIN_PERSONAS + s.personas).forEach { p ->
                        FilterChip(
                            selected = s.systemPrompt.trim() == p.prompt.trim(),
                            onClick = { vm.applyPersona(p) }, label = { Text(p.name) }
                        )
                    }
                }
                OutlinedButton(onClick = { savePersonaOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Save current prompt as persona")
                }
                s.personas.forEach { p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.name, modifier = Modifier.weight(1f))
                        IconButton(onClick = { vm.deletePersona(p.name) }) { Icon(Icons.Default.Delete, "Delete persona") }
                    }
                }
                if (savePersonaOpen) {
                    var pname by remember { mutableStateOf("") }
                    AlertDialog(
                        onDismissRequest = { savePersonaOpen = false },
                        title = { Text("Save persona") },
                        text = {
                            OutlinedTextField(
                                value = pname, onValueChange = { pname = it }, singleLine = true,
                                label = { Text("Name") }, modifier = Modifier.fillMaxWidth()
                            )
                        },
                        confirmButton = {
                            TextButton(enabled = pname.isNotBlank(), onClick = {
                                vm.savePersona(pname, s.systemPrompt); savePersonaOpen = false
                            }) { Text("Save") }
                        },
                        dismissButton = { TextButton(onClick = { savePersonaOpen = false }) { Text("Cancel") } }
                    )
                }
            }

            if (settingsSectionVisible(settingsQuery, "Generation", "temperature", "top_p", "tokens", "creativity", "stream")) SettingsCard("Generation", Icons.Default.Tune) {
                Text("Style", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Precise" to 0.2f, "Balanced" to 0.7f, "Creative" to 1.2f).forEach { (name, v) ->
                        FilterChip(
                            selected = abs(s.temperature - v) < 0.05f,
                            onClick = { vm.update(s.copy(temperature = v)) },
                            label = { Text(name) }
                        )
                    }
                }
                LabeledSlider("Temperature", "%.2f".format(s.temperature), s.temperature, 0f..2f) { vm.update(s.copy(temperature = it)) }
                LabeledSlider("Top P", "%.2f".format(s.topP), s.topP, 0f..1f) { vm.update(s.copy(topP = it)) }
                LabeledSlider("Max completion tokens", s.maxTokens.toString(), s.maxTokens.toFloat(), 256f..8192f) {
                    vm.update(s.copy(maxTokens = ((it / 256f).roundToInt() * 256).coerceAtLeast(256)))
                }
                Picker("Service tier", s.serviceTier, listOf("on_demand", "auto", "flex", "performance")) { vm.update(s.copy(serviceTier = it)) }
                SwitchRow("Stream responses", "Show text as it is generated", s.stream) { vm.update(s.copy(stream = it)) }
            }

            if (settingsSectionVisible(settingsQuery, "Reasoning", "effort", "think", "psychology")) SettingsCard("Reasoning", Icons.Default.Psychology) {
                Text("Effort (gpt-oss and Qwen3 models)", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("default", "none", "low", "medium", "high").forEach { e ->
                        FilterChip(
                            selected = s.reasoningEffort == e,
                            onClick = { vm.update(s.copy(reasoningEffort = e)) },
                            label = { Text(e) }
                        )
                    }
                }
                Hint("“none” only works on Qwen3; gpt-oss supports low, medium and high.")
                SwitchRow("Show reasoning", "Display the model's thinking in a collapsible block", s.showReasoning) { vm.update(s.copy(showReasoning = it)) }
            }

            if (settingsSectionVisible(settingsQuery, "Tool use", "tools", "device", "function", "mcp", "build")) SettingsCard("Tool use", Icons.Default.Build) {
                val names = vm.functionToolNames
                val modeKey = if (s.toolMode.startsWith("fn:")) "fn" else s.toolMode
                Text("When the model uses tools", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("auto" to "Auto", "off" to "Off", "required" to "Required", "fn" to "Specific").forEach { (k, label) ->
                        FilterChip(
                            selected = modeKey == k,
                            onClick = { vm.update(s.copy(toolMode = if (k == "fn") "fn:" + (names.firstOrNull() ?: "") else k)) },
                            label = { Text(label) }
                        )
                    }
                }
                if (modeKey == "fn") Picker("Tool to force", s.toolMode.removePrefix("fn:"), names) { vm.update(s.copy(toolMode = "fn:$it")) }
                Hint("Auto: the model decides. Off: no tools at all (also pauses server tools and MCP). Required / Specific: forces a function tool on the first step of each reply, then returns to Auto.")
                SwitchRow("Function tools", "Let the model call the tools below", s.tools) { vm.update(s.copy(tools = it)) }
                HorizontalDivider()
                Text("Device tools", fontWeight = FontWeight.SemiBold)
                SwitchRow(
                    "Device data tools",
                    "Lets the model ask for your clipboard, approximate location or calendar. You approve every use, and Android asks for permission first.",
                    s.sensitiveTools
                ) { vm.update(s.copy(sensitiveTools = it)) }
                if (s.allowedTools.isNotBlank()) {
                    Hint("Always allowed: ${s.allowedTools}")
                    TextButton(onClick = { vm.update(s.copy(allowedTools = "")) }) { Text("Forget these choices") }
                }
                val off = s.deviceToolsOff.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                LocalTools.names.forEach { n ->
                    SwitchRow(n, DeviceTools.describe(n), n !in off) { on ->
                        val next = if (on) off - n else off + n
                        vm.update(s.copy(deviceToolsOff = next.joinToString(",")))
                    }
                }
                HorizontalDivider()
                Text("Your tools", fontWeight = FontWeight.SemiBold)
                if (vm.customTools.isEmpty()) Hint("None yet.")
                vm.customTools.forEachIndexed { i, t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { toolEdit = ToolEdit(i, t) }) {
                            Text(t.name, fontWeight = FontWeight.Medium)
                            Text(
                                "${t.kind} · ${t.description}", fontSize = 12.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
                            )
                        }
                        Switch(checked = t.enabled, onCheckedChange = { vm.updateTool(i, t.copy(enabled = it)) })
                        IconButton(onClick = { vm.removeTool(i) }) { Icon(Icons.Default.Delete, "Remove tool") }
                    }
                }
                OutlinedButton(onClick = { toolEdit = ToolEdit(-1, null) }, modifier = Modifier.fillMaxWidth()) { Text("Add custom tool") }
                Hint("Webhook calls your https URL (GET or POST) and returns the response. Static returns fixed text. Ask me pops up a question so you provide the result. Use {{param}} to insert the model's arguments.")
                toolEdit?.let { e ->
                    ToolDialog(e, vm.customTools.map { it.name }, onDismiss = { toolEdit = null }) { saved ->
                        if (e.index < 0) vm.addTool(saved) else vm.updateTool(e.index, saved)
                        toolEdit = null
                    }
                }
            }

            if (settingsSectionVisible(settingsQuery, "Output format", "json", "schema", "code")) SettingsCard("Output format", Icons.Default.Code) {
                SwitchRow("JSON mode", "Forces valid JSON (turns off streaming and tools). Mention “JSON” in your prompt.", s.jsonMode) { vm.update(s.copy(jsonMode = it)) }
                SwitchRow("Structured output (JSON schema)", "The reply must match your schema. Works with gpt-oss and Qwen3 models; turns off streaming and tools.", s.schemaOn) { vm.update(s.copy(schemaOn = it)) }
                if (s.schemaOn) {
                    val schemaValid = parseSchema(s.schemaText) != null
                    OutlinedTextField(
                        value = s.schemaText, onValueChange = { vm.update(s.copy(schemaText = it)) },
                        label = { Text("JSON schema") }, minLines = 4, maxLines = 12,
                        isError = !schemaValid && s.schemaText.isNotBlank(),
                        supportingText = {
                            Text(
                                when {
                                    s.schemaText.isBlank() -> "Paste a JSON Schema object, e.g. {\"type\":\"object\",\"properties\":{\"name\":{\"type\":\"string\"}}}"
                                    schemaValid -> "Valid JSON"
                                    else -> "Not valid JSON yet"
                                }
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!supportsSchema(s.chatModel)) {
                        Text("⚠ ${s.chatModel.substringAfterLast('/')} doesn't support structured output, so it will be skipped.", fontSize = 12.sp, color = cs.error)
                    }
                }
            }

            if (settingsSectionVisible(settingsQuery, "Server tools", "browser", "web", "search", "code execution", "mcp", "language")) SettingsCard("Server tools", Icons.Default.Language) {
                SwitchRow("Web browsing", "Groq's browser_search tool (gpt-oss models)", s.browserSearch) { vm.update(s.copy(browserSearch = it)) }
                SwitchRow("Code execution", "Runs Python on Groq's servers (code_interpreter)", s.codeExecution) { vm.update(s.copy(codeExecution = it)) }
                Hint("These run on Groq's servers and only work with gpt-oss models, so replies arrive all at once. Tip: set Reasoning effort to low when browsing.")
                if ((s.browserSearch || s.codeExecution) && !isGptOss(s.chatModel)) {
                    Text(
                        "⚠ Your selected model (${s.chatModel.substringAfterLast('/')}) can't use these tools, so they are skipped. Select a gpt-oss model to use them. Your model is never swapped automatically.",
                        fontSize = 12.sp, color = cs.error
                    )
                }
                HorizontalDivider()
                Text("Remote MCP servers & connectors", fontWeight = FontWeight.SemiBold)
                if (vm.mcpServers.isEmpty()) Hint("None added yet.")
                vm.mcpServers.forEachIndexed { i, srv ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { mcpEdit = McpEdit(i, srv, srv.isConnector) }) {
                            Text(srv.label, fontWeight = FontWeight.Medium)
                            Text(
                                if (srv.isConnector) srv.connector else srv.url, fontSize = 12.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
                            )
                        }
                        Switch(checked = srv.enabled, onCheckedChange = { vm.updateMcp(i, srv.copy(enabled = it)) })
                        IconButton(onClick = { vm.removeMcp(i) }) { Icon(Icons.Default.Delete, "Remove server") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { mcpEdit = McpEdit(-1, null, false) }, modifier = Modifier.weight(1f)) { Text("Add server") }
                    OutlinedButton(onClick = { mcpEdit = McpEdit(-1, null, true) }, modifier = Modifier.weight(1f)) { Text("Google connector") }
                }
                Hint("While an MCP server is enabled, requests use Groq's Responses API: local tools are paused, and replies stream when Groq allows it. MCP servers can see your conversation, so only add servers you trust.")
                mcpEdit?.let { e ->
                    McpDialog(e, onDismiss = { mcpEdit = null }) { saved ->
                        if (e.index < 0) vm.addMcp(saved) else vm.updateMcp(e.index, saved)
                        mcpEdit = null
                    }
                }
            }

            if (settingsSectionVisible(settingsQuery, "Voice", "speech", "tts", "stt", "mic", "whisper")) SettingsCard("Voice", Icons.Default.Mic) {
                Picker("Speech-to-text model", s.sttModel, sttIds, vm.owners) { vm.update(s.copy(sttModel = it)) }
                OutlinedTextField(
                    value = s.sttLanguage, onValueChange = { vm.update(s.copy(sttLanguage = it)) }, singleLine = true,
                    label = { Text("Language code (e.g. en) – blank = auto") }, modifier = Modifier.fillMaxWidth()
                )
                SwitchRow("Translate speech to English", "Uses whisper-large-v3", s.translate) { vm.update(s.copy(translate = it)) }
                HorizontalDivider()
                Picker("Text-to-speech model", s.ttsModel, ttsIds, vm.owners) { m ->
                    vm.update(s.copy(ttsModel = m, ttsVoice = if (m.contains("arabic")) ARABIC_VOICES.first() else ENGLISH_VOICES.last()))
                }
                Text("Voice", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    voices.forEach { v ->
                        FilterChip(selected = s.ttsVoice == v, onClick = { vm.update(s.copy(ttsVoice = v)) }, label = { Text(v) })
                    }
                }
                SwitchRow("Read replies aloud", "Speaks each answer automatically", s.autoSpeak) { vm.update(s.copy(autoSpeak = it)) }
            }

            if (settingsSectionVisible(settingsQuery, "Appearance", "Theme", "Accent", "Font", "color", "dark", "light")) SettingsCard("Appearance", Icons.Default.Palette) {
                Text("Theme", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (k, label) ->
                        FilterChip(selected = s.theme == k, onClick = { vm.update(s.copy(theme = k)) }, label = { Text(label) })
                    }
                }
                SwitchRow("Pure black dark mode", "True black backgrounds (saves battery on OLED screens)", s.amoled) { vm.update(s.copy(amoled = it)) }
                if (Build.VERSION.SDK_INT >= 31) {
                    SwitchRow("Use system colors", "Match your wallpaper (Material You). Turn off to use an accent color.", s.dynamicColor) { vm.update(s.copy(dynamicColor = it)) }
                }
                Text("Accent color", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ACCENT_PRESETS.forEach { (key, label, color) ->
                        val picked = s.accent == key && s.customAccent == 0 && !(Build.VERSION.SDK_INT >= 31 && s.dynamicColor)
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(color)
                                .then(if (picked) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier)
                                .clickable { vm.update(s.copy(accent = key, customAccent = 0, dynamicColor = false)) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (picked) Icon(Icons.Default.Check, label, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                }
                // Custom colour — always visible on its own row (not hidden in the scroll strip)
                val customPicked = s.customAccent != 0 && !(Build.VERSION.SDK_INT >= 31 && s.dynamicColor)
                val customColor = if (s.customAccent != 0) Color(s.customAccent) else cs.primary
                Row(
                    Modifier.fillMaxWidth().clickable { showColorPicker = true }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(customColor)
                            .then(if (customPicked) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier.border(1.dp, cs.outlineVariant, CircleShape)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Palette, "Custom colour", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Custom colour", fontSize = 14.sp)
                        Text(
                            if (customPicked) "Tap to edit · active" else "Pick any accent with the colour wheel",
                            fontSize = 12.sp, color = cs.onSurfaceVariant
                        )
                    }
                    if (customPicked) {
                        TextButton(onClick = { vm.update(s.copy(customAccent = 0, accent = "default")) }) {
                            Text("Clear")
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        clipboardMgr.setText(AnnotatedString(s.exportThemeJson()))
                        vm.status = "Theme copied — paste into a note or another device"
                    }, modifier = Modifier.weight(1f)) { Text("Export theme") }
                    OutlinedButton(onClick = {
                        val raw = clipboardMgr.getText()?.text.orEmpty()
                        if (themePreviewLines(raw) != null) themePreviewText = raw
                        else vm.status = "Clipboard has no valid theme JSON"
                    }, modifier = Modifier.weight(1f)) { Text("Import theme") }
                }
                Text("Font", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("default" to "Default", "serif" to "Serif", "mono" to "Mono").forEach { (k, label) ->
                        FilterChip(selected = s.fontFamily == k, onClick = { vm.update(s.copy(fontFamily = k)) }, label = { Text(label) })
                    }
                }
                LabeledSlider("Text size", "${(s.fontScale * 100).roundToInt()}%", s.fontScale, 0.85f..1.4f) { vm.update(s.copy(fontScale = it)) }
            }

            if (settingsSectionVisible(settingsQuery, "Chat display", "compact", "avatar", "haptic", "bubble")) SettingsCard("Chat display", Icons.Default.Settings) {
                SwitchRow("Compact spacing", "Tighter messages so more fit on screen", s.compact) { vm.update(s.copy(compact = it)) }
                SwitchRow("Show avatars", "The round G next to replies", s.showAvatar) { vm.update(s.copy(showAvatar = it)) }
                SwitchRow("Show model and usage", "Model name, tokens and speed under each reply", s.showMeta) { vm.update(s.copy(showMeta = it)) }
                LabeledSlider("Bubble roundness", "${s.bubbleRadius} dp", s.bubbleRadius.toFloat(), 4f..32f) { vm.update(s.copy(bubbleRadius = it.roundToInt())) }
                SwitchRow("Haptic feedback", "A light tick when you send or use the mic", s.haptics) { vm.update(s.copy(haptics = it)) }
                SwitchRow("Auto-title chats", "After the first reply, ask the model for a short title (one small extra request)", s.autoTitle) { vm.update(s.copy(autoTitle = it)) }
                SwitchRow("Enter key sends", "The keyboard's Enter button sends the message instead of adding a new line", s.enterSends) { vm.update(s.copy(enterSends = it)) }
                SwitchRow("Swipe on messages", "Swipe right to copy, left to delete (or long-press for a menu)", s.swipeGestures) { vm.update(s.copy(swipeGestures = it)) }
                LabeledSlider(
                    "Tablet chat list width",
                    "${s.paneWidthDp} dp",
                    s.paneWidthDp.toFloat(),
                    280f..420f
                ) { vm.update(s.copy(paneWidthDp = it.roundToInt())) }
                Hint("Tip: long-press a message for copy, edit, share or delete. Swipe can be turned off above. List width applies on tablets / foldables.")
            }

            if (settingsSectionVisible(settingsQuery, "Long chats", "context", "summarise", "summarize", "meter")) SettingsCard("Long chats", Icons.Default.Info) {
                SwitchRow("Show context meter", "Shows how full the model's context window is once a chat gets long", s.showContext) { vm.update(s.copy(showContext = it)) }
                SwitchRow("Auto-summarise when nearly full", "Condenses older messages into a summary after a reply when more than 85% of the context is used", s.autoSummarize) { vm.update(s.copy(autoSummarize = it)) }
                Hint("Summarised messages stay visible (dimmed) but are no longer sent to the model. The estimate uses about 4 characters per token.")
            }

            if (settingsSectionVisible(settingsQuery, "Prompt templates", "template", "prompt", "variable")) SettingsCard("Prompt templates", Icons.Default.Edit) {
                Hint("Pick a template from the attach (paperclip) menu. Write {{name}} where something should be filled in.")
                if (s.templates.isEmpty()) Hint("You haven't added any templates yet. ${BUILTIN_TEMPLATES.size} built-in ones are always available.")
                s.templates.forEach { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.name, fontWeight = FontWeight.Medium)
                            Text(t.body, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant)
                        }
                        IconButton(onClick = { vm.deleteTemplate(t.name) }) { Icon(Icons.Default.Delete, "Delete template") }
                    }
                }
                OutlinedButton(onClick = { tplDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Add template") }
                if (tplDialog) TemplateEditDialog(onDismiss = { tplDialog = false }) { n, b -> vm.saveTemplate(n, b); tplDialog = false }
            }

            if (settingsSectionVisible(settingsQuery, "Usage", "limits", "tokens", "rate", "dashboard")) SettingsCard("Usage & limits", Icons.Default.Tune) {
                Hint("Tokens and speed for every reply, by model. Only counts are stored (not your messages).")
                vm.lastRate?.let { Text("Last response: $it", fontSize = 13.sp) }
                OutlinedButton(onClick = { showUsage = true }, modifier = Modifier.fillMaxWidth()) { Text("Open usage dashboard") }
                if (showUsage) UsageSheet(vm) { showUsage = false }
            }

            if (settingsSectionVisible(settingsQuery, "Privacy", "storage", "lock", "fingerprint")) SettingsCard("Privacy & storage", Icons.Default.Lock) {
                val actCtx = LocalContext.current
                SwitchRow("Require unlock", "Ask for your fingerprint, face or screen lock when you open the app", s.appLock) { on ->
                    if (!on) vm.update(s.copy(appLock = false))
                    else if (AppLock.available(actCtx)) vm.update(s.copy(appLock = true))
                    else vm.status = "Set up a screen lock or fingerprint in Android settings first"
                }
                if (s.appLock) {
                    Text("Lock after leaving the app", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0 to "Immediately", 60 to "1 min", 300 to "5 min", 900 to "15 min").forEach { (sec, label) ->
                            FilterChip(selected = s.lockDelay == sec, onClick = { vm.update(s.copy(lockDelay = sec)) }, label = { Text(label) })
                        }
                    }
                    Hint("“Immediately” also locks the app after the photo picker or the share sheet.")
                }
                SwitchRow("Hide in recent apps", "Blocks screenshots and shows a blank preview in the app switcher", s.hideRecents) { vm.update(s.copy(hideRecents = it)) }
                Hint("Chats and images are always stored encrypted on this device (AES-256-GCM, with the key protected by the Android Keystore).")
            }

            if (settingsSectionVisible(settingsQuery, "Data", "delete", "reset", "export", "import", "settings")) SettingsCard("Data", Icons.Default.Delete) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { clipboardMgr.setText(AnnotatedString(vm.exportSettings())); vm.status = "Settings copied" },
                        modifier = Modifier.weight(1f)
                    ) { Text("Copy settings") }
                    OutlinedButton(
                        onClick = {
                            val ok = vm.importSettings(clipboardMgr.getText()?.text.orEmpty())
                            vm.status = if (ok) "Settings imported" else "Clipboard doesn't contain exported settings"
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Import settings") }
                }
                Hint("Exports appearance, model and prompt settings. API keys, MCP servers and custom tools are never included.")
                OutlinedButton(onClick = { confirm = "chats" }, modifier = Modifier.fillMaxWidth()) { Text("Delete all chats") }
                OutlinedButton(onClick = { confirm = "reset" }, modifier = Modifier.fillMaxWidth()) { Text("Reset settings") }
                OutlinedButton(
                    onClick = { confirm = "key" }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error)
                ) { Text("Remove API key") }
            }

            if (settingsSectionVisible(settingsQuery, "About", "version", "docs", "license", "info")) SettingsCard("About", Icons.Default.Info) {
                val aboutCtx = LocalContext.current
                val version = remember {
                    try { aboutCtx.packageManager.getPackageInfo(aboutCtx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
                }
                Text("Groq Chat $version", fontWeight = FontWeight.SemiBold)
                Hint("An unofficial client for the Groq API. Math is typeset with KaTeX (MIT license).")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { uri.openUri("https://console.groq.com/docs") }, modifier = Modifier.weight(1f)) { Text("Groq docs") }
                    OutlinedButton(onClick = { uri.openUri("https://console.groq.com/keys") }, modifier = Modifier.weight(1f)) { Text("API keys") }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showColorPicker) {
        CustomColorPicker(
            initial = s.customAccent,
            onPick = { argb -> vm.update(s.copy(customAccent = argb, dynamicColor = false, accent = "custom")) },
            onDismiss = { showColorPicker = false }
        )
    }
    themePreviewText?.let { raw ->
        val lines = themePreviewLines(raw).orEmpty()
        AlertDialog(
            onDismissRequest = { themePreviewText = null },
            title = { Text("Apply theme?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Preview of the theme on the clipboard:", fontSize = 13.sp)
                    lines.forEach { Text("• $it", fontSize = 13.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    s.importThemeJson(raw)?.let { vm.update(it); vm.status = "Theme applied" }
                    themePreviewText = null
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { themePreviewText = null }) { Text("Cancel") } }
        )
    }

    confirm?.let { what ->
        val title = when (what) {
            "chats" -> "Delete all chats?"
            "reset" -> "Reset settings?"
            else -> "Remove API key?"
        }
        val body = when (what) {
            "chats" -> "Every saved conversation is removed from this device."
            "reset" -> "All options return to their defaults. Your API key is kept."
            else -> "You will need to paste your key again to use the app."
        }
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = {
                TextButton(onClick = {
                    when (what) {
                        "chats" -> vm.clearAllChats()
                        "reset" -> vm.update(com.example.groqchat.Settings())
                        else -> { vm.saveKey(""); keyText = "" }
                    }
                    confirm = null
                }) { Text("Confirm") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun SettingsCard(title: String, icon: ImageVector, startOpen: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(startOpen) }
    ElevatedCard(Modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Row(
                Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Icon(
                    if (open) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    if (open) "Collapse" else "Expand"
                )
            }
            if (open) {
                Column(Modifier.padding(top = 2.dp, bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    content()
                }
            }
        }
    }
}

@Composable
fun Hint(text: String) {
    Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title)
            Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun LabeledSlider(label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Row { Text(label, modifier = Modifier.weight(1f)); Text(valueText, color = MaterialTheme.colorScheme.primary) }
        Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun Picker(
    label: String, value: String, options: List<String>,
    owners: Map<String, String> = emptyMap(), onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(value.ifBlank { "—" }, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ArrowDropDown, null)
        }
    }
    if (open) OptionSheet(
        title = label,
        options = (listOf(value) + options).filter { it.isNotBlank() }.distinct()
            .map { Opt(it, "", owners[it]?.ifBlank { "Other" } ?: "") },
        selected = setOf(value),
        onSelect = onSelect,
        onDismiss = { open = false }
    )
}

data class Opt(val id: String, val sub: String = "", val group: String = "")
