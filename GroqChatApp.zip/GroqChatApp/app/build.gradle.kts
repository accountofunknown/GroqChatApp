import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
// KaTeX (MIT) is downloaded at build time and bundled as app assets for real LaTeX rendering.
// If the download fails the build still succeeds and the app falls back to text-based math.
val katexVersion = "0.16.11"
val katexAssets = layout.buildDirectory.dir("generated/katex-assets")

val fetchKatex by tasks.registering {
    val outDir = katexAssets.get().asFile
    outputs.dir(outDir)
    outputs.upToDateWhen { File(outDir, "katex/katex.min.js").exists() }
    doLast {
        val target = File(outDir, "katex")
        if (File(target, "katex.min.js").exists() && File(target, "katex.min.css").exists()) return@doLast

        fun download(url: String, to: File) {
            URL(url).openStream().use { input -> to.outputStream().use { out -> input.copyTo(out) } }
        }
        fun install(tree: FileTree): Boolean {
            val js = tree.matching { include("**/katex.min.js") }.files.firstOrNull() ?: return false
            copy {
                from(js.parentFile) { include("katex.min.js", "katex.min.css", "fonts/*.woff2") }
                into(target)
            }
            return File(target, "katex.min.js").exists()
        }

        var ok = false
        try {
            val zip = File(temporaryDir, "katex.zip")
            download("https://github.com/KaTeX/KaTeX/releases/download/v$katexVersion/katex.zip", zip)
            ok = install(zipTree(zip))
        } catch (e: Exception) {
            logger.warn("KaTeX zip download failed: ${e.message}")
        }
        if (!ok) {
            try {
                val tgz = File(temporaryDir, "katex.tgz")
                download("https://registry.npmjs.org/katex/-/katex-$katexVersion.tgz", tgz)
                ok = install(tarTree(resources.gzip(tgz)))
            } catch (e: Exception) {
                logger.warn("KaTeX npm download failed: ${e.message}")
            }
        }
        if (ok) logger.lifecycle("KaTeX $katexVersion bundled into app assets.")
        else logger.warn("*** KaTeX could not be downloaded: LaTeX will use the built-in text fallback. ***")
    }
}

// Mermaid (MIT) draws diagrams from text. Downloaded at build time like KaTeX; without it diagrams show as code.
val mermaidVersion = "10.9.1"
val mermaidAssets = layout.buildDirectory.dir("generated/mermaid-assets")

val fetchMermaid by tasks.registering {
    val outDir = mermaidAssets.get().asFile
    outputs.dir(outDir)
    outputs.upToDateWhen { File(outDir, "mermaid/mermaid.min.js").exists() }
    doLast {
        val target = File(outDir, "mermaid")
        val dest = File(target, "mermaid.min.js")
        if (dest.exists() && dest.length() > 100_000) return@doLast
        target.mkdirs()
        fun download(url: String, to: File) {
            URL(url).openStream().use { input -> to.outputStream().use { out -> input.copyTo(out) } }
        }
        var ok = false
        try {
            download("https://cdn.jsdelivr.net/npm/mermaid@$mermaidVersion/dist/mermaid.min.js", dest)
            ok = dest.length() > 100_000
        } catch (e: Exception) {
            logger.warn("Mermaid download failed: ${e.message}")
        }
        if (!ok) {
            try {
                val tgz = File(temporaryDir, "mermaid.tgz")
                download("https://registry.npmjs.org/mermaid/-/mermaid-$mermaidVersion.tgz", tgz)
                val js = tarTree(resources.gzip(tgz)).matching { include("**/dist/mermaid.min.js") }.files.firstOrNull()
                if (js != null) {
                    js.copyTo(dest, overwrite = true)
                    ok = dest.length() > 100_000
                }
            } catch (e: Exception) {
                logger.warn("Mermaid npm download failed: ${e.message}")
            }
        }
        if (!ok) dest.delete()
        if (ok) logger.lifecycle("Mermaid $mermaidVersion bundled into app assets.")
        else logger.warn("*** Mermaid could not be downloaded: diagrams will be shown as code. ***")
    }
}

tasks.matching { it.name == "preBuild" || (it.name.startsWith("merge") && it.name.endsWith("Assets")) }
    .configureEach { dependsOn(fetchKatex, fetchMermaid) }

android {
    namespace = "com.example.groqchat"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.groqchat"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    sourceSets { getByName("main") { assets.srcDir(katexAssets); assets.srcDir(mermaidAssets) } }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.3")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
