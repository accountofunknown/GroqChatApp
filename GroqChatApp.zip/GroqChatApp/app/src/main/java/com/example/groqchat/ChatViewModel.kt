package com.example.groqchat

import android.app.Application
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val main = Handler(Looper.getMainLooper())
    private val recorder = Recorder(app)
    private val player = Player()

    var apiKey by mutableStateOf(store.apiKey)
    var searchApiKey by mutableStateOf(store.searchApiKey)
        private set
    var settings by mutableStateOf(store.loadSettings())
        private set
    var models by mutableStateOf<List<ModelInfo>>(emptyList())
        private set
    var loadingModels by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var recording by mutableStateOf(false)
        private set
    var transcribing by mutableStateOf(false)
        private set
    var speakingId by mutableStateOf<Long?>(null)
    var canvasText by mutableStateOf<String?>(null)
    var canvasTitle by mutableStateOf("Canvas")
    var searchCitations by mutableStateOf<List<Citation>>(emptyList())
    var editingMessageId by mutableStateOf<Long?>(null)
        private set
    var draft by mutableStateOf("")
    /** Temporary chat: not written to disk until [saveIncognitoChat]. */
    var incognito by mutableStateOf(false)
        private set
    data class ToolLogEntry(val time: Long, val name: String, val detail: String, val ok: Boolean)
    val toolLog = mutableStateListOf<ToolLogEntry>()

    var status by mutableStateOf<String?>(null)
    val messages = mutableStateListOf<Msg>()
    val chats = mutableStateListOf<ChatMeta>()
    val mcpServers = mutableStateListOf<McpServer>()
    val customTools = mutableStateListOf<CustomTool>()

    /** A custom "Ask me" tool waiting for the user to type the result. */
    class AskRequest(val tool: String, val args: String, val answer: CompletableDeferred<String>)
    var pendingAsk by mutableStateOf<AskRequest?>(null)
        private set
    var currentChatId by mutableStateOf("")
        private set
    val attachments = mutableStateListOf<String>()
    val docs = mutableStateListOf<Doc>()

    /** This chat's overrides of the default model, system prompt, creativity and reasoning effort. */
    var chatPrefs by mutableStateOf(ChatPrefs())
        private set
    var summarizing by mutableStateOf(false)
        private set
    var lastRate by mutableStateOf<String?>(null)
        private set
    var voiceMode by mutableStateOf(false)
        private set
    var voiceState by mutableStateOf("")
        private set
    var voiceLevel by mutableStateOf(0f)
        private set
    private var voiceJob: Job? = null

    class ConsentRequest(val tool: String, val answer: CompletableDeferred<Int>)
    class PermissionRequest(val permission: String, val answer: CompletableDeferred<Boolean>)
    class ApprovalRequest(val server: String, val tool: String, val args: String, val answer: CompletableDeferred<Boolean>)

    /** A device tool is waiting for you to allow it (0 = deny, 1 = once, 2 = always). */
    var pendingConsent by mutableStateOf<ConsentRequest?>(null)
        private set
    /** An Android runtime permission the UI should ask for. */
    var pendingPermission by mutableStateOf<PermissionRequest?>(null)
        private set
    /** An MCP server is waiting for you to allow one of its tool calls. */
    var pendingApproval by mutableStateOf<ApprovalRequest?>(null)
        private set
    private var oneShotModel: String? = null
    private var regenBase: List<Alt> = emptyList()
    private var regenBackup: List<Msg> = emptyList()

    private val api = GroqApi { apiKey }
    private var job: Job? = null

    val chatModels: List<ModelInfo>
        get() = models.filter {
            val id = it.id.lowercase()
            !id.contains("whisper") && !id.contains("orpheus") && !id.contains("guard") && !id.contains("tts")
        }

    val owners: Map<String, String>
        get() = models.associate { it.id to it.owner }

    /** Picking any model from the full list assigns it to the matching role. */
    fun pickModel(id: String) {
        when (kindOf(id)) {
            Kind.STT -> { update(settings.copy(sttModel = id)); status = "Speech-to-text model: $id" }
            Kind.TTS -> {
                val v = if (id.contains("arabic")) ARABIC_VOICES.first() else ENGLISH_VOICES.last()
                update(settings.copy(ttsModel = id, ttsVoice = v)); status = "Text-to-speech model: $id"
            }
            else -> updateChatPrefs(chatPrefs.copy(model = id))
        }
    }

    /** Global settings with this chat's overrides applied. */
    val cfg: Settings
        get() = settings.copy(
            chatModel = chatPrefs.model.ifBlank { settings.chatModel },
            systemPrompt = chatPrefs.systemPrompt ?: settings.systemPrompt,
            temperature = if (chatPrefs.temperature >= 0f) chatPrefs.temperature else settings.temperature,
            reasoningEffort = chatPrefs.reasoningEffort.ifBlank { settings.reasoningEffort },
        )

    /** The model this chat uses now. */
    val activeModel: String get() = cfg.chatModel
    private val activeChatModel: String get() = oneShotModel ?: cfg.chatModel

    val contextWindow: Int get() = models.firstOrNull { it.id == activeChatModel }?.ctx ?: 0

    /** Rough token estimate (about 4 characters per token, 800 per image) of what the next request would carry. */
    val contextUsed: Int
        get() {
            var chars = cfg.systemPrompt.length + 300
            var pics = 0
            for (m in messages) {
                if (m.summarized || m.error) continue
                chars += m.text.length
                for (d in m.docs) chars += d.text.length
                for (t in m.toolCalls) chars += t.args.length
                pics += m.images.size
            }
            return chars / 4 + pics * 800
        }

    fun updateChatPrefs(p: ChatPrefs) {
        chatPrefs = p
        val i = chats.indexOfFirst { it.id == currentChatId }
        if (i >= 0) {
            chats[i] = chats[i].copy(prefs = if (p.isDefault) "" else p.toJson().toString())
            saveMetaAsync(chats[i])
        }
    }

    /** Turns this chat's overrides into the defaults for every chat. */
    fun makePrefsDefault() {
        val c = cfg
        update(settings.copy(chatModel = c.chatModel, systemPrompt = c.systemPrompt, temperature = c.temperature, reasoningEffort = c.reasoningEffort))
        updateChatPrefs(ChatPrefs())
    }

    // ---------- settings / key ----------
    fun update(s: Settings) { settings = s; store.saveSettings(s) }

    fun saveSearchApiKey(key: String) {
        searchApiKey = key.trim()
        store.searchApiKey = searchApiKey
    }

    fun setActiveWorkspace(id: String) {
        val ws = settings.workspaces.firstOrNull { it.id == id }
        update(settings.copy(activeWorkspaceId = id))
        if (ws != null && ws.model.isNotBlank()) {
            update(settings.copy(activeWorkspaceId = id, chatModel = ws.model.ifBlank { settings.chatModel }))
        }
        if (ws != null && currentChatId.isNotEmpty()) {
            setFolder(listOf(currentChatId), ws.name)
        }
        status = if (ws != null) "Workspace: ${ws.name}" else "No workspace"
    }

    fun saveWorkspace(ws: Workspace) {
        val list = settings.workspaces.toMutableList()
        val i = list.indexOfFirst { it.id == ws.id }
        if (i >= 0) list[i] = ws else list += ws
        update(settings.copy(workspaces = list))
    }

    fun deleteWorkspace(id: String) {
        update(settings.copy(
            workspaces = settings.workspaces.filter { it.id != id },
            activeWorkspaceId = if (settings.activeWorkspaceId == id) "" else settings.activeWorkspaceId
        ))
    }

    fun toggleChatLock() {
        val p = chatPrefs.copy(chatLocked = !chatPrefs.chatLocked)
        updateChatPrefs(p)
        status = if (p.chatLocked) "This chat is locked" else "Chat unlocked"
    }

    fun completeOnboarding() {
        update(settings.copy(onboardingDone = true))
    }

    fun memoryFacts(): List<MemoryFact> = MemoryStore.parse(settings.memoryJson)

    fun addMemory(text: String) {
        val t0 = text.trim()
        if (t0.isBlank()) return
        val list = memoryFacts() + MemoryFact(text = t0.take(500))
        update(settings.copy(memoryJson = MemoryStore.toJson(list.takeLast(40))))
        status = "Remembered"
    }

    fun removeMemory(id: String) {
        update(settings.copy(memoryJson = MemoryStore.toJson(memoryFacts().filter { it.id != id })))
    }

    fun clearMemory() {
        update(settings.copy(memoryJson = "[]"))
        status = "Memory cleared"
    }

    fun openCanvas(text: String, title: String = "Canvas") {
        canvasTitle = title
        canvasText = text
    }

    fun closeCanvas() { canvasText = null }

    fun editUserMessage(id: Long, newText: String) {
        val text = newText.trim()
        if (text.isBlank() || busy) return
        val i = messages.indexOfFirst { it.id == id && it.role == Role.USER }
        if (i < 0) return
        // Drop this message and everything after; resend edited text
        while (messages.size > i) messages.removeAt(messages.lastIndex)
        messages += Msg(role = Role.USER, text = text)
        editingMessageId = null
        draft = ""
        persist()
        run()
    }

    fun beginEditUserMessage(id: Long) {
        val m = messages.firstOrNull { it.id == id && it.role == Role.USER } ?: return
        editingMessageId = id
        draft = m.text
        status = "Edit the draft and send to continue from there"
    }

    /** Generate image via Pollinations (no Groq image-gen API). */
    fun generateImage(prompt: String) {
        val p = prompt.trim()
        if (p.isBlank() || busy) return
        viewModelScope.launch {
            try {
                busy = true
                status = "Generating image…"
                val url = "https://image.pollinations.ai/prompt/${java.net.URLEncoder.encode(p, "UTF-8")}?width=768&height=768&nologo=true"
                // Store as remote URL in a user+assistant pair for display
                messages += Msg(role = Role.USER, text = "Generate image: $p")
                messages += Msg(role = Role.ASSISTANT, text = "![generated]($url)

_Image via Pollinations (not a Groq model)._")
                persist()
                status = "Image ready"
            } catch (e: Exception) {
                status = friendly(e)
            } finally {
                busy = false
            }
        }
    }


    private fun autoArchiveIfNeeded() {
        val days = settings.autoArchiveDays
        if (days <= 0) return
        val cutoff = System.currentTimeMillis() - days * 24L * 60L * 60L * 1000L
        val toArch = chats.filter { !it.archived && !it.pinned && it.updated < cutoff }.map { it.id }
        if (toArch.isNotEmpty()) editChats(toArch) { it.copy(archived = true) }
    }


    // ---------- MCP servers / connectors ----------
    private fun saveMcp(list: List<McpServer>) {
        mcpServers.clear(); mcpServers.addAll(list); store.saveMcp(list)
    }
    fun addMcp(s: McpServer) = saveMcp(mcpServers.toList() + s)
    fun updateMcp(i: Int, s: McpServer) = saveMcp(mcpServers.toMutableList().also { if (i in it.indices) it[i] = s })
    fun removeMcp(i: Int) = saveMcp(mcpServers.toMutableList().also { if (i in it.indices) it.removeAt(i) })

    // ---------- custom function tools ----------
    private fun saveTools(list: List<CustomTool>) {
        customTools.clear(); customTools.addAll(list); store.saveTools(list)
    }
    fun addTool(t: CustomTool) = saveTools(customTools.toList() + t)
    fun updateTool(i: Int, t: CustomTool) = saveTools(customTools.toMutableList().also { if (i in it.indices) it[i] = t })
    fun removeTool(i: Int) = saveTools(customTools.toMutableList().also { if (i in it.indices) it.removeAt(i) })

    private fun deviceOff(): Set<String> {
        val off = settings.deviceToolsOff.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        return if (settings.sensitiveTools) off else off + DeviceTools.SENSITIVE
    }

    private fun activeCustom(): List<CustomTool> = customTools.filter { it.enabled && CustomTools.valid(it) }

    /** Names of every function tool the model could currently call. */
    val functionToolNames: List<String>
        get() = LocalTools.names.filter { it !in deviceOff() } + (if (settings.clientWebTools) WebTools.names else emptyList()) + activeCustom().map { it.name }

    fun answerAsk(text: String?) {
        pendingAsk?.answer?.complete(text ?: "The user declined to provide a result.")
    }

    private suspend fun askUser(t: CustomTool, args: String): String {
        val req = AskRequest(t.name, args, CompletableDeferred())
        pendingAsk = req
        try { return req.answer.await() } finally { pendingAsk = null }
    }

    private suspend fun runTool(name: String, args: String): String {
        if (name in WebTools.names) {
            if (!settings.clientWebTools) return "Error: client web tools are disabled in Settings"
            return withContext(Dispatchers.IO) { WebTools.run(name, args, searchApiKey) }
        }
        if (name in DeviceTools.names) return runDeviceTool(name, args)
        val t = customTools.firstOrNull { it.name == name && it.enabled }
            ?: return withContext(Dispatchers.Default) { LocalTools.run(name, args) }
        return when (t.kind) {
            "static" -> CustomTools.fill(t.response, args)
            "ask" -> askUser(t, args)
            else -> CustomTools.webhook(t, args)
        }
    }

    // ---------- device tools: you approve every use of the sensitive ones ----------
    private fun allowedSet(): Set<String> =
        settings.allowedTools.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    private suspend fun runDeviceTool(name: String, args: String): String {
        val app = getApplication<Application>()
        if (name in DeviceTools.SENSITIVE) {
            if (name !in allowedSet()) {
                when (askConsent(name)) {
                    0 -> return "The user declined to share this."
                    2 -> update(settings.copy(allowedTools = (allowedSet() + name).joinToString(",")))
                }
            }
            val perm = DeviceTools.permissionFor(name)
            if (perm != null && !ensurePermission(perm)) return "Android permission was not granted, so this data is unavailable."
        }
        val where = if (name == "read_clipboard") Dispatchers.Main else Dispatchers.IO
        return withContext(where) { DeviceTools.run(app, name, args) }
    }

    private suspend fun askConsent(tool: String): Int {
        val req = ConsentRequest(tool, CompletableDeferred())
        pendingConsent = req
        try { return req.answer.await() } finally { pendingConsent = null }
    }

    fun answerConsent(choice: Int) { pendingConsent?.answer?.complete(choice) }

    private suspend fun ensurePermission(p: String): Boolean {
        val app = getApplication<Application>()
        if (ContextCompat.checkSelfPermission(app, p) == PackageManager.PERMISSION_GRANTED) return true
        val req = PermissionRequest(p, CompletableDeferred())
        pendingPermission = req
        try { return req.answer.await() } finally { pendingPermission = null }
    }

    fun permissionResult(ok: Boolean) { pendingPermission?.answer?.complete(ok) }

    /** First step of a reply honours Required / Specific; later steps go back to auto so the loop can finish. */
    private fun toolChoice(round: Int, names: List<String>): Any {
        val m = settings.toolMode
        if (round > 0 || names.isEmpty()) return "auto"
        return when {
            m == "required" -> "required"
            m.startsWith("fn:") && m.removePrefix("fn:") in names ->
                JSONObject().put("type", "function").put("function", JSONObject().put("name", m.removePrefix("fn:")))
            else -> "auto"
        }
    }

    fun saveKey(k: String) {
        store.apiKey = k
        apiKey = k.trim()
        refreshModels()
    }

    fun refreshModels(loud: Boolean = true) {
        if (apiKey.isBlank()) return
        viewModelScope.launch {
            loadingModels = true
            try {
                models = api.listModels()
                val chat = chatModels
                var note = ""
                if (chat.isNotEmpty() && chat.none { it.id == settings.chatModel }) {
                    val pick = chat.firstOrNull { it.id == "llama-3.3-70b-versatile" }
                        ?: chat.firstOrNull { it.id.contains("gpt-oss") } ?: chat.first()
                    note = " · ${settings.chatModel.substringAfterLast('/')} is no longer available, switched to ${pick.id.substringAfterLast('/')}"
                    update(settings.copy(chatModel = pick.id))
                }
                if (loud || note.isNotEmpty()) status = "${models.size} models loaded$note"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status = friendly(e) }
            finally { loadingModels = false }
        }
    }

    // ---------- chat ----------
    fun send() {
        var text = draft.trim()
        if (busy || (text.isEmpty() && attachments.isEmpty() && docs.isEmpty())) return
        if (apiKey.isBlank()) { status = "Add your Groq API key in Settings"; return }
        if (settings.redactSecrets && text.isNotEmpty()) {
            val red = SecretRedaction.redact(text)
            if (red != text) {
                text = red
                status = "Secrets redacted before send"
            }
        }
        if (settings.routerMode && text.isNotEmpty()) applyRouter(text)
        if (settings.searchMode) {
            searchCitations = emptyList()
            // Ensure tools available for search
            if (!settings.tools || !settings.clientWebTools) {
                update(settings.copy(tools = true, clientWebTools = true))
            }
        }
        if (currentChatId.isEmpty()) {
            currentChatId = System.currentTimeMillis().toString()
            store.currentChatId = currentChatId
        }
        messages += Msg(role = Role.USER, text = text, images = attachments.toList(), docs = docs.toList())
        attachments.clear()
        docs.clear()
        draft = ""
        run()
    }

    /** Heuristic Fast/Cheap/Smart model pick from the user prompt. */
    private fun applyRouter(text: String) {
        val t = text.lowercase()
        val kind = when {
            t.length > 1200 || listOf("architect", "refactor", "prove", "complex", "analyze in depth", "compare trade").any { it in t } -> "smart"
            listOf("summarize", "tldr", "translate", "quick", "short answer", "yes or no").any { it in t } || t.length < 80 -> "fast"
            listOf("code", "debug", "implement", "write a", "function", "sql").any { it in t } -> "smart"
            else -> "cheap"
        }
        applyModelPreset(kind)
    }

    /** Handle slash commands in the draft. Returns true if the command was consumed. */
    fun runSlashCommand(raw: String): Boolean {
        val line = raw.trim()
        if (!line.startsWith("/")) return false
        val trimmed = line.removePrefix("/").trim()
        val sp = trimmed.indexOf(' ')
        val parts = if (sp < 0) listOf(trimmed) else listOf(trimmed.substring(0, sp), trimmed.substring(sp + 1).trim())
        val cmd = parts[0].lowercase()
        val arg = parts.getOrNull(1).orEmpty()
        when (cmd) {
            "help" -> status = "Commands: /help /fast /smart /search on|off /remember … /forget /image … /canvas /web /router /incognito /stop"
            "fast" -> applyModelPreset("fast")
            "cheap" -> applyModelPreset("cheap")
            "smart" -> applyModelPreset("smart")
            "model" -> {
                if (arg.isNotBlank()) update(settings.copy(chatModel = arg.trim()))
                status = "Model: ${settings.chatModel}"
            }
            "incognito" -> startIncognitoChat()
            "export" -> status = "Use ⋮ → Export Markdown file"
            "stop" -> stop()
            "web" -> {
                val on = arg.lowercase() !in listOf("off", "0", "false")
                update(settings.copy(clientWebTools = on, tools = settings.tools || on))
                status = if (on) "Client web tools on" else "Client web tools off"
            }
            "router" -> {
                val on = arg.lowercase() !in listOf("off", "0", "false")
                update(settings.copy(routerMode = on))
                status = if (on) "Router mode on" else "Router mode off"
            }
            "clear" -> { draft = ""; status = "Draft cleared" }
            "remember" -> { if (arg.isNotBlank()) addMemory(arg); status = "Remembered: $arg" }
            "forget" -> { clearMemory() }
            "search" -> {
                val on = arg.lowercase() !in listOf("off", "0", "false")
                update(settings.copy(searchMode = on, tools = true, clientWebTools = true))
                status = if (on) "Search mode on" else "Search mode off"
            }
            "image" -> { if (arg.isNotBlank()) generateImage(arg) else status = "Usage: /image a red bicycle" }
            "canvas" -> {
                val last = messages.lastOrNull { it.role == Role.ASSISTANT && it.text.isNotBlank() }
                if (last != null) openCanvas(last.text, "Last reply") else status = "No reply to open"
            }
            "new" -> newChat()
            else -> { status = "Unknown command /$cmd — try /help"; return true }
        }
        draft = ""
        return true
    }


    fun stop() {
        job?.cancel()
        busy = false
        status = "Generation stopped"
    }

    /** Saves the open chat (if any) and switches to a blank one. Nothing is deleted. */
    fun newChat() {
        persist()
        resetView()
        currentChatId = ""
        store.currentChatId = ""
        chatPrefs = ChatPrefs()
        incognito = false
    }

    fun openLastChat() {
        val id = store.widgetLastId.ifBlank { chats.firstOrNull()?.id.orEmpty() }
        if (id.isNotBlank()) openChat(id) else status = "No recent chat"
    }

    fun openChat(id: String, ignoreChatLock: Boolean = false) {
        if (id == currentChatId && !incognito) return
        val prefs = ChatPrefs.parse(chats.firstOrNull { it.id == id }?.prefs.orEmpty())
        if (prefs.chatLocked && settings.appLock && !ignoreChatLock) {
            pendingLockedChatId = id
            locked = true
            status = "Unlock to open this chat"
            return
        }
        persist()
        resetView()
        incognito = false
        currentChatId = id
        store.currentChatId = id
        chatPrefs = prefs
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) { store.loadChat(id) }
            if (currentChatId == id) { messages.clear(); messages.addAll(loaded) }
        }
    }

    private var pendingLockedChatId: String? = null


    fun deleteChat(id: String) = deleteChats(listOf(id))

    /** Takes chats out of the list at once; their data is erased for good after a few seconds unless [undoDelete] runs. */
    fun deleteChats(ids: Collection<String>) {
        val gone = chats.filter { it.id in ids }
        if (gone.isEmpty()) return
        finalizeTrash()
        if (currentChatId in ids) { resetView(); currentChatId = ""; store.currentChatId = ""; chatPrefs = ChatPrefs() }
        chats.removeAll { it.id in ids }
        viewModelScope.launch(Dispatchers.IO) { gone.forEach { store.removeMeta(it.id) } }
        val t = Trash(gone)
        trash = t
        trashJob = viewModelScope.launch { delay(7000); if (trash === t) finalizeTrash() }
    }

    fun undoDelete() {
        val t = trash ?: return
        trashJob?.cancel()
        trash = null
        val merged = (chats.toList() + t.metas).sortedByDescending { it.updated }
        chats.clear()
        chats.addAll(merged)
        viewModelScope.launch(Dispatchers.IO) { t.metas.forEach { store.saveMeta(it) } }
    }

    private fun finalizeTrash() {
        val t = trash ?: return
        trashJob?.cancel()
        trash = null
        viewModelScope.launch(Dispatchers.IO) { t.metas.forEach { store.deleteChat(it.id) } }
    }

    class Trash(val metas: List<ChatMeta>)
    var trash by mutableStateOf<Trash?>(null)
        private set
    private var trashJob: Job? = null

    private fun saveMetaAsync(m: ChatMeta) {
        viewModelScope.launch(Dispatchers.IO) { store.saveMeta(m) }
    }

    private fun editChats(ids: Collection<String>, change: (ChatMeta) -> ChatMeta) {
        for (id in ids) {
            val i = chats.indexOfFirst { it.id == id }
            if (i >= 0) { chats[i] = change(chats[i]); saveMetaAsync(chats[i]) }
        }
    }

    fun setFolder(ids: Collection<String>, folder: String) = editChats(ids) { it.copy(folder = folder.trim().take(40)) }

    fun setTags(id: String, tags: String) = editChats(listOf(id)) { m ->
        m.copy(tags = tags.split(",").map { it.trim().trimStart('#') }.filter { it.isNotEmpty() }.distinct().joinToString(", ").take(120))
    }

    fun setArchived(ids: Collection<String>, archived: Boolean) = editChats(ids) { it.copy(archived = archived) }

    // ---------- app lock ----------
    var locked by mutableStateOf(false)
        private set
    private var backgroundedAt = 0L

    fun onBackground() { backgroundedAt = SystemClock.elapsedRealtime() }

    fun onForeground() {
        if (settings.appLock && backgroundedAt > 0L &&
            SystemClock.elapsedRealtime() - backgroundedAt >= settings.lockDelay * 1000L) locked = true
        backgroundedAt = 0L
    }

    fun unlock() {
        locked = false
        val pending = pendingLockedChatId
        pendingLockedChatId = null
        if (pending != null) {
            viewModelScope.launch {
                kotlinx.coroutines.delay(50)
                openChat(pending, ignoreChatLock = true)
            }
        }
    }

    fun clearAllChats() {
        trashJob?.cancel()
        trash = null
        resetView()
        currentChatId = ""
        chats.clear()
        viewModelScope.launch(Dispatchers.IO) { store.deleteAllChats() }
    }

    private fun resetView() {
        if (voiceMode) stopVoiceMode()
        job?.cancel()
        voiceJob?.cancel()
        player.stop(); speakingId = null
        busy = false
        summarizing = false
        clearUndoDelete()
        messages.clear(); attachments.clear(); docs.clear(); draft = ""
    }

    /** Replaces the last reply with a new one. The old reply is kept as an earlier version you can flip back to. */
    fun regenerate(model: String? = null) {
        if (busy) return
        val removed = ArrayList<Msg>()
        while (messages.isNotEmpty() && messages.last().role != Role.USER) removed.add(0, messages.removeAt(messages.lastIndex))
        val old = removed.lastOrNull { it.role == Role.ASSISTANT && !it.error && it.text.isNotBlank() }
        regenBase = when {
            old == null -> emptyList()
            old.variants.isNotEmpty() -> old.variants.mapIndexed { i, a -> if (i == old.variant) old.toAlt() else a }
            else -> listOf(old.toAlt())
        }
        regenBackup = removed
        oneShotModel = model
        if (messages.isNotEmpty()) run()
        else { messages.addAll(removed); regenBackup = emptyList(); regenBase = emptyList(); oneShotModel = null }
    }

    /** Shows another stored version of a reply (and keeps the one you leave stored). */
    fun selectVariant(id: Long, pos: Int) {
        val i = messages.indexOfFirst { it.id == id }
        if (i < 0) return
        val m = messages[i]
        val v = m.variants.getOrNull(pos) ?: return
        messages[i] = m.copy(
            text = v.text, reasoning = v.reasoning, model = v.model, usage = v.usage, variant = pos,
            variants = m.variants.mapIndexed { j, a -> if (j == m.variant) m.toAlt() else a }
        )
        persist()
    }

    private fun run() {
        busy = true
        val cid = currentChatId
        val base = regenBase
        val backup = regenBackup
        regenBase = emptyList()
        regenBackup = emptyList()
        job = viewModelScope.launch {
            var ok = false
            try {
                var rounds = 0
                while (true) {
                    val reply = streamOne(rounds)
                    if (reply.toolCalls.isEmpty() || rounds++ >= settings.maxToolRounds.coerceIn(1, 8)) break
                    for (tc in reply.toolCalls) {
                        val result = runTool(tc.name, tc.args)
                        messages += Msg(role = Role.TOOL, text = result, toolCallId = tc.id, toolName = tc.name)
                        recordToolLog(tc.name, result.take(300), ok = !result.startsWith("Error"))
                        if (settings.searchMode) {
                            val cites = CitationParser.fromToolResult(tc.name, result)
                            if (cites.isNotEmpty()) searchCitations = (searchCitations + cites).distinctBy { it.url }.take(12)
                        }
                    }
                }
                if (base.isNotEmpty()) {
                    val li = messages.indexOfLast { it.role == Role.ASSISTANT && !it.error }
                    if (li >= 0) {
                        val cur = messages[li]
                        val all = (base + cur.toAlt()).takeLast(8)
                        messages[li] = cur.copy(variants = all, variant = all.lastIndex)
                    }
                }
                if (settings.autoSpeak && !voiceMode) messages.lastOrNull { it.role == Role.ASSISTANT && it.text.isNotBlank() }?.let { speak(it) }
                ok = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (backup.isNotEmpty()) messages.addAll(backup)   // a failed regenerate keeps the old reply
                messages += Msg(role = Role.ASSISTANT, text = friendly(e), error = true)
            } finally {
                oneShotModel = null
                if (cid == currentChatId) { busy = false; persist(); if (ok) { maybeAutoTitle(cid); maybeAutoSummarize() } }
            }
        }
    }

    private suspend fun streamOne(round: Int): Msg {
        val servers = if (settings.toolMode == "off") emptyList() else mcpServers.filter { it.usable }
        val viaResponses = servers.isNotEmpty()
        val hasImagesNow = messages.any { !it.summarized && it.images.isNotEmpty() }
        if (round == 0 && wantsBuiltin(cfg, hasImagesNow) && !isGptOss(activeChatModel)) {
            status = "Web browsing / code execution need a gpt-oss model, so they were skipped for this reply."
        }
        val body = if (viaResponses) buildResponsesBody(servers) else buildBody(round)
        val model = body.getString("model")
        if (round == 0 && cfg.schemaOn) {
            if (parseSchema(cfg.schemaText) == null) status = "The JSON schema in Settings isn't valid JSON, so it was skipped."
            else if (!supportsSchema(model)) status = "Structured output isn't supported by ${model.substringAfterLast('/')}, so it was skipped."
        }
        val switchNote = if (model != activeChatModel)
            "switched from ${activeChatModel.substringAfterLast('/')} (images)" else null
        val stream = body.optBoolean("stream")
        val idx = messages.size
        messages += Msg(role = Role.ASSISTANT, model = model)
        val t0 = SystemClock.elapsedRealtime()
        val res = try {
            if (viaResponses) respondLoop(body, idx, stream)
            else api.chat(body, stream) { t, r ->
                main.post { if (idx < messages.size) messages[idx] = messages[idx].copy(text = t, reasoning = r) }
            }
        } catch (e: Exception) {
            if (idx < messages.size && messages[idx].text.isEmpty() && messages[idx].reasoning.isEmpty()) messages.removeAt(idx)
            throw e
        }
        res.rate?.let { lastRate = it }
        val spent = if (res.completionMs > 0) res.completionMs else SystemClock.elapsedRealtime() - t0
        viewModelScope.launch(Dispatchers.IO) { store.recordUsage(model, res.promptTokens, res.completionTokens, spent) }
        val shownReasoning = if (viaResponses && !settings.showReasoning) "" else res.reasoning
        val done = Msg(
            id = messages[idx].id, role = Role.ASSISTANT, text = res.text, reasoning = shownReasoning,
            toolCalls = res.toolCalls, model = model,
            usage = listOfNotNull(res.usage, switchNote).joinToString(" · ").ifBlank { null }, steps = res.steps
        )
        messages[idx] = done
        return done
    }

    // ---------- MCP: streaming and per-call approvals (Responses API) ----------

    /** Sends a Responses API request and keeps answering approval requests until the model gives its final reply. */
    private suspend fun respondLoop(first: JSONObject, idx: Int, stream: Boolean): ChatResult {
        var cur = first
        val steps = ArrayList<ToolStep>()
        var prompt = 0
        var completion = 0
        var ms = 0L
        var rounds = 0
        while (true) {
            val res = respondOnce(cur, idx, stream)
            steps += res.steps
            prompt += res.promptTokens
            completion += res.completionTokens
            ms += res.completionMs
            if (res.approvals.isEmpty() || rounds++ >= 5) {
                return res.copy(steps = steps, promptTokens = prompt, completionTokens = completion, completionMs = ms)
            }
            // stateless API: send the earlier output back, followed by your answers
            val input = JSONArray(cur.getJSONArray("input").toString())
            val raw = JSONArray(res.rawOutput ?: "[]")
            for (i in 0 until raw.length()) input.put(raw.get(i))
            for (a in res.approvals) {
                val ok = askApproval(a)
                input.put(JSONObject().put("type", "mcp_approval_response").put("approval_request_id", a.id).put("approve", ok))
            }
            cur = JSONObject(cur.toString()).put("input", input)
        }
    }

    private suspend fun respondOnce(body: JSONObject, idx: Int, stream: Boolean): ChatResult {
        if (!stream) return api.respond(JSONObject(body.toString()).put("stream", false))
        return try {
            api.respond(JSONObject(body.toString()).put("stream", true)) { t, r ->
                main.post { if (idx < messages.size) messages[idx] = messages[idx].copy(text = t, reasoning = r) }
            }
        } catch (e: ApiException) {
            // if streaming isn't accepted for this request, quietly fall back to one complete reply
            if ((e.code == 400 || e.code == 422 || e.code == 501) && e.message.orEmpty().contains("stream", ignoreCase = true))
                api.respond(JSONObject(body.toString()).put("stream", false))
            else throw e
        }
    }

    private suspend fun askApproval(a: McpApproval): Boolean {
        val req = ApprovalRequest(a.server, a.tool, a.args, CompletableDeferred())
        pendingApproval = req
        try { return req.answer.await() } finally { pendingApproval = null }
    }

    fun answerApproval(ok: Boolean) { pendingApproval?.answer?.complete(ok) }

    private fun wantsBuiltin(s: Settings, hasImages: Boolean): Boolean =
        (s.browserSearch || s.codeExecution) && !hasImages && s.toolMode != "off"

    /** System prompt plus a line telling the model its real name (models often guess "GPT-4" otherwise). */
    private fun systemText(model: String): String {
        val ws = settings.workspaces.firstOrNull { it.id == settings.activeWorkspaceId }
        val base = (cfg.systemPrompt.ifBlank { ws?.systemPrompt.orEmpty() }).trim()
        val mem = if (settings.memoryEnabled) MemoryStore.systemBlock(MemoryStore.parse(settings.memoryJson)) else ""
        val searchHint = if (settings.searchMode)
            "Search mode is on: use web_search / fetch_url when needed and cite sources with markdown links [title](url)."
            else ""
        val short = model.substringAfterLast('/')
        val owner = owners[model]?.takeIf { it.isNotBlank() }
        val hint = "For reference: this conversation is running on the model \"$short\" (id: $model" +
            (if (owner != null) ", published by $owner" else "") + "), served through Groq. " +
            "If asked which model or AI you are, answer with this name and do not claim to be another model."
        val parts = listOf(base, mem, searchHint, hint).filter { it.isNotBlank() }
        return parts.joinToString("\n\n")
    }

    /** Always the model you selected. The only exception is a request with images on a model that cannot see them. */
    private fun effectiveModel(hasImages: Boolean): String {
        val chosen = activeChatModel
        return if (hasImages && !isVisionModel(chosen)) cfg.visionModel else chosen
    }

    private fun builtinTools(responses: Boolean): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        if (settings.browserSearch) out += JSONObject().put("type", "browser_search")
        if (settings.codeExecution) {
            val t = JSONObject().put("type", "code_interpreter")
            if (responses) t.put("container", JSONObject().put("type", "auto"))
            out += t
        }
        return out
    }

    /** Request for the Responses API: remote MCP servers / connectors (+ built-in tools). Not streamed. */
    private fun buildResponsesBody(servers: List<McpServer>): JSONObject {
        val s = cfg
        val hasImages = messages.any { !it.summarized && it.images.isNotEmpty() }
        val builtin = wantsBuiltin(s, hasImages) && isGptOss(activeChatModel)
        val model = effectiveModel(hasImages)

        var budget = 3
        val keep = HashSet<Long>()
        for (m in messages.asReversed()) if (m.images.isNotEmpty() && budget >= m.images.size) { keep += m.id; budget -= m.images.size }

        fun item(role: String, content: Any) =
            JSONObject().put("type", "message").put("role", role).put("content", content)

        val input = JSONArray()
        systemText(model).let { if (it.isNotBlank()) input.put(item("system", it)) }
        for (m in messages) {
            if (m.error || m.summarized) continue
            when (m.role) {
                Role.USER -> {
                    if (m.images.isNotEmpty() && m.id in keep) {
                        val parts = JSONArray()
                        parts.put(JSONObject().put("type", "input_text").put("text", m.apiText().ifBlank { "Describe this image." }))
                        m.images.forEach {
                            parts.put(JSONObject().put("type", "input_image").put("detail", "auto").put("image_url", it))
                        }
                        input.put(item("user", parts))
                    } else {
                        input.put(item("user", if (m.images.isNotEmpty()) "[image omitted] ${m.apiText()}" else m.apiText()))
                    }
                }
                Role.ASSISTANT -> if (m.text.isNotBlank()) input.put(item("assistant", m.text))
                Role.SYSTEM -> if (m.summary) input.put(item("system", "Summary of the earlier part of this conversation (older messages were condensed to save space):\n${m.text}"))
                else -> {}
            }
        }

        val tools = JSONArray()
        servers.forEach { tools.put(it.toTool()) }
        if (builtin) builtinTools(true).forEach { tools.put(it) }

        val b = JSONObject()
            .put("model", model).put("input", input).put("tools", tools)
            .put("temperature", s.temperature.toDouble()).put("top_p", s.topP.toDouble())
            .put("max_output_tokens", s.maxTokens).put("stream", s.stream)
        if (isReasoningModel(model) && s.reasoningEffort != "default") {
            b.put("reasoning", JSONObject().put("effort", s.reasoningEffort))
        }
        return b
    }

    private fun buildBody(round: Int): JSONObject {
        val s = cfg
        val hasImages = messages.any { !it.summarized && it.images.isNotEmpty() }
        val builtin = wantsBuiltin(s, hasImages) && isGptOss(activeChatModel)
        val model = effectiveModel(hasImages)

        // Vision requests accept at most 3 images: keep the most recent ones.
        var budget = 3
        val keep = HashSet<Long>()
        for (m in messages.asReversed()) if (m.images.isNotEmpty() && budget >= m.images.size) { keep += m.id; budget -= m.images.size }

        val arr = JSONArray()
        systemText(model).let { if (it.isNotBlank()) arr.put(JSONObject().put("role", "system").put("content", it)) }
        for (m in messages) {
            if (m.error || m.summarized) continue
            when (m.role) {
                Role.USER -> {
                    if (m.images.isNotEmpty() && m.id in keep) {
                        val parts = JSONArray()
                        parts.put(JSONObject().put("type", "text").put("text", m.apiText().ifBlank { "Describe this image." }))
                        m.images.forEach {
                            parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", it)))
                        }
                        arr.put(JSONObject().put("role", "user").put("content", parts))
                    } else {
                        val t = if (m.images.isNotEmpty()) "[image omitted] ${m.apiText()}" else m.apiText()
                        arr.put(JSONObject().put("role", "user").put("content", t))
                    }
                }
                Role.ASSISTANT -> {
                    if (m.text.isBlank() && m.toolCalls.isEmpty()) continue
                    val o = JSONObject().put("role", "assistant")
                    o.put("content", if (m.text.isBlank()) JSONObject.NULL else m.text)
                    if (m.toolCalls.isNotEmpty()) {
                        val tc = JSONArray()
                        m.toolCalls.forEach {
                            tc.put(JSONObject().put("id", it.id).put("type", "function")
                                .put("function", JSONObject().put("name", it.name).put("arguments", it.args)))
                        }
                        o.put("tool_calls", tc)
                    }
                    arr.put(o)
                }
                Role.TOOL -> arr.put(JSONObject().put("role", "tool").put("tool_call_id", m.toolCallId).put("name", m.toolName ?: "").put("content", m.text))
                Role.SYSTEM -> if (m.summary) arr.put(JSONObject().put("role", "system").put("content", "Summary of the earlier part of this conversation (older messages were condensed to save space):\n${m.text}"))
            }
        }

        val schema = if (s.schemaOn) parseSchema(s.schemaText) else null
        val schemaOk = schema != null && supportsSchema(model)
        val b = JSONObject()
            .put("model", model)
            .put("messages", arr)
            .put("temperature", s.temperature.toDouble())
            .put("top_p", s.topP.toDouble())
            .put("max_completion_tokens", s.maxTokens)
            .put("stream", s.stream && !s.jsonMode && !schemaOk)
        if (schemaOk) {
            b.put("response_format", JSONObject().put("type", "json_schema")
                .put("json_schema", JSONObject().put("name", "response").put("schema", schema)))
        } else if (s.jsonMode) {
            b.put("response_format", JSONObject().put("type", "json_object"))
        } else if (s.toolMode != "off") {
            val tools = JSONArray()
            val fnNames = mutableListOf<String>()
            if (s.tools) {
                LocalTools.active(deviceOff()).forEach { tools.put(it); fnNames += it.getJSONObject("function").getString("name") }
                if (s.clientWebTools) {
                    val web = WebTools.definitions()
                    for (i in 0 until web.length()) {
                        val d = web.getJSONObject(i)
                        tools.put(d)
                        fnNames += d.getJSONObject("function").getString("name")
                    }
                }
                activeCustom().forEach { tools.put(CustomTools.definition(it)); fnNames += it.name }
            }
            if (builtin) builtinTools(false).forEach { tools.put(it) }
            if (tools.length() > 0) b.put("tools", tools).put("tool_choice", toolChoice(round, fnNames))
            if (builtin) b.put("stream", false)
        }
        if (s.serviceTier != "on_demand") b.put("service_tier", s.serviceTier)
        if (isReasoningModel(model)) {
            if (s.reasoningEffort != "default") b.put("reasoning_effort", s.reasoningEffort)
            if (s.showReasoning) b.put("include_reasoning", true)
        }
        return b
    }

    // ---------- images ----------
    fun addImages(uris: List<Uri>) {
        viewModelScope.launch {
            for (u in uris) {
                if (attachments.size >= 3) { status = "Max 3 images per request"; break }
                val d = withContext(Dispatchers.IO) {
                    try { uriToDataUrl(getApplication<Application>(), u) } catch (e: Exception) { null }
                }
                if (d != null) attachments += d else status = "Couldn't read image"
            }
        }
    }

    // ---------- speech to text ----------
    fun toggleRecord() {
        // Barge-in: stop TTS when user starts speaking
        if (!recording) { player.stop(); speakingId = null }

        if (recording) {
            recording = false
            val f = recorder.stop()
            if (f != null) transcribe(f) else status = "Recording too short"
        } else {
            if (apiKey.isBlank()) { status = "Add your Groq API key in Settings"; return }
            try { recorder.start(); recording = true } catch (e: Exception) { status = "Mic error: ${e.message}" }
        }
    }

    private fun transcribe(f: File) {
        transcribing = true
        viewModelScope.launch {
            try {
                val t = api.transcribe(f, settings.sttModel, settings.sttLanguage, settings.translate)
                draft = (draft + " " + t).trim()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status = friendly(e) }
            finally { transcribing = false; f.delete() }
        }
    }

    // ---------- text to speech ----------
    fun speak(m: Msg, onFinished: (() -> Unit)? = null) {
        if (speakingId == m.id && onFinished == null) { player.stop(); speakingId = null; return }
        player.stop()
        speakingId = m.id
        viewModelScope.launch {
            try {
                val chunks = TtsText.chunks(m.text)
                if (chunks.isEmpty()) { speakingId = null; onFinished?.invoke(); return@launch }
                player.begin { speakingId = null; onFinished?.invoke() }
                for ((i, c) in chunks.withIndex()) {
                    if (speakingId != m.id) return@launch
                    val f = File(getApplication<Application>().cacheDir, "tts_${m.id}_$i.wav")
                    api.speech(c, settings.ttsModel, settings.ttsVoice, f)
                    if (speakingId != m.id) { f.delete(); return@launch }
                    player.add(f)           // playback starts with the first chunk while the rest is still being made
                }
                player.finish()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status = friendly(e); speakingId = null; player.stop()
            }
        }
    }

    private suspend fun speakAndWait(m: Msg) {
        val finished = CompletableDeferred<Unit>()
        speak(m) { finished.complete(Unit) }
        try { finished.await() } finally { if (!finished.isCompleted) player.stop() }
    }

    // ---------- hands-free voice mode: listen, answer, read aloud, repeat ----------
    fun startVoiceMode() {
        player.stop(); speakingId = null

        if (voiceMode || busy) return
        if (apiKey.isBlank()) { status = "Add your Groq API key in Settings"; return }
        voiceMode = true
        voiceJob = viewModelScope.launch {
            try {
                while (voiceMode) {
                    val heard = listenOnce() ?: continue
                    voiceState = "Thinking…"
                    draft = heard
                    send()
                    while (busy && voiceMode) delay(100)
                    val reply = messages.lastOrNull { it.role == Role.ASSISTANT && !it.error && it.text.isNotBlank() }
                    if (reply != null && voiceMode) { voiceState = "Speaking…"; speakAndWait(reply) }
                }
            } finally {
                voiceMode = false; voiceState = ""; voiceLevel = 0f
                recorder.stop()?.delete()
            }
        }
    }

    fun stopVoiceMode() {
        voiceMode = false
        voiceJob?.cancel()
        player.stop()
        speakingId = null
        recorder.stop()?.delete()
        voiceState = ""; voiceLevel = 0f
    }

    /** Records until you have spoken and then paused; returns the transcript, or null if nothing was said. */
    private suspend fun listenOnce(): String? {
        voiceState = "Listening…"
        try { recorder.start() } catch (e: Exception) { status = "Mic error: ${e.message}"; voiceMode = false; return null }
        var heard = false
        var silentMs = 0
        var waitedMs = 0
        while (voiceMode) {
            delay(100)
            val amp = recorder.level()
            voiceLevel = (amp / 12000f).coerceIn(0f, 1f)
            if (amp > 2200) { heard = true; silentMs = 0 } else if (heard) silentMs += 100
            waitedMs += 100
            if (heard && silentMs >= 1300) break
            if (!heard && waitedMs >= 10000) break
            if (waitedMs >= 60000) break
        }
        val f = recorder.stop()
        voiceLevel = 0f
        if (!heard || f == null) { f?.delete(); return null }
        voiceState = "Transcribing…"
        return try {
            api.transcribe(f, settings.sttModel, settings.sttLanguage, settings.translate).takeIf { it.isNotBlank() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            status = friendly(e); null
        } finally {
            f.delete()
        }
    }

    // ---------- documents ----------
    fun addDocuments(uris: List<Uri>) {
        viewModelScope.launch {
            for (u in uris) {
                if (docs.size >= 3) { status = "Max 3 documents per message"; break }
                val r = withContext(Dispatchers.IO) { DocReader.read(getApplication<Application>(), u) }
                val d = r.doc
                if (d != null) docs += d else status = r.error ?: "Couldn't read the document"
            }
        }
    }

    // ---------- long conversations: summarise older messages ----------
    private suspend fun quickChat(system: String, user: String, maxTokens: Int): String {
        val model = cfg.chatModel
        val body = JSONObject().put("model", model).put("stream", false).put("temperature", 0.3)
            .put("max_completion_tokens", if (isReasoningModel(model)) maxTokens + 400 else maxTokens)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user)))
        when {
            isGptOss(model) -> body.put("reasoning_effort", "low")
            "qwen3" in model.lowercase() -> body.put("reasoning_effort", "none")
        }
        return api.chat(body, false) { _, _ -> }.text.trim()
    }

    /**
     * Condenses everything except the last few messages into one summary. The old messages stay visible
     * (dimmed) but are no longer sent to the model, so nothing is lost.
     */
    fun summarizeOlder() {
        if (busy || summarizing) return
        val live = messages.indices.filter { val m = messages[it]; !m.summarized && !m.error && m.role != Role.TOOL }
        if (live.size < 8) { status = "The conversation is still short, nothing to summarise yet"; return }
        val keepFrom = live[live.size - 6]
        val keepId = messages[keepFrom].id
        val targets = messages.indices.filter { it < keepFrom && !messages[it].summarized }
        val targetIds = targets.map { messages[it].id }.toSet()
        val transcript = StringBuilder()
        for (i in targets) {
            val m = messages[i]
            when {
                m.summary -> transcript.append("Earlier summary: ").append(m.text.take(4000)).append("\n\n")
                m.role == Role.USER -> {
                    transcript.append("User: ").append(m.text.take(1500))
                    if (m.docs.isNotEmpty()) transcript.append(" [attached: ").append(m.docs.joinToString { it.name }).append("]")
                    transcript.append("\n\n")
                }
                m.role == Role.ASSISTANT && m.text.isNotBlank() -> transcript.append("Assistant: ").append(m.text.take(1500)).append("\n\n")
            }
            if (transcript.length > 48000) break
        }
        if (transcript.isBlank()) return
        summarizing = true
        val cid = currentChatId
        viewModelScope.launch {
            try {
                val text = quickChat(
                    "Summarise this conversation so far for your own future reference. Keep names, decisions, facts, numbers, " +
                        "code identifiers and open questions. At most 350 words. Reply with the summary only.",
                    transcript.toString(), 700
                )
                if (text.isBlank() || cid != currentChatId) return@launch
                val at = messages.indexOfFirst { it.id == keepId }
                if (at < 0) return@launch
                for (i in messages.indices) if (messages[i].id in targetIds) messages[i] = messages[i].copy(summarized = true)
                messages.add(at, Msg(role = Role.SYSTEM, text = text, summary = true))
                persist()
                status = "Older messages summarised"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status = friendly(e)
            } finally {
                summarizing = false
            }
        }
    }

    private fun maybeAutoSummarize() {
        if (!settings.autoSummarize || summarizing) return
        val w = contextWindow
        if (w > 0 && contextUsed > w * 0.85) summarizeOlder()
    }

    // ---------- prompt templates ----------
    fun saveTemplate(name: String, body: String) {
        val n = name.trim()
        if (n.isEmpty() || body.isBlank()) return
        update(settings.copy(templates = settings.templates.filter { it.name != n } + PromptTemplate(n, body)))
    }

    fun deleteTemplate(name: String) = update(settings.copy(templates = settings.templates.filter { it.name != name }))

    // ---------- usage statistics ----------
    suspend fun usage(sinceMs: Long): List<UsageRow> = withContext(Dispatchers.IO) { store.usageSince(sinceMs) }

    fun clearUsage() { viewModelScope.launch(Dispatchers.IO) { store.clearUsage() } }

    // ---------- helpers ----------
    private fun persist() {
        if (incognito) return
        val id = currentChatId
        if (id.isEmpty()) return
        // an existing chat may legitimately become empty (e.g. its first message was edited)
        if (messages.isEmpty() && chats.none { it.id == id }) return
        val snap = messages.toList()
        val old = chats.firstOrNull { it.id == id }
        val meta = (old ?: ChatMeta(id, fallbackTitle(snap), 0L)).copy(
            updated = System.currentTimeMillis(),
            prefs = if (chatPrefs.isDefault) "" else chatPrefs.toJson().toString()
        )
        chats.removeAll { it.id == id }
        chats.add(0, meta)
        // Widget: remember last chat id + title
        viewModelScope.launch(Dispatchers.IO) {
            store.saveChat(id, snap); store.saveMeta(meta)
            store.widgetLastId = id
            store.widgetLastTitle = meta.title.take(40)
        }
    }

    fun startIncognitoChat() {
        persist()
        resetView()
        currentChatId = "incognito-${System.currentTimeMillis()}"
        store.currentChatId = ""
        chatPrefs = ChatPrefs()
        incognito = true
        status = "Incognito chat — not saved until you choose Save"
    }

    fun saveIncognitoChat() {
        if (!incognito) return
        incognito = false
        // assign a normal id if needed
        if (currentChatId.startsWith("incognito-")) {
            currentChatId = System.currentTimeMillis().toString()
            store.currentChatId = currentChatId
        }
        persist()
        status = "Chat saved"
    }

    fun discardIncognitoChat() {
        if (!incognito) return
        resetView()
        currentChatId = ""
        store.currentChatId = ""
        chatPrefs = ChatPrefs()
        incognito = false
        status = "Incognito chat discarded"
    }

    /** Fast / Cheap / Smart model presets (chat model + temperature). */
    fun applyModelPreset(kind: String) {
        val (model, temp) = when (kind) {
            "fast" -> "llama-3.1-8b-instant" to 0.7f
            "cheap" -> "llama-3.1-8b-instant" to 0.5f
            "smart" -> "llama-3.3-70b-versatile" to 0.7f
            else -> return
        }
        // Prefer a model that exists in the loaded list when possible
        val pick = vmChatModelOr(model)
        update(settings.copy(chatModel = pick, temperature = temp))
        status = when (kind) {
            "fast" -> "Preset: Fast ($pick)"
            "cheap" -> "Preset: Cheap ($pick)"
            else -> "Preset: Smart ($pick)"
        }
    }

    private fun vmChatModelOr(preferred: String): String {
        val ids = chatModels.map { it.id }
        if (preferred in ids) return preferred
        // fallbacks
        val alts = listOf(preferred, "llama-3.3-70b-versatile", "llama-3.1-8b-instant", "gemma2-9b-it")
        return alts.firstOrNull { it in ids } ?: settings.chatModel
    }

    fun recordToolLog(name: String, detail: String, ok: Boolean = true) {
        toolLog.add(0, ToolLogEntry(System.currentTimeMillis(), name, detail.take(500), ok))
        while (toolLog.size > 50) toolLog.removeAt(toolLog.lastIndex)
    }

    fun clearToolLog() { toolLog.clear() }


    // ---------- chat management ----------
    fun renameChat(id: String, title: String) {
        val i = chats.indexOfFirst { it.id == id }
        if (i < 0) return
        val t = title.trim()
        if (t.isEmpty()) return
        chats[i] = chats[i].copy(title = t.take(80))
        saveMetaAsync(chats[i])
    }

    /** Last deleted turn, for undo snackbar. */
    private var undoBundle: Pair<Int, List<Msg>>? = null
    var canUndoDelete by mutableStateOf(false)
        private set

    /** Removes a user message together with the reply (and tool steps) that followed it. Supports undo. */
    fun deleteTurn(id: Long) {
        if (busy) return
        val i = messages.indexOfFirst { it.id == id }
        if (i < 0) return
        var end = i + 1
        while (end < messages.size && messages[end].role != Role.USER) end++
        val removed = messages.subList(i, end).toList()
        undoBundle = i to removed
        canUndoDelete = true
        repeat(end - i) { messages.removeAt(i) }
        if (messages.isEmpty()) {
            // keep chat id; empty thread is fine — undo can restore
            persist()
        } else persist()
        status = "Message deleted"
    }

    fun undoDeleteTurn() {
        val bundle = undoBundle ?: return
        val (index, removed) = bundle
        val at = index.coerceIn(0, messages.size)
        messages.addAll(at, removed)
        undoBundle = null
        canUndoDelete = false
        persist()
        status = "Delete undone"
    }

    fun clearUndoDelete() {
        undoBundle = null
        canUndoDelete = false
    }

    /** Start a new chat containing messages up to and including [id]. */
    fun branchFromMessage(id: Long) {
        if (busy) return
        val idx = messages.indexOfFirst { it.id == id }
        if (idx < 0) return
        val kept = messages.take(idx + 1).map { it.copy(id = System.nanoTime() + it.id % 1000) }
        persist()
        resetView()
        incognito = false
        currentChatId = System.currentTimeMillis().toString()
        store.currentChatId = currentChatId
        chatPrefs = ChatPrefs()
        messages.addAll(kept)
        persist()
        status = "Branched into a new chat"
    }

    fun togglePinMessage(id: Long) {
        val i = messages.indexOfFirst { it.id == id }
        if (i < 0) return
        val m = messages[i]
        messages[i] = m.copy(pinned = !m.pinned)
        persist()
        status = if (!m.pinned) "Message pinned" else "Pin removed"
    }

    fun pinnedMessages(): List<Msg> = messages.filter { it.pinned && it.text.isNotBlank() }


    /** Puts a user message (and its images) back into the input box and drops it and everything after it. */
    fun editMessage(id: Long) {
        if (busy) return
        val i = messages.indexOfFirst { it.id == id && it.role == Role.USER }
        if (i < 0) return
        val m = messages[i]
        draft = m.text
        attachments.clear()
        attachments.addAll(m.images)
        docs.clear()
        docs.addAll(m.docs)
        while (messages.size > i) messages.removeAt(messages.lastIndex)
        persist()
    }

    fun chatMarkdown(): String {
        val title = chats.firstOrNull { it.id == currentChatId }?.title ?: "Chat"
        val sb = StringBuilder("# ").append(title).append("\n\n")
        for (m in messages) {
            when (m.role) {
                Role.USER -> {
                    sb.append("**You:** ").append(m.text)
                    if (m.images.isNotEmpty()) sb.append(" _(").append(m.images.size).append(" image(s) not included)_")
                    sb.append("\n\n")
                }
                Role.ASSISTANT -> if (m.text.isNotBlank()) {
                    sb.append("**").append(m.model?.substringAfterLast('/') ?: "Assistant").append(":** ")
                        .append(m.text).append("\n\n")
                }
                Role.TOOL -> sb.append("> 🔧 ").append(m.toolName ?: "tool").append(": ").append(m.text).append("\n\n")
                Role.SYSTEM -> {}
            }
        }
        return sb.toString().trim()
    }

    // ---------- personas (saved system prompts) ----------
    /** Settings as JSON for backup or sharing. API keys, MCP servers and custom tools are never included. */
    fun exportSettings(): String = settings.toJson().toString(2)

    fun importSettings(text: String): Boolean = try {
        val j = JSONObject(text.trim())
        if (!j.has("chatModel")) false else { update(Settings.fromJson(j)); true }
    } catch (e: Exception) { false }

    fun togglePin(id: String) {
        val i = chats.indexOfFirst { it.id == id }
        if (i < 0) return
        chats[i] = chats[i].copy(pinned = !chats[i].pinned)
        saveMetaAsync(chats[i])
    }

    /** Chats whose title or message text contains [query], with an excerpt of the first matching text. */
    suspend fun searchChats(query: String, list: List<ChatMeta>): List<ChatHit> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.length < 2) return@withContext emptyList<ChatHit>()
        list.mapNotNull { c ->
            val text = store.chatText(c.id)
            val i = text.indexOf(q, ignoreCase = true)
            if (i < 0 && !c.title.contains(q, ignoreCase = true) && !c.tags.contains(q, ignoreCase = true) && !c.folder.contains(q, ignoreCase = true)) null
            else ChatHit(c, if (i >= 0) excerpt(text, i, q.length) else "")
        }
    }

    private fun excerpt(text: String, at: Int, len: Int): String {
        val start = (at - 30).coerceAtLeast(0)
        val end = (at + len + 50).coerceAtMost(text.length)
        return (if (start > 0) "…" else "") + text.substring(start, end).replace('\n', ' ') + (if (end < text.length) "…" else "")
    }

    // ---------- automatic chat titles ----------
    private val titleTried = HashSet<String>()

    private fun fallbackTitle(list: List<Msg>): String =
        list.firstOrNull { it.role == Role.USER }?.text?.trim()?.replace("\n", " ")?.take(48)?.ifBlank { null } ?: "Image chat"

    /** After the first reply of a new chat, asks the model for a short title. Skipped if you renamed the chat. */
    private fun maybeAutoTitle(cid: String) {
        if (!settings.autoTitle || cid.isEmpty() || cid in titleTried || apiKey.isBlank()) return
        val meta = chats.firstOrNull { it.id == cid } ?: return
        val snap = messages.toList()
        if (meta.title != fallbackTitle(snap)) return
        val user = snap.firstOrNull { it.role == Role.USER }?.text.orEmpty()
        val reply = snap.firstOrNull { it.role == Role.ASSISTANT && !it.error && it.text.isNotBlank() }?.text ?: return
        titleTried += cid
        val model = cfg.chatModel
        viewModelScope.launch {
            try {
                val body = JSONObject().put("model", model).put("stream", false).put("temperature", 0.3)
                    .put("max_completion_tokens", if (isReasoningModel(model)) 256 else 32)
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content",
                            "Write a very short title (at most 5 words) for this conversation. Reply with the title only: no quotes and no final punctuation."))
                        .put(JSONObject().put("role", "user").put("content",
                            "User: ${user.take(400)}\n\nAssistant: ${reply.take(400)}")))
                when {
                    isGptOss(model) -> body.put("reasoning_effort", "low")
                    "qwen3" in model.lowercase() -> body.put("reasoning_effort", "none")
                }
                val title = api.chat(body, false) { _, _ -> }.text
                    .lines().firstOrNull { it.isNotBlank() }.orEmpty()
                    .trim().trim('"', '\'', '“', '”', '.', '*', '#').trim().take(60)
                val now = chats.firstOrNull { it.id == cid }
                if (title.isNotEmpty() && now != null && now.title == fallbackTitle(snap)) renameChat(cid, title)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // a missing title is not worth bothering the user about
            }
        }
    }

    fun applyPersona(p: Persona) = update(settings.copy(systemPrompt = p.prompt))

    fun savePersona(name: String, prompt: String) {
        val n = name.trim()
        if (n.isEmpty() || prompt.isBlank()) return
        val rest = settings.personas.filter { !it.name.equals(n, ignoreCase = true) }
        update(settings.copy(personas = rest + Persona(n, prompt.trim())))
    }

    fun deletePersona(name: String) = update(settings.copy(personas = settings.personas.filter { it.name != name }))

    private fun friendly(e: Exception): String = friendlyErrorMessage(e)

    override fun onCleared() {
        player.stop()
        if (recording) recorder.stop()?.delete()
    }

    init {
        mcpServers.addAll(store.loadMcp())
        customTools.addAll(store.loadTools())
        locked = settings.appLock
        viewModelScope.launch {
            // the chat list is read and decrypted off the main thread so start-up never waits on it
            val index = withContext(Dispatchers.IO) { store.loadIndex() }
            chats.addAll(index)
            autoArchiveIfNeeded()
            val cur = store.currentChatId
            if (cur.isNotEmpty() && chats.any { it.id == cur }) {
                val loaded = withContext(Dispatchers.IO) { store.loadChat(cur) }
                if (currentChatId.isEmpty() && messages.isEmpty()) {
                    currentChatId = cur
                    chatPrefs = ChatPrefs.parse(chats.firstOrNull { it.id == cur }?.prefs.orEmpty())
                    messages.addAll(loaded)
                }
            }
        }
        refreshModels(loud = false)
    }
}
